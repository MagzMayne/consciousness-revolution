var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/araya-edit-cockpit.mjs
var araya_edit_cockpit_exports = {};
__export(araya_edit_cockpit_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(araya_edit_cockpit_exports);

// netlify/functions/domain-tools.mjs
var BUILDER_COCKPITS = {
  commander: {
    name: "Commander",
    role: "Mission Commander",
    cockpit: "/COMMANDER_COCKPIT.html",
    discord_id: null,
    xp: 0,
    domain: "1_COMMAND",
    access_tier: "PERSONAL"
  },
  tiger: {
    name: "Tiger",
    role: "Technical Builder",
    cockpit: "/OPERATOR_COCKPIT_TIGER.html",
    discord_id: null,
    // TODO: get from Discord
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  alex: {
    name: "Alex",
    role: "Designer Builder",
    cockpit: "/OPERATOR_COCKPIT_ALEX.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  agent_r: {
    name: "Agent R",
    role: "AI Agent Builder",
    cockpit: "/OPERATOR_COCKPIT_AGENT_R.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  toby: {
    name: "Toby",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_TOBY.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  josh_serrano: {
    name: "Josh Serrano",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_JOSH_SERRANO.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  ryan: {
    name: "Ryan",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_RYAN.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  }
};
function getBuilder(identifier) {
  if (!identifier) return null;
  const normalized = identifier.toLowerCase().replace(/[\s-]/g, "_");
  if (BUILDER_COCKPITS[normalized]) {
    return BUILDER_COCKPITS[normalized];
  }
  const builders = Object.values(BUILDER_COCKPITS);
  return builders.find(
    (b) => b.name.toLowerCase() === identifier.toLowerCase() || b.name.toLowerCase().replace(/[\s-]/g, "_") === normalized || b.discord_id === identifier
  );
}

// netlify/functions/araya-edit-cockpit.mjs
var GITHUB_TOKEN = process.env.GITHUB_TOKEN;
var GITHUB_OWNER = "overkor-tek";
var GITHUB_REPO = "consciousness-revolution";
var GITHUB_BRANCH = "master";
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Method not allowed - use POST" })
    };
  }
  try {
    const { builder_name, edit_type, edit_data, auth_token } = JSON.parse(event.body);
    if (!builder_name || !edit_type || !edit_data) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: "Missing required fields: builder_name, edit_type, edit_data"
        })
      };
    }
    const builder = getBuilder(builder_name);
    if (!builder) {
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: `Builder '${builder_name}' not found in registry`
        })
      };
    }
    const cockpitPath = builder.cockpit.replace(/^\//, "");
    const fullPath = cockpitPath;
    console.log(`[ARAYA-EDIT] Editing cockpit for ${builder.name}: ${fullPath}`);
    console.log(`[ARAYA-EDIT] Edit type: ${edit_type}`);
    const currentFile = await fetchGitHubFile(fullPath);
    if (!currentFile) {
      return {
        statusCode: 500,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: `Failed to fetch cockpit file from GitHub: ${fullPath}`
        })
      };
    }
    const currentContent = Buffer.from(currentFile.content, "base64").toString("utf-8");
    let newContent;
    switch (edit_type) {
      case "add_task":
        newContent = addTaskToCockpit(currentContent, edit_data);
        break;
      case "update_status":
        newContent = updateCockpitStatus(currentContent, edit_data);
        break;
      case "add_note":
        newContent = addNoteToCockpit(currentContent, edit_data);
        break;
      case "update_xp":
        newContent = updateBuilderXP(currentContent, edit_data);
        break;
      default:
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({
            error: `Unknown edit_type: ${edit_type}. Supported: add_task, update_status, add_note, update_xp`
          })
        };
    }
    const commitResult = await commitToGitHub(
      fullPath,
      newContent,
      currentFile.sha,
      `ARAYA: ${edit_type} for ${builder.name}`
    );
    if (!commitResult.success) {
      return {
        statusCode: 500,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: "Failed to commit changes to GitHub",
          details: commitResult.error
        })
      };
    }
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: true,
        builder: builder.name,
        cockpit: builder.cockpit,
        edit_type,
        commit_sha: commitResult.sha,
        message: `Successfully updated ${builder.name}'s cockpit - changes will deploy automatically`,
        deploy_url: "https://consciousnessrevolution.io" + builder.cockpit
      })
    };
  } catch (error) {
    console.error("[ARAYA-EDIT] Error:", error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message
      })
    };
  }
}
async function fetchGitHubFile(path) {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}?ref=${GITHUB_BRANCH}`;
  try {
    const response = await fetch(url, {
      headers: {
        "Authorization": `token ${GITHUB_TOKEN}`,
        "Accept": "application/vnd.github.v3+json"
      }
    });
    if (!response.ok) {
      console.error(`[ARAYA-EDIT] GitHub fetch failed: ${response.status} ${response.statusText}`);
      return null;
    }
    return await response.json();
  } catch (error) {
    console.error("[ARAYA-EDIT] GitHub fetch error:", error);
    return null;
  }
}
async function commitToGitHub(path, content, sha, message) {
  const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`;
  try {
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Authorization": `token ${GITHUB_TOKEN}`,
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message,
        content: Buffer.from(content).toString("base64"),
        sha,
        branch: GITHUB_BRANCH,
        committer: {
          name: "ARAYA Bot",
          email: "araya@consciousnessrevolution.io"
        }
      })
    });
    if (!response.ok) {
      const errorData = await response.json();
      return {
        success: false,
        error: `GitHub commit failed: ${response.status} ${errorData.message || response.statusText}`
      };
    }
    const data = await response.json();
    return {
      success: true,
      sha: data.commit.sha
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}
function addTaskToCockpit(htmlContent, taskData) {
  const { title, description, priority = "medium", category = "general" } = taskData;
  const taskHtml = `
            <div class="task task-${priority}">
                <div class="task-header">
                    <span class="task-title">${escapeHtml(title)}</span>
                    <span class="task-priority">${priority}</span>
                </div>
                <div class="task-desc">${escapeHtml(description)}</div>
                <div class="task-meta">
                    <span class="task-category">${category}</span>
                    <span class="task-date">${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}</span>
                </div>
            </div>`;
  return htmlContent.replace("</body>", `${taskHtml}
</body>`);
}
function updateCockpitStatus(htmlContent, statusData) {
  const { status, message } = statusData;
  const statusHtml = `<div class="status status-${status}">${escapeHtml(message)}</div>`;
  if (htmlContent.includes('<div class="status')) {
    return htmlContent.replace(/<div class="status[^>]*>.*?<\/div>/s, statusHtml);
  } else {
    return htmlContent.replace("</header>", `${statusHtml}
</header>`);
  }
}
function addNoteToCockpit(htmlContent, noteData) {
  const { note, timestamp = (/* @__PURE__ */ new Date()).toISOString() } = noteData;
  const noteHtml = `
            <div class="note">
                <div class="note-time">${new Date(timestamp).toLocaleString()}</div>
                <div class="note-content">${escapeHtml(note)}</div>
            </div>`;
  return htmlContent.replace("</body>", `${noteHtml}
</body>`);
}
function updateBuilderXP(htmlContent, xpData) {
  const { xp, action } = xpData;
  const xpPattern = /<span class="xp-count">\d+<\/span>/;
  const newXpHtml = `<span class="xp-count">${xp}</span>`;
  if (xpPattern.test(htmlContent)) {
    return htmlContent.replace(xpPattern, newXpHtml);
  } else {
    return htmlContent.replace("</header>", `<div class="xp-display">XP: ${newXpHtml}</div>
</header>`);
  }
}
function escapeHtml(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
