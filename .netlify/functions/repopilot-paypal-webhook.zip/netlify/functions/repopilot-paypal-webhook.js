var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/repopilot-paypal-webhook.mjs
var repopilot_paypal_webhook_exports = {};
__export(repopilot_paypal_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(repopilot_paypal_webhook_exports);
var import_crypto = __toESM(require("crypto"), 1);
var RELEVANT_EVENTS = [
  "PAYMENT.SALE.COMPLETED",
  "PAYMENT.CAPTURE.COMPLETED",
  "CHECKOUT.ORDER.COMPLETED",
  "BILLING.SUBSCRIPTION.CREATED",
  "BILLING.SUBSCRIPTION.ACTIVATED"
];
function verifyWebhookSignature(headers, body, webhookId) {
  try {
    const transmissionId = headers["paypal-transmission-id"];
    const transmissionTime = headers["paypal-transmission-time"];
    const certUrl = headers["paypal-cert-url"];
    const authAlgo = headers["paypal-auth-algo"];
    const transmissionSig = headers["paypal-transmission-sig"];
    if (!transmissionId || !transmissionTime || !transmissionSig) {
      console.warn("Missing required PayPal webhook headers");
      return false;
    }
    console.log("Webhook verification attempted:", {
      transmissionId,
      transmissionTime,
      authAlgo,
      certUrl
    });
    const isProduction = process.env.PAYPAL_MODE === "live";
    if (isProduction) {
      console.error("Production mode requires full signature verification - rejecting webhook");
      return false;
    }
    return true;
  } catch (error) {
    console.error("Webhook verification error:", error);
    return false;
  }
}
function extractCustomerEmail(resource) {
  return resource.payer?.email_address || resource.payer?.payer_info?.email || resource.subscriber?.email_address || resource.subscriber?.payer?.email_address || "unknown@example.com";
}
function determinePlan(amount) {
  const value = parseFloat(amount);
  if (value === 0) return "Free";
  if (value === 29 || value === 29) return "Pro";
  return "Enterprise";
}
async function sendDeliveryNotification(orderData) {
  try {
    const response = await fetch(`${process.env.URL || "https://consciousnessrevolution.io"}/.netlify/functions/repopilot-delivery-notification`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(orderData)
    });
    if (!response.ok) {
      console.error("Failed to send delivery notification:", response.statusText);
      return false;
    }
    console.log("Delivery notification sent successfully");
    return true;
  } catch (error) {
    console.error("Delivery notification error:", error);
    return false;
  }
}
async function sendWelcomeEmail(orderData) {
  try {
    const response = await fetch(`${process.env.URL || "https://consciousnessrevolution.io"}/.netlify/functions/send-repopilot-welcome`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(orderData)
    });
    if (!response.ok) {
      console.error("Failed to send welcome email:", response.statusText);
      return false;
    }
    console.log("Welcome email sent successfully");
    return true;
  } catch (error) {
    console.error("Welcome email error:", error);
    return false;
  }
}
async function handler(event, context) {
  console.log("RepoPilot PayPal Webhook received");
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body);
    const headers = event.headers;
    console.log("Webhook event type:", body.event_type);
    console.log("Webhook body:", JSON.stringify(body, null, 2));
    const webhookId = process.env.PAYPAL_WEBHOOK_ID;
    if (webhookId) {
      const isValid = verifyWebhookSignature(headers, body, webhookId);
      if (!isValid) {
        console.error("Invalid webhook signature");
        return {
          statusCode: 401,
          body: JSON.stringify({ error: "Invalid signature" })
        };
      }
    }
    const eventType = body.event_type;
    if (!RELEVANT_EVENTS.includes(eventType)) {
      console.log("Ignoring event type:", eventType);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "Event type ignored" })
      };
    }
    const resource = body.resource;
    const customerEmail = extractCustomerEmail(resource);
    const amount = resource.amount?.value || resource.amount?.total || resource.plan?.payment_definitions?.[0]?.amount?.value || "29.00";
    const currency = resource.amount?.currency_code || "USD";
    const transactionId = resource.id || body.id || "unknown";
    const plan = determinePlan(amount);
    const orderData = {
      plan,
      email: customerEmail,
      amount: parseFloat(amount),
      currency,
      orderId: transactionId,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      eventType
    };
    console.log("Processing order:", orderData);
    const deliveryNotificationSent = await sendDeliveryNotification(orderData);
    const welcomeEmailSent = await sendWelcomeEmail(orderData);
    console.log("Autonomous delivery results:", {
      deliveryNotificationSent,
      welcomeEmailSent,
      orderData
    });
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        message: "RepoPilot webhook processed",
        transactionId,
        deliveryNotificationSent,
        welcomeEmailSent
      })
    };
  } catch (error) {
    console.error("Webhook processing error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
