var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/stripe-webhook-v2.mjs
var stripe_webhook_v2_exports = {};
__export(stripe_webhook_v2_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(stripe_webhook_v2_exports);
var import_stripe = __toESM(require("stripe"), 1);
var import_supabase_js = require("@supabase/supabase-js");
var stripe = new import_stripe.default(process.env.STRIPE_SECRET_KEY);
function getSupabase() {
  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    return (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
  }
  return null;
}
async function updateArayaSubscriptionStatus(email, status, subscriptionId = null, customerId = null) {
  const supabase = getSupabase();
  if (!supabase || !email) {
    console.log("Cannot update ARAYA status - missing Supabase or email");
    return null;
  }
  try {
    const { data: existingProfile } = await supabase.from("araya_profiles").select("id, email").eq("email", email.toLowerCase()).single();
    const updateData = {
      subscription_status: status,
      subscription_updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (subscriptionId) {
      updateData.stripe_subscription_id = subscriptionId;
    }
    if (customerId) {
      updateData.stripe_customer_id = customerId;
    }
    if (existingProfile) {
      const { data, error } = await supabase.from("araya_profiles").update(updateData).eq("email", email.toLowerCase()).select();
      if (error) throw error;
      console.log("Updated ARAYA profile subscription status:", email, status);
      return data;
    } else {
      const { data, error } = await supabase.from("araya_profiles").insert({
        email: email.toLowerCase(),
        ...updateData,
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      }).select();
      if (error) throw error;
      console.log("Created ARAYA profile with subscription:", email, status);
      return data;
    }
  } catch (error) {
    console.error("Failed to update ARAYA subscription status:", error);
    return null;
  }
}
var ARAYA_PRODUCT_ID = "prod_TjA91iP5kaKFrV";
function subscriptionContainsAraya(subscription) {
  if (!subscription.items?.data) return false;
  return subscription.items.data.some(
    (item) => item.price?.product === ARAYA_PRODUCT_ID || item.plan?.product === ARAYA_PRODUCT_ID
  );
}
async function getCustomerEmail(customerId) {
  if (!customerId) return null;
  try {
    const customer = await stripe.customers.retrieve(customerId);
    return customer.email;
  } catch (error) {
    console.error("Failed to retrieve customer:", error);
    return null;
  }
}
async function recordContribution(foundationId, type, metadata = {}) {
  if (!foundationId) return null;
  try {
    const response = await fetch(
      `${process.env.URL || "https://conciousnessrevolution.io"}/.netlify/functions/update-contribution`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          foundation_id: foundationId,
          contribution_type: type,
          metadata
        })
      }
    );
    return await response.json();
  } catch (error) {
    console.error("Failed to record contribution:", error);
    return null;
  }
}
async function handler(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const sig = event.headers["stripe-signature"];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      webhookSecret
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: `Webhook Error: ${err.message}` })
    };
  }
  switch (stripeEvent.type) {
    case "checkout.session.completed": {
      const session = stripeEvent.data.object;
      const metadata = session.metadata || {};
      console.log("Payment successful for session:", session.id);
      console.log("Customer email:", session.customer_details?.email);
      console.log("Amount total:", session.amount_total);
      const customerEmail = session.customer_details?.email;
      const customerName = session.customer_details?.name || "Consciousness Revolutionary";
      const amountPaid = session.amount_total ? (session.amount_total / 100).toFixed(2) : "0.00";
      const currency = session.currency?.toUpperCase() || "USD";
      if (metadata.seller_foundation_id) {
        console.log("Recording marketplace sale contribution for seller:", metadata.seller_foundation_id);
        const contributionResult = await recordContribution(
          metadata.seller_foundation_id,
          "marketplace_sale",
          {
            creation_id: metadata.creation_id,
            amount_cents: session.amount_total,
            buyer_email: customerEmail
          }
        );
        console.log("Contribution recorded:", contributionResult);
        if (metadata.has_upstream === "true") {
          await processDownstreamContributions(metadata.creation_id, session.amount_total);
        }
      }
      if (customerEmail) {
        try {
          const emailResponse = await fetch(
            `${process.env.URL || "https://conciousnessrevolution.io"}/.netlify/functions/send-welcome-email`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                email: customerEmail,
                name: customerName,
                amount: amountPaid,
                currency,
                sessionId: session.id,
                productName: metadata.product_name || "Consciousness Revolution Membership"
              })
            }
          );
          const emailResult = await emailResponse.json();
          console.log("Email send result:", emailResult);
        } catch (emailError) {
          console.error("Failed to send welcome email:", emailError);
        }
      }
      break;
    }
    case "customer.subscription.created": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription created:", subscription.id);
      if (subscriptionContainsAraya(subscription)) {
        const email = await getCustomerEmail(subscription.customer);
        if (email) {
          await updateArayaSubscriptionStatus(
            email,
            subscription.status,
            // 'active', 'trialing', etc.
            subscription.id,
            subscription.customer
          );
          console.log("ARAYA subscription activated for:", email);
        }
      }
      break;
    }
    case "customer.subscription.updated": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription updated:", subscription.id, "Status:", subscription.status);
      if (subscriptionContainsAraya(subscription)) {
        const email = await getCustomerEmail(subscription.customer);
        if (email) {
          await updateArayaSubscriptionStatus(
            email,
            subscription.status,
            // 'active', 'past_due', 'canceled', etc.
            subscription.id,
            subscription.customer
          );
          console.log("ARAYA subscription status synced:", email, subscription.status);
        }
      }
      break;
    }
    case "customer.subscription.deleted": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription cancelled:", subscription.id);
      if (subscriptionContainsAraya(subscription)) {
        const email = await getCustomerEmail(subscription.customer);
        if (email) {
          await updateArayaSubscriptionStatus(
            email,
            "canceled",
            subscription.id,
            subscription.customer
          );
          console.log("ARAYA subscription canceled for:", email);
        }
      }
      break;
    }
    case "invoice.paid": {
      const invoice = stripeEvent.data.object;
      console.log("Invoice paid:", invoice.id);
      break;
    }
    case "invoice.payment_failed": {
      const invoice = stripeEvent.data.object;
      console.log("Invoice payment failed:", invoice.id);
      break;
    }
    default:
      console.log(`Unhandled event type: ${stripeEvent.type}`);
  }
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ received: true })
  };
}
async function processDownstreamContributions(creationId, grossAmountCents) {
  const supabase = getSupabase();
  if (!supabase || !creationId) return;
  try {
    const { data: lineage } = await supabase.from("creation_lineage").select(`
                parent_creation_id,
                parent_foundation_id,
                builder_creations!parent_creation_id(downstream_share_pct)
            `).eq("child_creation_id", creationId);
    for (const parent of lineage || []) {
      if (!parent.parent_foundation_id) continue;
      console.log("Recording downstream contribution for:", parent.parent_foundation_id);
      await recordContribution(
        parent.parent_foundation_id,
        "downstream_derivative",
        {
          derived_creation_id: creationId,
          original_creation_id: parent.parent_creation_id,
          gross_amount_cents: grossAmountCents
        }
      );
    }
  } catch (error) {
    console.error("Failed to process downstream contributions:", error);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
