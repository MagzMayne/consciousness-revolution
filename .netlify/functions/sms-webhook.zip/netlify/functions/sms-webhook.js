var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/sms-webhook.mjs
var sms_webhook_exports = {};
__export(sms_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sms_webhook_exports);
var import_supabase_js = require("@supabase/supabase-js");

// netlify/functions/utils/security.mjs
var import_crypto = __toESM(require("crypto"), 1);
var ALLOWED_ORIGINS = [
  "https://consciousnessrevolution.io",
  "https://www.consciousnessrevolution.io",
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "http://localhost:8888",
  "http://localhost:3000",
  "http://127.0.0.1:8888"
];
function getSecureCORSHeaders(origin) {
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    // 24 hours
    "Content-Type": "application/json",
    // Security headers
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
  };
}
var rateLimitStore = /* @__PURE__ */ new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of rateLimitStore.entries()) {
    if (now > record.resetAt + 6e4) {
      rateLimitStore.delete(key);
    }
  }
}, 3e5);
function sanitizeString(input, maxLength = 1e3) {
  if (!input || typeof input !== "string") return "";
  let sanitized = input.replace(/\0/g, "");
  sanitized = sanitized.trim();
  if (sanitized.length > maxLength) {
    sanitized = sanitized.substring(0, maxLength);
  }
  return sanitized;
}
function anonymizeIP(ip) {
  if (!ip) return null;
  if (ip.includes(".")) {
    const parts = ip.split(".");
    if (parts.length === 4) {
      return `${parts[0]}.${parts[1]}.${parts[2]}.0`;
    }
  }
  if (ip.includes(":")) {
    const parts = ip.split(":");
    if (parts.length >= 4) {
      return `${parts[0]}:${parts[1]}:${parts[2]}:${parts[3]}::`;
    }
  }
  return null;
}
function pseudonymize(identifier, salt = process.env.ANONYMIZATION_SALT || "default-salt") {
  if (!identifier) return null;
  return import_crypto.default.createHmac("sha256", salt).update(identifier).digest("hex").substring(0, 16);
}
var ENCRYPTION_KEY = process.env.DATA_ENCRYPTION_KEY;
var SENSITIVE_FIELDS = ["password", "token", "secret", "key", "authorization", "cookie"];
function redactSensitiveData(data) {
  if (!data || typeof data !== "object") return data;
  const redacted = Array.isArray(data) ? [...data] : { ...data };
  for (const key in redacted) {
    const lowerKey = key.toLowerCase();
    if (SENSITIVE_FIELDS.some((field) => lowerKey.includes(field))) {
      redacted[key] = "[REDACTED]";
    } else if (typeof redacted[key] === "object" && redacted[key] !== null) {
      redacted[key] = redactSensitiveData(redacted[key]);
    }
  }
  return redacted;
}
function secureLog(message, data = {}) {
  console.log(message, redactSensitiveData(data));
}

// netlify/functions/sms-webhook.mjs
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
var TEAM_NUMBERS = {
  "+15094968855": { name: "Commander", priority: "critical" },
  "+14256289888": { name: "Maggie", priority: "high" },
  "+12674439742": { name: "Josh S", priority: "high" },
  "+13463083078": { name: "Teddy", priority: "high" },
  "+15094963855": { name: "Josh B", priority: "normal" }
};
var handler = async (event, context) => {
  const origin = event.headers.origin || event.headers.Origin || "";
  const headers = {
    "Content-Type": "text/xml",
    ...getSecureCORSHeaders(origin)
  };
  if (event.httpMethod === "GET") {
    return {
      statusCode: 200,
      headers: { "Content-Type": "text/plain" },
      body: "SMS Webhook Active - Consciousness Revolution"
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: '<?xml version="1.0" encoding="UTF-8"?><Response><Message>Method not allowed</Message></Response>'
    };
  }
  try {
    const params = new URLSearchParams(event.body);
    const from = params.get("From");
    const body = params.get("Body");
    const messageSid = params.get("MessageSid");
    const numMedia = parseInt(params.get("NumMedia") || "0");
    if (!from || !body) {
      return {
        statusCode: 400,
        headers,
        body: '<?xml version="1.0" encoding="UTF-8"?><Response><Message>Missing required fields</Message></Response>'
      };
    }
    const sanitizedBody = sanitizeString(body, 1e3);
    const lowerBody = sanitizedBody.toLowerCase();
    let messageType = "general";
    let priority = "normal";
    if (lowerBody.includes("bug") || lowerBody.includes("broken") || lowerBody.includes("error")) {
      messageType = "bug";
      priority = "high";
    } else if (lowerBody.includes("urgent") || lowerBody.includes("critical") || lowerBody.includes("emergency")) {
      messageType = "urgent";
      priority = "critical";
    } else if (lowerBody.includes("idea") || lowerBody.includes("suggest") || lowerBody.includes("feature")) {
      messageType = "idea";
    } else if (lowerBody.includes("help") || lowerBody.includes("how do") || lowerBody.includes("?")) {
      messageType = "question";
    }
    const teamMember = TEAM_NUMBERS[from];
    if (teamMember) {
      if (teamMember.priority === "critical" && priority === "normal") {
        priority = "high";
      }
    }
    const record = {
      from_number: pseudonymize(from),
      // Pseudonymized for storage
      from_number_last4: from.slice(-4),
      // Keep last 4 digits for support
      message: sanitizedBody,
      message_sid: messageSid,
      message_type: messageType,
      priority,
      has_media: numMedia > 0,
      sender_name: teamMember?.name || "Unknown",
      processed: false,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      ip_address: anonymizeIP(clientIP)
    };
    let stored = false;
    if (SUPABASE_URL && SUPABASE_KEY) {
      try {
        const supabase = (0, import_supabase_js.createClient)(SUPABASE_URL, SUPABASE_KEY);
        const { data, error } = await supabase.from("sms_inbox").insert([record]);
        if (!error) {
          stored = true;
        } else {
          secureLog("Supabase error", { error: error.message });
        }
      } catch (e) {
        secureLog("Supabase connection error", { error: e.message });
      }
    }
    let responseMessage;
    if (messageType === "bug") {
      responseMessage = "Bug received! Team has been notified.";
    } else if (messageType === "urgent") {
      responseMessage = "URGENT message received! Escalating immediately.";
    } else if (messageType === "idea") {
      responseMessage = "Great idea! Added to our feature backlog.";
    } else if (messageType === "question") {
      responseMessage = "Question received! Someone will respond shortly.";
    } else {
      responseMessage = "Message received! Thanks for reaching out.";
    }
    secureLog("SMS received", {
      from: teamMember?.name || "Unknown",
      type: messageType,
      priority,
      stored,
      preview: sanitizedBody.substring(0, 50)
    });
    const twiml = '<?xml version="1.0" encoding="UTF-8"?><Response><Message>' + responseMessage + "</Message></Response>";
    return {
      statusCode: 200,
      headers,
      body: twiml
    };
  } catch (error) {
    secureLog("SMS webhook error", { error: error.message });
    return {
      statusCode: 500,
      headers,
      body: '<?xml version="1.0" encoding="UTF-8"?><Response><Message>Error processing message.</Message></Response>'
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
