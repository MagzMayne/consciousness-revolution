// netlify/functions/araya-chat-admin-patch.mjs
var ADMIN_PASSPHRASE = process.env.ARAYA;
function detectAdminMode(message2) {
  if (!message2 || !ADMIN_PASSPHRASE) {
    return { isAdmin: false, cleanedMessage: message2 };
  }
  const hasPassphrase = message2.includes(ADMIN_PASSPHRASE);
  if (hasPassphrase) {
    const cleanedMessage = message2.replace(ADMIN_PASSPHRASE, "").trim();
    console.log("[ADMIN AUTH] Admin passphrase detected - elevating privileges");
    return { isAdmin: true, cleanedMessage };
  }
  return { isAdmin: false, cleanedMessage: message2 };
}
var adminCheck = detectAdminMode(message);
var isAdmin = adminCheck.isAdmin;
var processedMessage = adminCheck.cleanedMessage;
var effectiveMode = isAdmin ? "admin" : mode;
if (isAdmin) {
  console.log("[ADMIN MODE] Passphrase authenticated - admin privileges granted");
  console.log("[ADMIN MODE] Original message length:", message.length);
  console.log("[ADMIN MODE] Cleaned message length:", processedMessage.length);
}
