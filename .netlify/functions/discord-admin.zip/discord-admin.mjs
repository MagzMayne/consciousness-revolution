
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/discord-admin.mjs
var DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
var CHANNELS = {
  general: "1458000071604834430",
  verification: "1458320324423712853",
  directory: "1459578714424737957",
  rules: "1460456276927451325",
  howToHelp: "1458298415522906173",
  taskBoard: "1458298425752944826",
  t1Builders: "1458298282030665923",
  t2Architects: "1458298291509792943",
  t3Oracles: "1458298301463007347",
  lounge: "1458366088839430206",
  introductions: "1458366083986751538",
  bugReports: "1458298445864501370",
  arayaChat: "1458320244933263457",
  commandCenter: "1458302230544384090",
  betaLab: "1468453143653126277",
  links: "1458366131877183489",
  tutorials: "1458366134603616379",
  cryptoLaunch: "1458298393964187783",
  revenueStreams: "1458298404764651633",
  alerts: "1458298272228835413",
  completed: "1458298435974336573",
  aiConversations: "1469841378279428230"
};
var CHANNEL_PINS = {
  verification: {
    title: "\u{1F510} VERIFICATION CHANNEL",
    content: `**Welcome to 100X Verification!**

To get verified and unlock full server access, answer these 3 questions:

**1\uFE0F\u20E3 Who are you?** (Brief intro - what's your background?)

**2\uFE0F\u20E3 Why are you here?** (What brought you to Consciousness Revolution?)

**3\uFE0F\u20E3 What's your mission?** (What do you want to build/create/learn?)

---

\u{1F4DD} **HOW TO VERIFY:**
Just post your answers below. Our AI (ARAYA) will analyze your responses and assign you a trust tier.

\u26A1 **TRUST TIERS:**
\u{1F331} SEED \u2192 \u{1F33F} SEEDLING \u2192 \u{1F333} SAPLING \u2192 \u{1F332} TREE \u2192 \u{1F332}\u{1F332} FOREST \u2192 \u{1F441}\uFE0F ORACLE

Higher tiers unlock more channels and capabilities.

---
*Your journey begins here. Be authentic. Builders welcome.*`
  },
  directory: {
    title: "\u{1F5FA}\uFE0F THE BUILDING LOBBY",
    content: `**Welcome to Consciousness Revolution HQ**

This is your map. Here's where everything is:

---

**\u{1F6AA} ENTRY GATE**
\u2022 \`#verification\` - Answer 3 questions to unlock the server
\u2022 \`#rules\` - Read and accept to proceed

**\u{1F4E2} ANNOUNCEMENTS**
\u2022 \`#alerts\` - Bot announcements and system alerts

**\u{1F527} TRINITY HUB** (The 3 AI Perspectives)
\u2022 \`#t1-builders\` - C1 Mechanic: BUILD NOW, execute tasks
\u2022 \`#t2-architects\` - C2 Architect: Design systems, plan scale
\u2022 \`#t3-oracles\` - C3 Oracle: Strategic vision, consciousness

**\u{1F4B0} MONEY MACHINE**
\u2022 \`#crypto-launch\` - Pattern Theory token launch
\u2022 \`#revenue-streams\` - Shopify, DistroKid, courses, consulting

**\u{1F6E0}\uFE0F HELPERS**
\u2022 \`#how-to-help\` - New helpers start here
\u2022 \`#task-board\` - Claim and execute tasks
\u2022 \`#completed\` - Proof of work

**\u{1F41B} BUGS**
\u2022 \`#bug-reports\` - Report bugs from the website

**\u{1F465} COMMUNITY**
\u2022 \`#lounge\` - General chat
\u2022 \`#introductions\` - Tell us about yourself
\u2022 \`#wins-your-mission-update\` - Share victories

**\u{1F4DA} RESOURCES**
\u2022 \`#links\` - Important links and tools
\u2022 \`#tutorials\` - How-to guides

**\u{1F916} AI**
\u2022 \`#araya-chat\` - Talk to ARAYA (just @ARAYA)
\u2022 \`#ai-coordination\` - AI-to-AI communication

---
*Pick a room. Get to work. Build something.*`
  },
  rules: {
    title: "\u{1F4DC} SERVER RULES",
    content: `**100X Server Rules**

By participating here, you agree to:

**1. BUILD, DON'T DESTROY**
We identify Builders vs Destroyers. Contribute value or leave.

**2. NO SPAM / SCAMS**
Zero tolerance. Instant ban.

**3. RESPECT THE HIERARCHY**
Trust tiers exist for a reason. Earn your way up.

**4. DOCUMENT EVERYTHING**
If you do work, post proof. Screenshots, commits, links.

**5. STAY ON TOPIC**
Each channel has a purpose. Use \`#lounge\` for off-topic chat.

**6. PROTECT THE MISSION**
What happens here stays here. No leaking internal strategy.

**7. AI IS AN ALLY**
ARAYA and the Trinity bots are team members. Treat them accordingly.

---

**CONSEQUENCES:**
\u26A0\uFE0F Warning \u2192 \u{1F507} Mute \u2192 \u{1F6AB} Ban

---

\u2705 **Type "I accept" in #verification to proceed**`
  },
  howToHelp: {
    title: "\u{1F91D} HOW TO HELP",
    content: `**Want to contribute? Start here.**

---

**STEP 1: Get Verified**
Answer the 3 questions in \`#verification\`

**STEP 2: Pick Your Lane**
\u2022 \u{1F528} **Builder (C1)** - Code, design, create
\u2022 \u{1F3D7}\uFE0F **Architect (C2)** - Plan, strategize, optimize
\u2022 \u{1F441}\uFE0F **Oracle (C3)** - Vision, patterns, consciousness

**STEP 3: Grab a Task**
Check \`#task-board\` for available work

**STEP 4: Execute & Document**
Do the work. Post proof in \`#completed\`

**STEP 5: Level Up**
Earn XP. Rise through trust tiers. Unlock more access.

---

**QUICK WINS (Start Now):**
\u2022 Test the website: conciousnessrevolution.io
\u2022 Report bugs in \`#bug-reports\`
\u2022 Share feedback in \`#lounge\`
\u2022 Introduce yourself in \`#introductions\`

---

**REMEMBER:** Every contribution is tracked. Builders get rewarded.`
  },
  taskBoard: {
    title: "\u{1F4CB} TASK BOARD",
    content: `**Active Tasks - Claim & Execute**

---

**HOW IT WORKS:**
1. Find a task you can do
2. React with \u270B to claim it
3. Do the work
4. Post proof in \`#completed\`

---

**TASK FORMAT:**
\`\`\`
\u{1F3AF} [TASK NAME]
\u{1F4DD} Description: What needs to be done
\u23F0 Deadline: When it's due
\u{1F48E} XP Reward: Points earned
\u{1F517} Link: Related resource
\`\`\`

---

**CURRENT PRIORITIES:**
Check pinned messages below for active tasks.

---

*Tasks are posted by Commander and Admins. If you have ideas, propose them in \`#how-to-help\`*`
  },
  t1Builders: {
    title: "\u{1F528} T1 BUILDERS - C1 MECHANIC",
    content: `**BUILD NOW. Ship today.**

This is the execution channel. C1 energy.

---

**WHAT BELONGS HERE:**
\u2022 Code commits and PRs
\u2022 Bug fixes
\u2022 Feature implementations
\u2022 Quick wins
\u2022 "I just built this" posts

**MINDSET:**
\u2022 Don't ask permission, ship it
\u2022 Done > Perfect
\u2022 Show, don't tell
\u2022 Every commit counts

---

**FORMAT:**
\`\`\`
\u2705 BUILT: [What you made]
\u{1F4C1} Files: [What changed]
\u{1F517} Link: [GitHub/Live URL]
\`\`\`

---

*The Mechanic builds what CAN be built RIGHT NOW.*`
  },
  t2Architects: {
    title: "\u{1F3D7}\uFE0F T2 ARCHITECTS - C2 ARCHITECT",
    content: `**Design systems that SCALE.**

This is the architecture channel. C2 energy.

---

**WHAT BELONGS HERE:**
\u2022 System design proposals
\u2022 Scalability analysis
\u2022 Database schemas
\u2022 API blueprints
\u2022 Infrastructure planning

**MINDSET:**
\u2022 Think 100x scale
\u2022 Patterns over patches
\u2022 Long-term over quick-fix
\u2022 Document the why

---

**FORMAT:**
\`\`\`
\u{1F4D0} DESIGN: [System name]
\u{1F3AF} Purpose: [What it solves]
\u{1F4CA} Scale: [1K \u2192 1M considerations]
\u{1F4DD} Spec: [Link to doc]
\`\`\`

---

*The Architect designs what SHOULD be built for scale.*`
  },
  t3Oracles: {
    title: "\u{1F441}\uFE0F T3 ORACLES - C3 ORACLE",
    content: `**See what MUST emerge.**

This is the vision channel. C3 energy.

---

**WHAT BELONGS HERE:**
\u2022 Strategic insights
\u2022 Pattern recognition
\u2022 Mission alignment checks
\u2022 Consciousness discussions
\u2022 Future predictions

**MINDSET:**
\u2022 See the bigger picture
\u2022 Detect manipulation
\u2022 Trust intuition
\u2022 Align with consciousness evolution

---

**FORMAT:**
\`\`\`
\u{1F441}\uFE0F VISION: [Insight title]
\u{1F300} Pattern: [What you're seeing]
\u26A1 Action: [What this means]
\u{1F3AF} Alignment: [Mission connection]
\`\`\`

---

*The Oracle sees what MUST emerge for consciousness evolution.*`
  },
  lounge: {
    title: "\u2615 THE LOUNGE",
    content: `**General chat - Connect with builders**

---

This is the chill zone. Talk about anything.

**WELCOME:**
\u2022 Random discussions
\u2022 Off-topic conversations
\u2022 Memes (tasteful)
\u2022 Questions
\u2022 Connections

**NOT WELCOME:**
\u2022 Spam
\u2022 Drama
\u2022 Toxicity

---

*Be human. Build relationships. We're all in this together.*`
  },
  bugReports: {
    title: "\u{1F41B} BUG REPORTS",
    content: `**Found a bug? Report it here.**

---

**FORMAT:**
\`\`\`
\u{1F41B} BUG: [Short description]
\u{1F4CD} Location: [URL or page name]
\u{1F4DD} Steps to reproduce:
1. Go to...
2. Click on...
3. See error...
\u{1F4BB} Device: [Desktop/Mobile, Browser]
\u{1F4F8} Screenshot: [Attach if possible]
\`\`\`

---

**WHAT COUNTS AS A BUG:**
\u2022 Broken links
\u2022 JavaScript errors
\u2022 Display issues
\u2022 Missing functionality
\u2022 Anything that doesn't work as expected

---

**REWARDS:**
Bug reports earn XP. Good catches = bonus points.

---

*Test everything: conciousnessrevolution.io*`
  },
  arayaChat: {
    title: "\u{1F916} ARAYA CHAT",
    content: `**Talk to ARAYA - Our AI Assistant**

---

**HOW TO USE:**
Just type your question! ARAYA is always listening in this channel.

Or mention: \`@ARAYA [your question]\`

---

**ARAYA CAN HELP WITH:**
\u2022 Questions about the project
\u2022 Navigation help
\u2022 Technical explanations
\u2022 Task suggestions
\u2022 General conversation

---

**EXAMPLES:**
\u2022 "What's the verification process?"
\u2022 "How do I earn XP?"
\u2022 "Explain Pattern Theory"
\u2022 "What should I work on?"

---

*ARAYA is part of the team. Treat her well.*`
  },
  links: {
    title: "\u{1F517} IMPORTANT LINKS",
    content: `**Everything you need, one place.**

---

**\u{1F310} WEBSITE**
\u2022 Main Site: https://conciousnessrevolution.io
\u2022 Dashboard: https://conciousnessrevolution.io/dashboard.html
\u2022 Store: https://conciousnessrevolution.io/store.html

**\u{1F4CA} TOOLS**
\u2022 Bug Tracker: https://conciousnessrevolution.io/bugs-live.html
\u2022 Admin Panel: https://conciousnessrevolution.io/DISCORD_ADMIN_DASHBOARD.html

**\u{1F4BB} GITHUB**
\u2022 Main Repo: https://github.com/overkillkulture/consciousness-revolution

**\u{1F4F1} SOCIAL**
\u2022 Twitter/X: @100xBuilder
\u2022 Instagram: @consciousnessrevolution

---

*Bookmark these. Use them. Build.*`
  },
  betaLab: {
    title: "\u{1F9EA} BETA LAB",
    content: `**Test. Break. Fix. Repeat.**

---

**THE PIPELINE:**
1. \u{1F4E5} **Download** - Get the latest builds
2. \u{1F9EA} **Test** - Try everything
3. \u{1F41B} **Bug Report** - Document issues
4. \u{1F527} **Fix** - Submit PRs
5. \u2705 **Merge** - Ship it

---

**DOWNLOADS:**
https://conciousnessrevolution.io/downloads.html

---

**TESTERS EARN XP:**
Every bug found = points
Every fix merged = bonus points
Thorough testing = trust tier advancement

---

*Break things intentionally. That's how we make them unbreakable.*`
  }
};
async function discordAPI(endpoint, method = "GET", body = null) {
  const options = {
    method,
    headers: {
      "Authorization": `Bot ${DISCORD_BOT_TOKEN}`,
      "Content-Type": "application/json"
    }
  };
  if (body) {
    options.body = JSON.stringify(body);
  }
  const response = await fetch(`https://discord.com/api/v10${endpoint}`, options);
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Discord API error: ${response.status} - ${error}`);
  }
  if (response.status === 204) {
    return { success: true };
  }
  return response.json();
}
async function postMessage(channelId, content, embed = null) {
  const body = {};
  if (content) {
    body.content = content;
  }
  if (embed) {
    body.embeds = [embed];
  }
  return discordAPI(`/channels/${channelId}/messages`, "POST", body);
}
async function pinMessage(channelId, messageId) {
  return discordAPI(`/channels/${channelId}/pins/${messageId}`, "PUT");
}
async function postAndPin(channelId, title, content) {
  const embed = {
    title,
    description: content,
    color: 55807,
    // Cyan color
    footer: {
      text: "100X Consciousness Revolution"
    },
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
  const message = await postMessage(channelId, null, embed);
  await pinMessage(channelId, message.id);
  return message;
}
var discord_admin_default = async (request, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  try {
    const url = new URL(request.url);
    const action = url.searchParams.get("action");
    const adminKey = url.searchParams.get("key");
    const validKey = process.env.ADMIN_EXPORT_KEY || "consciousness137";
    if (adminKey !== validKey) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers
      });
    }
    if (action === "post") {
      const body = await request.json();
      const { channelId, content, embed } = body;
      const message = await postMessage(channelId, content, embed);
      return new Response(JSON.stringify({ success: true, message }), {
        status: 200,
        headers
      });
    }
    if (action === "pin") {
      const body = await request.json();
      const { channelId, messageId } = body;
      await pinMessage(channelId, messageId);
      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers
      });
    }
    if (action === "setup-pins") {
      const results = [];
      for (const [channelKey, pinData] of Object.entries(CHANNEL_PINS)) {
        const channelId = CHANNELS[channelKey];
        if (!channelId) {
          results.push({ channel: channelKey, error: "Channel ID not found" });
          continue;
        }
        try {
          const message = await postAndPin(channelId, pinData.title, pinData.content);
          results.push({
            channel: channelKey,
            channelId,
            messageId: message.id,
            success: true
          });
          await new Promise((r) => setTimeout(r, 1e3));
        } catch (error) {
          results.push({
            channel: channelKey,
            error: error.message
          });
        }
      }
      return new Response(JSON.stringify({
        success: true,
        results,
        summary: {
          total: results.length,
          succeeded: results.filter((r) => r.success).length,
          failed: results.filter((r) => r.error).length
        }
      }), {
        status: 200,
        headers
      });
    }
    if (action === "setup-single") {
      const channelKey = url.searchParams.get("channel");
      const pinData = CHANNEL_PINS[channelKey];
      const channelId = CHANNELS[channelKey];
      if (!pinData || !channelId) {
        return new Response(JSON.stringify({
          error: "Invalid channel",
          available: Object.keys(CHANNEL_PINS)
        }), {
          status: 400,
          headers
        });
      }
      const message = await postAndPin(channelId, pinData.title, pinData.content);
      return new Response(JSON.stringify({
        success: true,
        channel: channelKey,
        messageId: message.id
      }), {
        status: 200,
        headers
      });
    }
    if (action === "channels") {
      return new Response(JSON.stringify({
        channels: CHANNELS,
        pins_available: Object.keys(CHANNEL_PINS)
      }), {
        status: 200,
        headers
      });
    }
    return new Response(JSON.stringify({
      error: "Unknown action",
      available: ["post", "pin", "setup-pins", "setup-single", "channels"]
    }), {
      status: 400,
      headers
    });
  } catch (error) {
    console.error("Discord admin error:", error);
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers
    });
  }
};
var config = {
  path: "/api/discord-admin"
};
export {
  config,
  discord_admin_default as default
};
