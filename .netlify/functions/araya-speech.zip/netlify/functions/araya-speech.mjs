
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/araya-speech.mjs
import OpenAI from "openai";
var openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
var WHISPER_LANGUAGES = {
  "en": "en",
  "es": "es",
  "zh": "zh",
  "tl": "tl",
  "vi": "vi",
  "ar": "ar",
  "fr": "fr",
  "hi": "hi",
  "pt": "pt",
  "ru": "ru",
  "ja": "ja",
  "de": "de",
  "ko": "ko",
  "it": "it",
  "nl": "nl",
  "pl": "pl"
};
var araya_speech_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "POST required" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  const startTime = Date.now();
  try {
    const contentType = req.headers.get("content-type") || "";
    let audioBuffer;
    let language = null;
    let filename = "audio.webm";
    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const audioFile2 = formData.get("audio");
      language = formData.get("language") || null;
      if (!audioFile2) {
        return new Response(JSON.stringify({ error: "audio file required" }), {
          status: 400,
          headers: { "Content-Type": "application/json" }
        });
      }
      audioBuffer = await audioFile2.arrayBuffer();
      filename = audioFile2.name || "audio.webm";
    } else if (contentType.includes("application/json")) {
      const body = await req.json();
      if (!body.audio) {
        return new Response(JSON.stringify({ error: "audio (base64) required" }), {
          status: 400,
          headers: { "Content-Type": "application/json" }
        });
      }
      const base64Data = body.audio.replace(/^data:audio\/\w+;base64,/, "");
      audioBuffer = Buffer.from(base64Data, "base64");
      language = body.language || null;
      filename = body.filename || "audio.webm";
    } else {
      audioBuffer = await req.arrayBuffer();
    }
    const audioFile = new File([audioBuffer], filename, {
      type: `audio/${filename.split(".").pop() || "webm"}`
    });
    const options = {
      file: audioFile,
      model: "whisper-1",
      response_format: "verbose_json",
      timestamp_granularities: ["word", "segment"]
    };
    if (language && WHISPER_LANGUAGES[language]) {
      options.language = WHISPER_LANGUAGES[language];
    }
    const transcription = await openai.audio.transcriptions.create(options);
    const result = {
      text: transcription.text,
      language: transcription.language,
      duration: transcription.duration,
      segments: transcription.segments?.map((seg) => ({
        start: seg.start,
        end: seg.end,
        text: seg.text
      })),
      words: transcription.words?.map((word) => ({
        word: word.word,
        start: word.start,
        end: word.end
      })),
      latencyMs: Date.now() - startTime
    };
    return new Response(JSON.stringify(result), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    console.error("[SPEECH] Error:", error);
    return new Response(JSON.stringify({
      error: "Speech recognition failed",
      details: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
};
var config = { path: "/api/araya-speech" };
export {
  config,
  araya_speech_default as default
};
