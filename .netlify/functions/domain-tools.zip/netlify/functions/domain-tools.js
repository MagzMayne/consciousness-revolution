var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/domain-tools.mjs
var domain_tools_exports = {};
__export(domain_tools_exports, {
  ACCESS_TIERS: () => ACCESS_TIERS,
  BUILDER_COCKPITS: () => BUILDER_COCKPITS,
  DISCORD_ROLE_MAPPING: () => DISCORD_ROLE_MAPPING,
  DOMAIN_TOOLS: () => DOMAIN_TOOLS,
  HELP_TRIGGERS: () => HELP_TRIGGERS,
  LEVEL_UNLOCKS: () => LEVEL_UNLOCKS,
  ONBOARDING_STEPS: () => ONBOARDING_STEPS,
  VERIFICATION_LEVELS: () => VERIFICATION_LEVELS,
  findDomainTools: () => findDomainTools,
  formatDomainResponse: () => formatDomainResponse,
  formatOnboardingResponse: () => formatOnboardingResponse,
  getAccessibleDomains: () => getAccessibleDomains,
  getBuilder: () => getBuilder,
  getBuildersInDomain: () => getBuildersInDomain,
  getHighestLevelFromRoles: () => getHighestLevelFromRoles,
  getLevelFromDiscordRole: () => getLevelFromDiscordRole,
  getNextSteps: () => getNextSteps,
  getUserLevel: () => getUserLevel,
  isOnboardingTrigger: () => isOnboardingTrigger
});
module.exports = __toCommonJS(domain_tools_exports);
var DOMAIN_TOOLS = {
  command: {
    name: "\u{1F3AF} COMMAND",
    level: "team",
    keywords: ["dashboard", "cockpit", "control", "status", "overview", "manage", "admin", "command"],
    tools: [
      { name: "Commander Dashboard", url: "/COMMANDER_DASHBOARD.html", desc: "Central mission control" },
      { name: "Team Cockpit", url: "/TEAM_COCKPIT.html", desc: "Team coordination hub" },
      { name: "Builder Cockpit", url: "/BUILDER_COCKPIT.html", desc: "Developer command center" },
      { name: "Project Health", url: "/PROJECT_HEALTH_DASHBOARD.html", desc: "Project status overview" },
      { name: "Master Command", url: "/MASTER_COMMAND_CENTER.html", desc: "Full system control" }
    ]
  },
  build: {
    name: "\u{1F528} BUILD",
    level: "team",
    keywords: ["build", "create", "code", "developer", "make", "design", "project", "coding", "programmer", "engineer"],
    tools: [
      { name: "Builder Cockpit", url: "/BUILDER_COCKPIT.html", desc: "Developer dashboard" },
      { name: "DNA Builder Agreement", url: "/DNA_BUILDER_AGREEMENT.html", desc: "Join as a builder" },
      { name: "Command Bar", url: "/command-bar.html", desc: "Power user slash commands" },
      { name: "Araya Builder Mode", url: "/araya-chat.html?mode=builder", desc: "ARAYA with file edit powers" }
    ]
  },
  connect: {
    name: "\u{1F91D} CONNECT",
    level: "free",
    keywords: ["community", "people", "connect", "join", "help", "contribute", "talk", "team", "together", "share", "friend", "meet"],
    tools: [
      { name: "Araya Chat", url: "/araya-chat.html", desc: "Talk to ARAYA - your AI companion" },
      { name: "Consciousness Tools Hub", url: "/consciousness-tools.html", desc: "All tools in one place" },
      { name: "Team Dashboard", url: "/TEAM_DASHBOARD_HUB.html", desc: "Connect with the team" }
    ]
  },
  protect: {
    name: "\u2696\uFE0F PROTECT",
    level: "free",
    keywords: ["legal", "court", "case", "evidence", "custody", "divorce", "protect", "rights", "lawyer", "judge", "cps", "child", "document"],
    tools: [
      { name: "Case Builder", url: "/araya-chat.html", desc: "Build legal cases with AI - organize evidence, timelines" },
      { name: "Legal Cockpit", url: "/LEGAL_COCKPIT.html", desc: "Track and manage legal matters" },
      { name: "Legal Case Tracker", url: "/LEGAL_CASE_TRACKER.html", desc: "Case management system" }
    ]
  },
  grow: {
    name: "\u{1F4B0} GROW",
    level: "free",
    keywords: ["money", "pay", "business", "finance", "invest", "budget", "debt", "income", "job", "work", "career", "earn"],
    tools: [
      { name: "Budget Boss", url: "/BudgetBoss.html", desc: "Financial management" },
      { name: "Store", url: "/store.html", desc: "Consciousness Revolution marketplace" },
      { name: "Pricing", url: "/pricing.html", desc: "Service tiers" }
    ]
  },
  learn: {
    name: "\u{1F4DA} LEARN",
    level: "free",
    keywords: ["learn", "study", "research", "understand", "read", "book", "knowledge", "teach", "education", "explore", "discover", "how does"],
    tools: [
      { name: "Pattern Library", url: "/PATTERN_LIBRARY.html", desc: "Encyclopedia of manipulation patterns" },
      { name: "AI Tutorial", url: "/AI_TUTORIAL.html", desc: "Learn how AI works" },
      { name: "Seven Domains Dashboard", url: "/SEVEN_DOMAINS_DASHBOARD.html", desc: "Explore all 7 life domains" },
      { name: "GLYPH 12D System", url: "/GLYPH_TEST.html", desc: "Advanced pattern language research" }
    ]
  },
  transcend: {
    name: "\u2728 TRANSCEND",
    level: "free",
    keywords: ["transcend", "spiritual", "meditation", "frequency", "vibration", "energy", "higher", "consciousness", "awakening", "enlighten"],
    tools: [
      { name: "Consciousness Dashboard", url: "/CONSCIOUSNESS_DASHBOARD.html", desc: "Track consciousness expansion" },
      { name: "Life Journey Explorer", url: "/life-journey-explorer.html", desc: "Self-actualization path" },
      { name: "GLYPH 12D", url: "/GLYPH_TEST.html", desc: "Advanced dimensional patterns" }
    ]
  },
  awareness: {
    name: "\u{1F9E0} AWARENESS",
    level: "free",
    keywords: ["conscious", "aware", "mind", "think", "belief", "manipulate", "pattern", "truth", "reality", "detect", "see clearly", "gaslighting", "narcissist"],
    tools: [
      { name: "Pattern Library", url: "/PATTERN_LIBRARY.html", desc: "Learn all manipulation patterns" },
      { name: "Reality Check", url: "/REALITY_CHECK.html", desc: "Instant truth analysis for any claim" },
      { name: "Consciousness Trainer", url: "/CONSCIOUSNESS_TRAINER.html", desc: "Game to train pattern recognition" },
      { name: "Belief Checker", url: "/BELIEF_CHECKER.html", desc: "Examine if your beliefs are evidence-based" },
      { name: "Manipulation Immunity", url: "/MANIPULATION_IMMUNITY_TRACKER.html", desc: "Build resistance to manipulation" },
      { name: "Influence Detector", url: "/INFLUENCE_DETECTOR.html", desc: "Detect psychological tactics in ads/sales" },
      { name: "Conversation Analyzer", url: "/CONVERSATION_ANALYZER.html", desc: "Analyze conversations for manipulation" },
      { name: "Daily Check", url: "/DAILY_CONSCIOUSNESS_CHECK.html", desc: "Quick daily consciousness assessment" }
    ]
  },
  journey: {
    name: "\u{1F31F} JOURNEY",
    level: "free",
    keywords: ["journey", "path", "grow", "evolve", "progress", "self", "better", "transform", "change", "improve", "who am i", "find myself", "purpose"],
    tools: [
      { name: "Life Journey Explorer", url: "/life-journey-explorer.html", desc: "Discover YOUR unique path to becoming your best self" },
      { name: "Journey Dashboard", url: "/journey-dashboard.html", desc: "Track your personal evolution" },
      { name: "Timeline Projector", url: "/TIMELINE_PROJECTOR.html", desc: "Visualize decision outcomes" },
      { name: "Goal Alignment", url: "/GOAL_ALIGNMENT_CHECK.html", desc: "Verify goals align with consciousness" },
      { name: "Decision Matrix", url: "/DECISION_MATRIX.html", desc: "Weighted comparison for decisions" }
    ]
  },
  games: {
    name: "\u{1F3AE} GAMES",
    level: "free",
    keywords: ["game", "play", "fun", "entertainment", "poker", "casino", "bricks", "oasis"],
    tools: [
      { name: "OASIS", url: "/oasis.html", desc: "Immersive consciousness game world" },
      { name: "Building Bricks", url: "/building-bricks.html", desc: "Creative building game" },
      { name: "GPoker", url: "/GPoker.html", desc: "Poker game" },
      { name: "Consciousness Trainer", url: "/CONSCIOUSNESS_TRAINER.html", desc: "Gamified pattern recognition" }
    ]
  }
};
function findDomainTools(message) {
  const msgLower = message.toLowerCase();
  const matches = [];
  for (const [domainKey, domain] of Object.entries(DOMAIN_TOOLS)) {
    const keywordMatches = domain.keywords.filter((kw) => msgLower.includes(kw));
    if (keywordMatches.length > 0) {
      matches.push({
        domain: domain.name,
        level: domain.level,
        matchedKeywords: keywordMatches,
        tools: domain.tools
      });
    }
  }
  matches.sort((a, b) => b.matchedKeywords.length - a.matchedKeywords.length);
  return matches;
}
function formatDomainResponse(matches) {
  if (matches.length === 0) {
    return null;
  }
  let response = "Based on what you're looking for, here are some tools that might help:\n\n";
  matches.slice(0, 3).forEach((match) => {
    response += `**${match.domain}**
`;
    match.tools.forEach((tool) => {
      response += `\u2022 [${tool.name}](${tool.url}) - ${tool.desc}
`;
    });
    response += "\n";
  });
  return response;
}
var VERIFICATION_LEVELS = {
  LOBBY: { level: 0, name: "Lobby", xp: 0, access: "none", desc: "Just arrived - complete verification to begin" },
  SEEKER: { level: 1, name: "Seeker", xp: 0, access: "basic", desc: "Verified - exploring consciousness tools" },
  BUILDER: { level: 2, name: "Builder", xp: 50, access: "domains", desc: "Contributing to the mission" },
  CONTRIBUTOR: { level: 3, name: "Contributor", xp: 200, access: "edit", desc: "Active builder with edit powers" },
  ARCHITECT: { level: 4, name: "Architect", xp: 500, access: "full", desc: "Full system access" },
  ORACLE: { level: 5, name: "Oracle", xp: 2500, access: "admin", desc: "Admin powers - system guardian" }
};
var LEVEL_UNLOCKS = {
  0: [],
  // LOBBY - nothing yet
  1: ["connect", "protect", "grow", "learn", "transcend", "awareness", "journey", "games"],
  // SEEKER - free domains
  2: ["command", "build", "personal_cockpit"],
  // BUILDER - team domains + personal cockpit
  3: ["araya_edit", "file_access"],
  // CONTRIBUTOR - edit powers
  4: ["full_dashboard", "all_abilities"],
  // ARCHITECT - everything
  5: ["admin", "user_management"]
  // ORACLE - admin
};
var BUILDER_COCKPITS = {
  commander: {
    name: "Commander",
    role: "Mission Commander",
    cockpit: "/COMMANDER_COCKPIT.html",
    discord_id: null,
    xp: 0,
    domain: "1_COMMAND",
    access_tier: "PERSONAL"
  },
  tiger: {
    name: "Tiger",
    role: "Technical Builder",
    cockpit: "/OPERATOR_COCKPIT_TIGER.html",
    discord_id: null,
    // TODO: get from Discord
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  alex: {
    name: "Alex",
    role: "Designer Builder",
    cockpit: "/OPERATOR_COCKPIT_ALEX.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  agent_r: {
    name: "Agent R",
    role: "AI Agent Builder",
    cockpit: "/OPERATOR_COCKPIT_AGENT_R.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  toby: {
    name: "Toby",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_TOBY.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  josh_serrano: {
    name: "Josh Serrano",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_JOSH_SERRANO.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  },
  ryan: {
    name: "Ryan",
    role: "Builder",
    cockpit: "/OPERATOR_COCKPIT_RYAN.html",
    discord_id: null,
    xp: 0,
    domain: "2_BUILD",
    access_tier: "PERSONAL"
  }
};
var ACCESS_TIERS = {
  PERSONAL: {
    level: 0,
    name: "Personal",
    desc: "Individual builder cockpit - private workspace",
    scope: "single_user",
    edit_permissions: ["own_cockpit", "own_tasks"]
  },
  TEAM: {
    level: 1,
    name: "Team",
    desc: "Team command center - 6 builders coordination",
    scope: "team_members",
    edit_permissions: ["shared_docs", "team_tasks", "collaboration"]
  },
  PUBLIC: {
    level: 2,
    name: "Public",
    desc: "Public consciousness tools - consciousnessrevolution.io",
    scope: "all_users",
    edit_permissions: []
  }
};
function getBuilder(identifier) {
  if (!identifier) return null;
  const normalized = identifier.toLowerCase().replace(/[\s-]/g, "_");
  if (BUILDER_COCKPITS[normalized]) {
    return BUILDER_COCKPITS[normalized];
  }
  const builders = Object.values(BUILDER_COCKPITS);
  return builders.find(
    (b) => b.name.toLowerCase() === identifier.toLowerCase() || b.name.toLowerCase().replace(/[\s-]/g, "_") === normalized || b.discord_id === identifier
  );
}
function getBuildersInDomain(domainKey) {
  return Object.values(BUILDER_COCKPITS).filter((b) => b.domain === domainKey);
}
var DISCORD_ROLE_MAPPING = {
  "Lobby": { level: 0, xp: 0, verification: "LOBBY" },
  "Seeker": { level: 1, xp: 0, verification: "SEEKER" },
  "Builder": { level: 2, xp: 50, verification: "BUILDER" },
  "Contributor": { level: 3, xp: 200, verification: "CONTRIBUTOR" },
  "Architect": { level: 4, xp: 500, verification: "ARCHITECT" },
  "Oracle": { level: 5, xp: 2500, verification: "ORACLE" }
};
function getLevelFromDiscordRole(roleName) {
  const normalized = roleName.trim();
  return DISCORD_ROLE_MAPPING[normalized] || DISCORD_ROLE_MAPPING["Lobby"];
}
function getHighestLevelFromRoles(roleNames) {
  let highest = DISCORD_ROLE_MAPPING["Lobby"];
  roleNames.forEach((roleName) => {
    const level = getLevelFromDiscordRole(roleName);
    if (level.level > highest.level) {
      highest = level;
    }
  });
  return highest;
}
var ONBOARDING_STEPS = {
  LOBBY: [
    { step: 1, action: "verify", desc: "Complete verification quiz", url: "/verify.html" },
    { step: 2, action: "discord", desc: "Join Discord community", url: "https://discord.gg/consciousnessrevolution" }
  ],
  SEEKER: [
    { step: 1, action: "explore", desc: "Explore the 7 Domains", url: "/SEVEN_DOMAINS_DASHBOARD.html" },
    { step: 2, action: "talk", desc: "Chat with ARAYA about your interests", url: "/araya-chat.html" },
    { step: 3, action: "xp", desc: "Earn 50 XP to become a Builder", url: "/XP_TRACKER.html" }
  ],
  BUILDER: [
    { step: 1, action: "agreement", desc: "Sign Builder Agreement", url: "/DNA_BUILDER_AGREEMENT.html" },
    { step: 2, action: "cockpit", desc: "Set up your Builder Cockpit", url: "/BUILDER_COCKPIT.html" },
    { step: 3, action: "contribute", desc: "Make your first contribution", url: "/contribute.html" }
  ],
  CONTRIBUTOR: [
    { step: 1, action: "araya_builder", desc: "Try ARAYA Builder Mode", url: "/araya-chat.html?mode=builder" },
    { step: 2, action: "github", desc: "Connect GitHub for code contributions", url: "/github-connect.html" }
  ],
  ARCHITECT: [
    { step: 1, action: "full_access", desc: "Access Master Command Center", url: "/MASTER_COMMAND_CENTER.html" },
    { step: 2, action: "mentor", desc: "Mentor new Builders", url: "/mentorship.html" }
  ],
  ORACLE: [
    { step: 1, action: "admin", desc: "Admin Dashboard access", url: "/admin-dashboard.html" }
  ]
};
function getUserLevel(xp, isVerified = false) {
  if (!isVerified) return VERIFICATION_LEVELS.LOBBY;
  if (xp >= 2500) return VERIFICATION_LEVELS.ORACLE;
  if (xp >= 500) return VERIFICATION_LEVELS.ARCHITECT;
  if (xp >= 200) return VERIFICATION_LEVELS.CONTRIBUTOR;
  if (xp >= 50) return VERIFICATION_LEVELS.BUILDER;
  return VERIFICATION_LEVELS.SEEKER;
}
function getAccessibleDomains(level) {
  const accessible = [];
  for (let i = 0; i <= level; i++) {
    accessible.push(...LEVEL_UNLOCKS[i] || []);
  }
  return [...new Set(accessible)];
}
function getNextSteps(levelName) {
  return ONBOARDING_STEPS[levelName] || [];
}
function formatOnboardingResponse(levelName, xp = 0) {
  const level = VERIFICATION_LEVELS[levelName];
  const nextSteps = ONBOARDING_STEPS[levelName] || [];
  const accessibleDomains = getAccessibleDomains(level.level);
  let response = `**Your Level: ${level.name}** (${xp} XP)
`;
  response += `${level.desc}

`;
  if (nextSteps.length > 0) {
    response += `**Next Steps:**
`;
    nextSteps.forEach((step, i) => {
      response += `${i + 1}. [${step.desc}](${step.url})
`;
    });
  }
  const levels = Object.values(VERIFICATION_LEVELS);
  const nextLevel = levels.find((l) => l.level === level.level + 1);
  if (nextLevel) {
    response += `
**Next Level:** ${nextLevel.name} (${nextLevel.xp} XP needed)
`;
  }
  return response;
}
var HELP_TRIGGERS = [
  "how can i help",
  "what can i do",
  "how do i contribute",
  "i want to help",
  "where do i start",
  "how do i get started",
  "what should i do",
  "how can i contribute",
  "i want to build",
  "what are the levels",
  "how do i level up",
  "what is my level"
];
function isOnboardingTrigger(message) {
  const msgLower = message.toLowerCase();
  return HELP_TRIGGERS.some((trigger) => msgLower.includes(trigger));
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ACCESS_TIERS,
  BUILDER_COCKPITS,
  DISCORD_ROLE_MAPPING,
  DOMAIN_TOOLS,
  HELP_TRIGGERS,
  LEVEL_UNLOCKS,
  ONBOARDING_STEPS,
  VERIFICATION_LEVELS,
  findDomainTools,
  formatDomainResponse,
  formatOnboardingResponse,
  getAccessibleDomains,
  getBuilder,
  getBuildersInDomain,
  getHighestLevelFromRoles,
  getLevelFromDiscordRole,
  getNextSteps,
  getUserLevel,
  isOnboardingTrigger
});
