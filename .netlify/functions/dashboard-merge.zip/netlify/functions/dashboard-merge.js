var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/dashboard-merge.mjs
var dashboard_merge_exports = {};
__export(dashboard_merge_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(dashboard_merge_exports);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const {
      source_dashboard,
      target_dashboard,
      feature_ids,
      strategy = "append",
      preview_only = true
    } = JSON.parse(event.body || "{}");
    if (!source_dashboard || !target_dashboard || !feature_ids || feature_ids.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Missing required params: source_dashboard, target_dashboard, feature_ids (array)"
        })
      };
    }
    const registryPath = import_path.default.join(process.cwd(), "DASHBOARD_FEATURES_REGISTRY.json");
    const registryData = import_fs.default.readFileSync(registryPath, "utf8");
    const registry = JSON.parse(registryData);
    const sourcePath = import_path.default.join(process.cwd(), source_dashboard);
    const targetPath = import_path.default.join(process.cwd(), target_dashboard);
    if (!import_fs.default.existsSync(sourcePath)) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: `Source dashboard not found: ${source_dashboard}` })
      };
    }
    if (!import_fs.default.existsSync(targetPath)) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: `Target dashboard not found: ${target_dashboard}` })
      };
    }
    const sourceHTML = import_fs.default.readFileSync(sourcePath, "utf8");
    const targetHTML = import_fs.default.readFileSync(targetPath, "utf8");
    const featuresToMerge = [];
    for (const featureId of feature_ids) {
      const feature = registry.features.find((f) => f.id === featureId);
      if (!feature) {
        return {
          statusCode: 404,
          headers,
          body: JSON.stringify({ error: `Feature not found: ${featureId}` })
        };
      }
      const featureCode = extractFeatureCode(sourceHTML, feature);
      if (!featureCode) {
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: `Could not extract feature ${featureId} from ${source_dashboard}`
          })
        };
      }
      featuresToMerge.push({
        id: feature.id,
        name: feature.name,
        code: featureCode,
        category: feature.category,
        dependencies: feature.dependencies
      });
    }
    const missingDeps = checkDependencies(featuresToMerge, targetHTML, registry);
    if (missingDeps.length > 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Missing dependencies",
          missing_dependencies: missingDeps,
          suggestion: "Install these features first or include them in the merge"
        })
      };
    }
    let mergedHTML = targetHTML;
    const injectionLog = [];
    for (const feature of featuresToMerge) {
      const result = injectFeature(mergedHTML, feature, strategy);
      mergedHTML = result.html;
      injectionLog.push({
        feature_id: feature.id,
        feature_name: feature.name,
        strategy_used: result.strategy,
        injection_point: result.injection_point,
        success: result.success
      });
    }
    mergedHTML = updateDNABlock(mergedHTML, target_dashboard, featuresToMerge);
    if (preview_only) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          preview: true,
          merged_html: mergedHTML,
          injection_log: injectionLog,
          features_merged: featuresToMerge.length,
          target_dashboard,
          message: "Preview generated. Set preview_only=false to save changes."
        })
      };
    }
    import_fs.default.writeFileSync(targetPath, mergedHTML, "utf8");
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        target_dashboard,
        features_merged: featuresToMerge.length,
        injection_log: injectionLog,
        message: `Successfully merged ${featuresToMerge.length} feature(s) into ${target_dashboard}`
      })
    };
  } catch (error) {
    console.error("Dashboard merge error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: error.message,
        stack: error.stack
      })
    };
  }
};
function extractFeatureCode(html, feature) {
  const featureRegex = new RegExp(
    `<!-- FEATURE: ${feature.id} -->([\\s\\S]*?)<!-- \\/FEATURE -->`,
    "i"
  );
  const match = html.match(featureRegex);
  if (match) {
    return match[0];
  }
  const nameRegex = new RegExp(
    `<!-- ${feature.name} START -->([\\s\\S]*?)<!-- ${feature.name} END -->`,
    "i"
  );
  const nameMatch = html.match(nameRegex);
  if (nameMatch) {
    return nameMatch[0];
  }
  return null;
}
function checkDependencies(features, targetHTML, registry) {
  const missing = [];
  for (const feature of features) {
    if (!feature.dependencies || feature.dependencies.length === 0) continue;
    for (const dep of feature.dependencies) {
      if (dep.startsWith("feat_")) {
        const depFeature = registry.features.find((f) => f.id === dep);
        if (!depFeature) continue;
        const hasFeature = targetHTML.includes(`<!-- FEATURE: ${dep} -->`);
        if (!hasFeature) {
          missing.push({
            required_by: feature.id,
            dependency: dep,
            dependency_name: depFeature.name,
            type: "feature"
          });
        }
      } else if (dep.includes(".js") || dep.includes(".mjs")) {
        const hasScript = targetHTML.includes(dep);
        if (!hasScript) {
          missing.push({
            required_by: feature.id,
            dependency: dep,
            type: "script"
          });
        }
      }
    }
  }
  return missing;
}
function injectFeature(html, feature, strategy) {
  let injectedHTML = html;
  let injectionPoint = "unknown";
  let actualStrategy = strategy;
  if (strategy === "quadrant") {
    const result = insertIntoQuadrant(html, feature.code, "top-right");
    injectedHTML = result.html;
    injectionPoint = result.location;
  } else if (strategy === "smart") {
    const result = insertAfterSimilar(html, feature);
    if (result.found) {
      injectedHTML = result.html;
      injectionPoint = result.location;
    } else {
      actualStrategy = "append (smart fallback)";
      injectedHTML = html.replace("</body>", `
${feature.code}
</body>`);
      injectionPoint = "before </body>";
    }
  } else {
    injectedHTML = html.replace("</body>", `
${feature.code}
</body>`);
    injectionPoint = "before </body>";
  }
  return {
    html: injectedHTML,
    strategy: actualStrategy,
    injection_point: injectionPoint,
    success: true
  };
}
function insertIntoQuadrant(html, featureCode, quadrant = "top-right") {
  const quadrantMap = {
    "top-left": /<!-- TOP-LEFT QUADRANT -->[\s\S]*?<!-- \/TOP-LEFT -->/i,
    "top-right": /<!-- TOP-RIGHT QUADRANT -->[\s\S]*?<!-- \/TOP-RIGHT -->/i,
    "bottom-left": /<!-- BOTTOM-LEFT QUADRANT -->[\s\S]*?<!-- \/BOTTOM-LEFT -->/i,
    "bottom-right": /<!-- BOTTOM-RIGHT QUADRANT -->[\s\S]*?<!-- \/BOTTOM-RIGHT -->/i
  };
  const regex = quadrantMap[quadrant];
  if (regex && regex.test(html)) {
    const closingTag = `<!-- /${quadrant.toUpperCase().replace("-", "-")} -->`;
    const modifiedHTML = html.replace(closingTag, `${featureCode}
${closingTag}`);
    return { html: modifiedHTML, location: quadrant };
  }
  return {
    html: html.replace("</body>", `
${featureCode}
</body>`),
    location: "before </body> (quadrant not found)"
  };
}
function insertAfterSimilar(html, feature) {
  const categoryRegex = new RegExp(
    `<!-- FEATURE: feat_\\d+ -->([\\s\\S]*?)<!-- CATEGORY: ${feature.category} -->([\\s\\S]*?)<!-- \\/FEATURE -->`,
    "i"
  );
  const match = html.match(categoryRegex);
  if (match) {
    const insertAfter = match[0];
    const modifiedHTML = html.replace(insertAfter, `${insertAfter}
${feature.code}`);
    return {
      html: modifiedHTML,
      location: `after similar ${feature.category} widget`,
      found: true
    };
  }
  return { html, location: "none", found: false };
}
function updateDNABlock(html, dashboardName, mergedFeatures) {
  const dnaRegex = /<script id="dashboard-dna" type="application\/json">([\s\S]*?)<\/script>/;
  const match = html.match(dnaRegex);
  if (!match) {
    const newDNA = {
      version: "1.0.0",
      owner: "merged_dashboard",
      dashboard_name: dashboardName,
      created: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      last_updated: (/* @__PURE__ */ new Date()).toISOString(),
      changelog: [
        {
          date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          version: "1.0.0",
          changes: mergedFeatures.map((f) => `Merged ${f.name} (${f.id})`),
          author: "Dashboard Factory"
        }
      ],
      installed_features: mergedFeatures.map((f) => f.id),
      lfsme_impact: { average: 8.5 }
    };
    const dnaBlock = `
<script id="dashboard-dna" type="application/json">
${JSON.stringify(newDNA, null, 2)}
</script>
`;
    return html.replace("</head>", `${dnaBlock}</head>`);
  }
  const dna = JSON.parse(match[1]);
  const [major, minor, patch] = dna.version.split(".").map(Number);
  dna.version = `${major}.${minor + 1}.${patch}`;
  dna.last_updated = (/* @__PURE__ */ new Date()).toISOString();
  if (!dna.changelog) dna.changelog = [];
  dna.changelog.unshift({
    date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    version: dna.version,
    changes: mergedFeatures.map((f) => `Merged ${f.name} (${f.id})`),
    author: "Dashboard Factory"
  });
  if (!dna.installed_features) dna.installed_features = [];
  for (const feature of mergedFeatures) {
    if (!dna.installed_features.includes(feature.id)) {
      dna.installed_features.push(feature.id);
    }
  }
  const updatedDNA = `<script id="dashboard-dna" type="application/json">
${JSON.stringify(dna, null, 2)}
</script>`;
  return html.replace(match[0], updatedDNA);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
