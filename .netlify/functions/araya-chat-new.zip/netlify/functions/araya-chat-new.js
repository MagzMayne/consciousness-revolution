// netlify/functions/araya-chat-new.mjs
var DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
var ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
var GITHUB_TOKEN = process.env.GITHUB_TOKEN;
