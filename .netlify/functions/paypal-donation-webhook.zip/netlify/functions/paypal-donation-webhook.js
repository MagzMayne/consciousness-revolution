var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/paypal-donation-webhook.mjs
var paypal_donation_webhook_exports = {};
__export(paypal_donation_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(paypal_donation_webhook_exports);
var RELEVANT_EVENTS = [
  "PAYMENT.SALE.COMPLETED",
  "PAYMENT.CAPTURE.COMPLETED",
  "CHECKOUT.ORDER.COMPLETED"
];
var PAYPAL_API_BASE = process.env.PAYPAL_MODE === "live" ? "https://api.paypal.com" : "https://api.sandbox.paypal.com";
async function getPayPalAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error("PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET must be set");
  }
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const response = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      "Authorization": `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials"
  });
  if (!response.ok) {
    throw new Error(`Failed to get PayPal access token: ${response.statusText}`);
  }
  const data = await response.json();
  return data.access_token;
}
async function verifyWebhookSignature(headers, rawBody, webhookId) {
  try {
    const transmissionId = headers["paypal-transmission-id"];
    const transmissionTime = headers["paypal-transmission-time"];
    const certUrl = headers["paypal-cert-url"];
    const authAlgo = headers["paypal-auth-algo"];
    const transmissionSig = headers["paypal-transmission-sig"];
    if (!transmissionId || !transmissionTime || !transmissionSig || !certUrl || !authAlgo) {
      console.warn("Missing required PayPal webhook headers");
      return false;
    }
    const accessToken = await getPayPalAccessToken();
    const verifyResponse = await fetch(`${PAYPAL_API_BASE}/v1/notifications/verify-webhook-signature`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        auth_algo: authAlgo,
        cert_url: certUrl,
        transmission_id: transmissionId,
        transmission_sig: transmissionSig,
        transmission_time: transmissionTime,
        webhook_id: webhookId,
        webhook_event: JSON.parse(rawBody)
        // rawBody is always event.body (raw string)
      })
    });
    if (!verifyResponse.ok) {
      console.error("PayPal verify-webhook-signature API error:", verifyResponse.statusText);
      return false;
    }
    const result = await verifyResponse.json();
    console.log("Webhook verification result:", result.verification_status);
    return result.verification_status === "SUCCESS";
  } catch (error) {
    console.error("Webhook verification error:", error);
    return false;
  }
}
async function logDonation(donationData) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  const logEntry = {
    timestamp,
    event: "PayPal Donation Received",
    amount: donationData.amount,
    currency: donationData.currency,
    donor: donationData.donor,
    transactionId: donationData.transactionId,
    recipient: "BarbrickDesign@gmail.com"
  };
  console.log("DONATION RECEIVED:", JSON.stringify(logEntry, null, 2));
  return logEntry;
}
async function sendThankYou(donationData) {
  console.log(`Thank you email would be sent to: ${donationData.donor}`);
  return true;
}
async function handler(event, context) {
  console.log("PayPal Webhook received");
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body);
    const headers = event.headers;
    const webhookId = process.env.PAYPAL_WEBHOOK_ID;
    if (webhookId) {
      const isValid = await verifyWebhookSignature(headers, event.body, webhookId);
      if (!isValid) {
        console.error("Invalid webhook signature");
        return {
          statusCode: 401,
          body: JSON.stringify({ error: "Invalid signature" })
        };
      }
    }
    const eventType = body.event_type;
    if (!RELEVANT_EVENTS.includes(eventType)) {
      console.log("Ignoring event type:", eventType);
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "Event type ignored" })
      };
    }
    const resource = body.resource;
    const donationData = {
      transactionId: resource.id || "unknown",
      amount: resource.amount?.value || "0",
      currency: resource.amount?.currency_code || "USD",
      donor: resource.payer?.email_address || "anonymous",
      donorName: resource.payer?.name?.given_name || "Anonymous",
      status: resource.state || resource.status || "unknown",
      eventType
    };
    await logDonation(donationData);
    sendThankYou(donationData).catch(
      (err) => console.error("Thank you notification failed:", err)
    );
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        message: "Donation webhook processed",
        transactionId: donationData.transactionId
      })
    };
  } catch (error) {
    console.error("Webhook processing error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
