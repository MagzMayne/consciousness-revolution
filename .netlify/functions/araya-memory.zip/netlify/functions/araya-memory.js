var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/araya-memory.mjs
var araya_memory_exports = {};
__export(araya_memory_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(araya_memory_exports);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;
var WRITE_OPERATIONS = ["store_message", "store_profile", "store_insight"];
async function supabase(table, method, data = null, query = "") {
  const url = `${SUPABASE_URL}/rest/v1/${table}${query}`;
  const options = {
    method,
    headers: {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": method === "POST" ? "return=representation" : "return=minimal"
    }
  };
  if (data) {
    options.body = JSON.stringify(data);
  }
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Supabase error: ${error}`);
  }
  if (method === "GET" || method === "POST") {
    return response.json();
  }
  return null;
}
async function handler(event) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Memory-Key",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  try {
    const { action, user_id, data } = JSON.parse(event.body);
    if (WRITE_OPERATIONS.includes(action)) {
      const authKey = event.headers["x-memory-key"] || event.headers["X-Memory-Key"];
      const internalCall = event.headers["x-internal-call"] === "araya-chat";
      if (!internalCall && authKey !== process.env.MEMORY_API_KEY) {
        console.log(`\u26A0\uFE0F UNAUTHORIZED MEMORY WRITE ATTEMPT: ${action} for user ${user_id || "unknown"}`);
        return {
          statusCode: 401,
          headers,
          body: JSON.stringify({
            error: "Unauthorized - X-Memory-Key required for write operations"
          })
        };
      }
    }
    if (!user_id) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "user_id required" })
      };
    }
    switch (action) {
      case "store_message": {
        const atom = {
          user_id,
          type: data.role,
          // 'user' or 'assistant'
          content: data.content,
          metadata: data.metadata || {},
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        await supabase("araya_memory", "POST", atom);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true })
        };
      }
      case "store_profile": {
        const profile = {
          user_id,
          type: "profile",
          content: JSON.stringify(data),
          metadata: { updated_at: (/* @__PURE__ */ new Date()).toISOString() },
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        await supabase("araya_memory", "DELETE", null, `?user_id=eq.${user_id}&type=eq.profile`);
        await supabase("araya_memory", "POST", profile);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true })
        };
      }
      case "get_context": {
        const limit = data?.limit || 20;
        const profiles = await supabase(
          "araya_memory",
          "GET",
          null,
          `?user_id=eq.${user_id}&type=eq.profile&limit=1`
        );
        const messages = await supabase(
          "araya_memory",
          "GET",
          null,
          `?user_id=eq.${user_id}&type=neq.profile&order=created_at.desc&limit=${limit}`
        );
        let profile = null;
        if (profiles && profiles.length > 0) {
          try {
            profile = JSON.parse(profiles[0].content);
          } catch (e) {
            profile = profiles[0].content;
          }
        }
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            profile,
            messages: messages?.reverse() || [],
            total_interactions: messages?.length || 0
          })
        };
      }
      case "store_insight": {
        const insight = {
          user_id,
          type: "insight",
          content: data.insight,
          metadata: {
            category: data.category,
            confidence: data.confidence,
            context: data.context
          },
          created_at: (/* @__PURE__ */ new Date()).toISOString()
        };
        await supabase("araya_memory", "POST", insight);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true })
        };
      }
      case "get_insights": {
        const insights = await supabase(
          "araya_memory",
          "GET",
          null,
          `?user_id=eq.${user_id}&type=eq.insight&order=created_at.desc`
        );
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ insights: insights || [] })
        };
      }
      default:
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "Unknown action" })
        };
    }
  } catch (error) {
    console.error("Araya Memory Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
