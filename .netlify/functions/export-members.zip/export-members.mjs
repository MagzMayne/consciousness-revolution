
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/export-members.mjs
import { createClient } from "@supabase/supabase-js";
var supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
function escapeCSV(value) {
  if (value === null || value === void 0) return "";
  const str = String(value);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}
function toCSV(data, columns) {
  const header = columns.map((col) => escapeCSV(col.label || col.key)).join(",");
  const rows = data.map(
    (row) => columns.map((col) => escapeCSV(row[col.key])).join(",")
  );
  return [header, ...rows].join("\n");
}
var export_members_default = async (request, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  try {
    const url = new URL(request.url);
    const adminKey = url.searchParams.get("key");
    const format = url.searchParams.get("format") || "csv";
    const filter = url.searchParams.get("filter") || "all";
    const validKey = process.env.ADMIN_EXPORT_KEY || "consciousness137";
    if (adminKey !== validKey) {
      return new Response(JSON.stringify({
        error: "Unauthorized",
        hint: "Add ?key=YOUR_ADMIN_KEY to URL"
      }), {
        status: 401,
        headers: { ...headers, "Content-Type": "application/json" }
      });
    }
    let query = supabase.from("discord_users").select("*").order("created_at", { ascending: false });
    if (filter === "verified") {
      query = query.eq("verified", true);
    } else if (filter === "pending") {
      query = query.eq("verification_status", "pending");
    } else if (filter === "flagged") {
      query = query.eq("verification_status", "flagged");
    }
    const { data: members, error } = await query;
    if (error) {
      throw new Error(`Database error: ${error.message}`);
    }
    const columns = [
      { key: "username", label: "Username" },
      { key: "discord_id", label: "Discord ID" },
      { key: "verification_status", label: "Status" },
      { key: "trust_tier", label: "Trust Tier" },
      { key: "total_xp", label: "XP" },
      { key: "current_level", label: "Level" },
      { key: "builder_score", label: "Builder Score" },
      { key: "verified", label: "Verified" },
      { key: "social_link", label: "Social Link" },
      { key: "intro_message", label: "Intro Message" },
      { key: "messages_count", label: "Messages" },
      { key: "tasks_completed", label: "Tasks" },
      { key: "joined_at", label: "Joined At" },
      { key: "verified_at", label: "Verified At" },
      { key: "last_active", label: "Last Active" },
      { key: "is_blocked", label: "Blocked" },
      { key: "review_notes", label: "Review Notes" },
      { key: "reviewed_by", label: "Reviewed By" }
    ];
    if (format === "json") {
      return new Response(JSON.stringify({
        success: true,
        count: members.length,
        exported_at: (/* @__PURE__ */ new Date()).toISOString(),
        members
      }, null, 2), {
        status: 200,
        headers: {
          ...headers,
          "Content-Type": "application/json"
        }
      });
    }
    const csv = toCSV(members, columns);
    const filename = `100x_members_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`;
    return new Response(csv, {
      status: 200,
      headers: {
        ...headers,
        "Content-Type": "text/csv",
        "Content-Disposition": `attachment; filename="${filename}"`
      }
    });
  } catch (error) {
    console.error("Export error:", error);
    return new Response(JSON.stringify({
      error: "Export failed",
      message: error.message
    }), {
      status: 500,
      headers: { ...headers, "Content-Type": "application/json" }
    });
  }
};
var config = {
  path: "/api/export-members"
};
export {
  config,
  export_members_default as default
};
