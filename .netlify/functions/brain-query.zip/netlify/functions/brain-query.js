var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/brain-query.mjs
var brain_query_exports = {};
__export(brain_query_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(brain_query_exports);
var import_fs = require("fs");
var import_path = require("path");
var import_url = require("url");
var brainData = null;
function searchBrain(atoms, query, limit = 5) {
  if (!atoms || !query) return [];
  const queryLower = query.toLowerCase();
  const queryWords = queryLower.split(/\s+/).filter((w) => w.length > 2);
  const scored = atoms.map((atom) => {
    const content = (atom.content || "").toLowerCase();
    let score = 0;
    if (content.includes(queryLower)) score += 10;
    for (const word of queryWords) {
      if (content.includes(word)) score += 2;
    }
    const typeWeights = {
      "knowledge": 1.5,
      "pattern": 1.4,
      "insight": 1.3,
      "concept": 1.2,
      "fact": 1.1,
      "ability": 1
    };
    score *= typeWeights[atom.type] || 1;
    return { ...atom, score };
  });
  return scored.filter((a) => a.score > 0).sort((a, b) => b.score - a.score).slice(0, limit).map(({ score, ...atom }) => atom);
}
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
      },
      body: ""
    };
  }
  try {
    let query = "";
    let limit = 5;
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      query = body.query || "";
      limit = body.limit || 5;
    } else if (event.httpMethod === "GET") {
      query = event.queryStringParameters?.query || "";
      limit = parseInt(event.queryStringParameters?.limit) || 5;
    }
    if (!query) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Missing query parameter" })
      };
    }
    if (!brainData) {
      const brainResponse = await fetch("https://conciousnessrevolution.io/brain-context.json");
      if (!brainResponse.ok) {
        throw new Error("Failed to load brain data");
      }
      brainData = await brainResponse.json();
    }
    const atoms = brainData;
    const results = searchBrain(atoms, query, limit);
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        query,
        count: results.length,
        atoms: results,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("Brain query error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: error.message })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
