var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-checkout.mjs
var create_checkout_exports = {};
__export(create_checkout_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_checkout_exports);

// netlify/functions/utils/security.mjs
var import_crypto = __toESM(require("crypto"), 1);
var ALLOWED_ORIGINS = [
  "https://consciousnessrevolution.io",
  "https://www.consciousnessrevolution.io",
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "http://localhost:8888",
  "http://localhost:3000",
  "http://127.0.0.1:8888"
];
function getSecureCORSHeaders(origin) {
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    // 24 hours
    "Content-Type": "application/json",
    // Security headers
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
  };
}
var rateLimitStore = /* @__PURE__ */ new Map();
function checkRateLimit(identifier, maxRequests = 100, windowMs = 6e4) {
  const now = Date.now();
  const key = `rate_${identifier}`;
  if (!rateLimitStore.has(key)) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  const record = rateLimitStore.get(key);
  if (now > record.resetAt) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  if (record.count >= maxRequests) {
    return { allowed: false, resetAt: record.resetAt };
  }
  record.count++;
  rateLimitStore.set(key, record);
  return { allowed: true, resetAt: record.resetAt };
}
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of rateLimitStore.entries()) {
    if (now > record.resetAt + 6e4) {
      rateLimitStore.delete(key);
    }
  }
}, 3e5);
function anonymizeIP(ip) {
  if (!ip) return null;
  if (ip.includes(".")) {
    const parts = ip.split(".");
    if (parts.length === 4) {
      return `${parts[0]}.${parts[1]}.${parts[2]}.0`;
    }
  }
  if (ip.includes(":")) {
    const parts = ip.split(":");
    if (parts.length >= 4) {
      return `${parts[0]}:${parts[1]}:${parts[2]}:${parts[3]}::`;
    }
  }
  return null;
}
var ENCRYPTION_KEY = process.env.DATA_ENCRYPTION_KEY;
function successResponse(data, origin, statusCode = 200) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: true,
      data,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function errorResponse(message, origin, statusCode = 400, code = null) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: false,
      error: message,
      ...code && { code },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function handlePreflight(origin) {
  return {
    statusCode: 204,
    headers: getSecureCORSHeaders(origin),
    body: ""
  };
}

// netlify/functions/create-checkout.mjs
var STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;
async function handler(event, context) {
  const origin = event.headers.origin || event.headers.Origin || "";
  if (event.httpMethod === "OPTIONS") {
    return handlePreflight(origin);
  }
  if (event.httpMethod !== "POST") {
    return errorResponse("Method not allowed", origin, 405);
  }
  const clientIP = event.headers["x-forwarded-for"]?.split(",")[0] || "unknown";
  const rateLimitCheck = checkRateLimit(`checkout_${anonymizeIP(clientIP)}`, 20, 36e5);
  if (!rateLimitCheck.allowed) {
    return errorResponse("Too many requests. Please try again later.", origin, 429);
  }
  try {
    const { priceId, email, customerEmail, successUrl, cancelUrl } = JSON.parse(event.body);
    const finalEmail = customerEmail || email;
    if (!STRIPE_SECRET_KEY) {
      return errorResponse("Payment system not configured", origin, 503);
    }
    const finalPriceId = priceId || process.env.STRIPE_PRICE_BUILDER_PRO || "price_1She0KIBd71iNToy3S6IWn2I";
    const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        "mode": "payment",
        "line_items[0][price]": finalPriceId,
        "line_items[0][quantity]": "1",
        "success_url": successUrl || "https://conciousnessrevolution.io/success.html?session_id={CHECKOUT_SESSION_ID}",
        "cancel_url": cancelUrl || "https://conciousnessrevolution.io/",
        ...finalEmail && { "customer_email": finalEmail }
      })
    });
    if (!response.ok) {
      const error = await response.text();
      console.error("Stripe error:", error);
      return errorResponse("Failed to create checkout session", origin, 500);
    }
    const session = await response.json();
    return successResponse({
      sessionId: session.id,
      url: session.url
    }, origin);
  } catch (error) {
    console.error("Checkout error:", error);
    return errorResponse("Failed to create checkout", origin, 500);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
