
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/araya-phrases.mjs
import { createClient } from "@supabase/supabase-js";
var supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
var CORE_PHRASES = [
  // GREETINGS (10)
  { category: "greeting", en: "Hello", es: "Hola", formality: "neutral" },
  { category: "greeting", en: "Good morning", es: "Buenos d\xEDas", formality: "neutral" },
  { category: "greeting", en: "Good afternoon", es: "Buenas tardes", formality: "neutral" },
  { category: "greeting", en: "Good evening", es: "Buenas noches", formality: "neutral" },
  { category: "greeting", en: "How are you?", es: "\xBFC\xF3mo est\xE1 usted?", formality: "formal" },
  { category: "greeting", en: "How are you?", es: "\xBFC\xF3mo est\xE1s?", formality: "casual" },
  { category: "greeting", en: "Nice to meet you", es: "Mucho gusto", formality: "neutral" },
  { category: "greeting", en: "My name is...", es: "Me llamo...", formality: "neutral" },
  { category: "greeting", en: "Goodbye", es: "Adi\xF3s", formality: "neutral" },
  { category: "greeting", en: "See you later", es: "Hasta luego", formality: "neutral" },
  // COURTESY (10)
  { category: "courtesy", en: "Please", es: "Por favor", formality: "neutral" },
  { category: "courtesy", en: "Thank you", es: "Gracias", formality: "neutral" },
  { category: "courtesy", en: "Thank you very much", es: "Muchas gracias", formality: "neutral" },
  { category: "courtesy", en: "You're welcome", es: "De nada", formality: "neutral" },
  { category: "courtesy", en: "Excuse me", es: "Disculpe", formality: "formal" },
  { category: "courtesy", en: "Excuse me", es: "Perd\xF3n", formality: "casual" },
  { category: "courtesy", en: "I'm sorry", es: "Lo siento", formality: "neutral" },
  { category: "courtesy", en: "No problem", es: "No hay problema", formality: "casual" },
  { category: "courtesy", en: "Of course", es: "Por supuesto", formality: "neutral" },
  { category: "courtesy", en: "With pleasure", es: "Con mucho gusto", formality: "formal" },
  // NAVIGATION (15)
  { category: "navigation", en: "Where is the restroom?", es: "\xBFD\xF3nde est\xE1 el ba\xF1o?", formality: "neutral" },
  { category: "navigation", en: "Where is the hospital?", es: "\xBFD\xF3nde est\xE1 el hospital?", formality: "neutral" },
  { category: "navigation", en: "Where is the pharmacy?", es: "\xBFD\xF3nde est\xE1 la farmacia?", formality: "neutral" },
  { category: "navigation", en: "Where is the police station?", es: "\xBFD\xF3nde est\xE1 la estaci\xF3n de polic\xEDa?", formality: "neutral" },
  { category: "navigation", en: "Where is the airport?", es: "\xBFD\xF3nde est\xE1 el aeropuerto?", formality: "neutral" },
  { category: "navigation", en: "Where is the train station?", es: "\xBFD\xF3nde est\xE1 la estaci\xF3n de tren?", formality: "neutral" },
  { category: "navigation", en: "How do I get there?", es: "\xBFC\xF3mo llego all\xED?", formality: "neutral" },
  { category: "navigation", en: "Turn left", es: "Gire a la izquierda", formality: "neutral" },
  { category: "navigation", en: "Turn right", es: "Gire a la derecha", formality: "neutral" },
  { category: "navigation", en: "Go straight", es: "Siga derecho", formality: "neutral" },
  { category: "navigation", en: "Is it far?", es: "\xBFEst\xE1 lejos?", formality: "neutral" },
  { category: "navigation", en: "Is it close?", es: "\xBFEst\xE1 cerca?", formality: "neutral" },
  { category: "navigation", en: "I am lost", es: "Estoy perdido", formality: "neutral" },
  { category: "navigation", en: "Can you show me on the map?", es: "\xBFPuede mostrarme en el mapa?", formality: "formal" },
  { category: "navigation", en: "What is this address?", es: "\xBFCu\xE1l es esta direcci\xF3n?", formality: "neutral" },
  // COMMERCE (15)
  { category: "commerce", en: "How much does this cost?", es: "\xBFCu\xE1nto cuesta esto?", formality: "neutral" },
  { category: "commerce", en: "How much is it?", es: "\xBFCu\xE1nto es?", formality: "casual" },
  { category: "commerce", en: "Do you accept credit cards?", es: "\xBFAceptan tarjetas de cr\xE9dito?", formality: "neutral" },
  { category: "commerce", en: "Do you accept cash?", es: "\xBFAceptan efectivo?", formality: "neutral" },
  { category: "commerce", en: "Can I see the menu?", es: "\xBFPuedo ver el men\xFA?", formality: "neutral" },
  { category: "commerce", en: "I would like to order", es: "Me gustar\xEDa ordenar", formality: "neutral" },
  { category: "commerce", en: "The check please", es: "La cuenta por favor", formality: "neutral" },
  { category: "commerce", en: "Is there a discount?", es: "\xBFHay descuento?", formality: "neutral" },
  { category: "commerce", en: "That is too expensive", es: "Es muy caro", formality: "neutral" },
  { category: "commerce", en: "I will take it", es: "Lo llevar\xE9", formality: "neutral" },
  { category: "commerce", en: "Do you have a smaller size?", es: "\xBFTiene una talla m\xE1s peque\xF1a?", formality: "neutral" },
  { category: "commerce", en: "Do you have a larger size?", es: "\xBFTiene una talla m\xE1s grande?", formality: "neutral" },
  { category: "commerce", en: "Can I try this on?", es: "\xBFPuedo probarme esto?", formality: "neutral" },
  { category: "commerce", en: "Where is the fitting room?", es: "\xBFD\xF3nde est\xE1 el probador?", formality: "neutral" },
  { category: "commerce", en: "Keep the change", es: "Qu\xE9dese con el cambio", formality: "neutral" },
  // EMERGENCY (15)
  { category: "emergency", en: "Help!", es: "\xA1Ayuda!", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "I need help", es: "Necesito ayuda", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "Call the police", es: "Llame a la polic\xEDa", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "Call an ambulance", es: "Llame una ambulancia", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "There is an emergency", es: "Hay una emergencia", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "I need a doctor", es: "Necesito un m\xE9dico", formality: "urgent", domain: "medical" },
  { category: "emergency", en: "I am hurt", es: "Estoy herido", formality: "urgent", domain: "medical" },
  { category: "emergency", en: "There has been an accident", es: "Ha habido un accidente", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "Fire!", es: "\xA1Fuego!", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "Stop!", es: "\xA1Pare!", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "Someone stole my wallet", es: "Alguien rob\xF3 mi cartera", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "I lost my passport", es: "Perd\xED mi pasaporte", formality: "urgent", domain: "emergency" },
  { category: "emergency", en: "I need to go to the embassy", es: "Necesito ir a la embajada", formality: "formal", domain: "emergency" },
  { category: "emergency", en: "I don't feel well", es: "No me siento bien", formality: "neutral", domain: "medical" },
  { category: "emergency", en: "Can you help me?", es: "\xBFPuede ayudarme?", formality: "formal", domain: "emergency" },
  // HEALTH (15)
  { category: "health", en: "I am allergic to...", es: "Soy al\xE9rgico a...", formality: "neutral", domain: "medical" },
  { category: "health", en: "I have a headache", es: "Tengo dolor de cabeza", formality: "neutral", domain: "medical" },
  { category: "health", en: "I have a stomachache", es: "Tengo dolor de est\xF3mago", formality: "neutral", domain: "medical" },
  { category: "health", en: "I have a fever", es: "Tengo fiebre", formality: "neutral", domain: "medical" },
  { category: "health", en: "I am diabetic", es: "Soy diab\xE9tico", formality: "neutral", domain: "medical" },
  { category: "health", en: "I take medication for...", es: "Tomo medicamento para...", formality: "neutral", domain: "medical" },
  { category: "health", en: "I need my prescription filled", es: "Necesito surtir mi receta", formality: "neutral", domain: "medical" },
  { category: "health", en: "Do you have pain medicine?", es: "\xBFTiene medicina para el dolor?", formality: "neutral", domain: "medical" },
  { category: "health", en: "I cannot breathe well", es: "No puedo respirar bien", formality: "urgent", domain: "medical" },
  { category: "health", en: "Where does it hurt?", es: "\xBFD\xF3nde le duele?", formality: "formal", domain: "medical" },
  { category: "health", en: "I am pregnant", es: "Estoy embarazada", formality: "neutral", domain: "medical" },
  { category: "health", en: "I need an appointment", es: "Necesito una cita", formality: "neutral", domain: "medical" },
  { category: "health", en: "Is it serious?", es: "\xBFEs grave?", formality: "neutral", domain: "medical" },
  { category: "health", en: "How many times a day?", es: "\xBFCu\xE1ntas veces al d\xEDa?", formality: "neutral", domain: "medical" },
  { category: "health", en: "Take with food", es: "Tome con comida", formality: "neutral", domain: "medical" },
  // SOCIAL (10)
  { category: "social", en: "Where are you from?", es: "\xBFDe d\xF3nde es usted?", formality: "formal" },
  { category: "social", en: "Where are you from?", es: "\xBFDe d\xF3nde eres?", formality: "casual" },
  { category: "social", en: "I am from the United States", es: "Soy de los Estados Unidos", formality: "neutral" },
  { category: "social", en: "Do you speak English?", es: "\xBFHabla ingl\xE9s?", formality: "neutral" },
  { category: "social", en: "I don't understand", es: "No entiendo", formality: "neutral" },
  { category: "social", en: "Please speak slowly", es: "Por favor hable despacio", formality: "formal" },
  { category: "social", en: "Can you repeat that?", es: "\xBFPuede repetir eso?", formality: "formal" },
  { category: "social", en: "What does this mean?", es: "\xBFQu\xE9 significa esto?", formality: "neutral" },
  { category: "social", en: "How do you say... in Spanish?", es: "\xBFC\xF3mo se dice... en espa\xF1ol?", formality: "neutral" },
  { category: "social", en: "I am learning Spanish", es: "Estoy aprendiendo espa\xF1ol", formality: "neutral" },
  // TRAVEL (10)
  { category: "travel", en: "I have a reservation", es: "Tengo una reservaci\xF3n", formality: "neutral", domain: "travel" },
  { category: "travel", en: "What time is checkout?", es: "\xBFA qu\xE9 hora es el checkout?", formality: "neutral", domain: "travel" },
  { category: "travel", en: "Is breakfast included?", es: "\xBFEl desayuno est\xE1 incluido?", formality: "neutral", domain: "travel" },
  { category: "travel", en: "What is the WiFi password?", es: "\xBFCu\xE1l es la contrase\xF1a del WiFi?", formality: "neutral", domain: "travel" },
  { category: "travel", en: "Can I have the key please?", es: "\xBFMe puede dar la llave por favor?", formality: "formal", domain: "travel" },
  { category: "travel", en: "What time does the flight leave?", es: "\xBFA qu\xE9 hora sale el vuelo?", formality: "neutral", domain: "travel" },
  { category: "travel", en: "Where is gate number...?", es: "\xBFD\xF3nde est\xE1 la puerta n\xFAmero...?", formality: "neutral", domain: "travel" },
  { category: "travel", en: "My luggage is lost", es: "Mi equipaje se perdi\xF3", formality: "neutral", domain: "travel" },
  { category: "travel", en: "I am here for business", es: "Estoy aqu\xED por negocios", formality: "formal", domain: "travel" },
  { category: "travel", en: "I am here on vacation", es: "Estoy aqu\xED de vacaciones", formality: "neutral", domain: "travel" }
];
var araya_phrases_default = async (req) => {
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "list";
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  try {
    if (action === "seed") {
      const createTableSQL = `
                CREATE TABLE IF NOT EXISTS language_phrases (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    category VARCHAR(50) NOT NULL,
                    domain VARCHAR(50) DEFAULT 'general',
                    en TEXT NOT NULL,
                    es TEXT,
                    zh TEXT,
                    tl TEXT,
                    vi TEXT,
                    ar TEXT,
                    fr TEXT,
                    formality VARCHAR(20) DEFAULT 'neutral',
                    context_hints JSONB,
                    audio_urls JSONB,
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );
            `;
      const { error: insertError } = await supabase.from("language_phrases").upsert(CORE_PHRASES.map((p) => ({
        category: p.category,
        domain: p.domain || "general",
        en: p.en,
        es: p.es,
        formality: p.formality || "neutral"
      })), { onConflict: "en,es" });
      if (insertError && !insertError.message.includes("duplicate")) {
        console.error("[PHRASES] Seed error:", insertError);
      }
      return new Response(JSON.stringify({
        success: true,
        message: `Seeded ${CORE_PHRASES.length} phrases`,
        categories: [...new Set(CORE_PHRASES.map((p) => p.category))]
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "list") {
      const category = url.searchParams.get("category");
      const domain = url.searchParams.get("domain");
      const formality = url.searchParams.get("formality");
      let query = supabase.from("language_phrases").select("*");
      if (category) query = query.eq("category", category);
      if (domain) query = query.eq("domain", domain);
      if (formality) query = query.eq("formality", formality);
      const { data, error } = await query.limit(100);
      if (error) {
        const filtered = CORE_PHRASES.filter((p) => {
          if (category && p.category !== category) return false;
          if (domain && p.domain !== domain) return false;
          if (formality && p.formality !== formality) return false;
          return true;
        });
        return new Response(JSON.stringify({
          phrases: filtered,
          source: "memory",
          count: filtered.length
        }), {
          status: 200,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
        });
      }
      return new Response(JSON.stringify({
        phrases: data,
        source: "database",
        count: data.length
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "categories") {
      const categories = [...new Set(CORE_PHRASES.map((p) => p.category))];
      return new Response(JSON.stringify({
        categories,
        count: categories.length
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "search") {
      const query = url.searchParams.get("q") || "";
      const lang = url.searchParams.get("lang") || "en";
      const results = CORE_PHRASES.filter((p) => {
        const searchIn = p[lang] || p.en;
        return searchIn.toLowerCase().includes(query.toLowerCase());
      });
      return new Response(JSON.stringify({
        query,
        results,
        count: results.length
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    if (action === "random") {
      const category = url.searchParams.get("category");
      let pool = CORE_PHRASES;
      if (category) {
        pool = CORE_PHRASES.filter((p) => p.category === category);
      }
      const phrase = pool[Math.floor(Math.random() * pool.length)];
      return new Response(JSON.stringify({
        phrase,
        category: phrase.category
      }), {
        status: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
      });
    }
    return new Response(JSON.stringify({
      error: "Unknown action",
      available: ["list", "categories", "search", "random", "seed"]
    }), {
      status: 400,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  } catch (error) {
    console.error("[PHRASES] Error:", error);
    return new Response(JSON.stringify({
      error: "Phrase operation failed",
      details: error.message
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
};
var config = { path: "/api/araya-phrases" };
export {
  config,
  araya_phrases_default as default
};
