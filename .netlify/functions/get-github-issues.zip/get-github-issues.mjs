
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/get-github-issues.mjs
async function handler(request, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  try {
    const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
    const REPO_OWNER = "overkillkulture";
    const REPO_NAME = "consciousness-dashboards";
    const fetchHeaders = {
      "Accept": "application/vnd.github.v3+json",
      "User-Agent": "Consciousness-Revolution-TaskBoard"
    };
    if (GITHUB_TOKEN) {
      fetchHeaders["Authorization"] = `token ${GITHUB_TOKEN}`;
    }
    const response = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/issues?state=all&per_page=100&sort=created&direction=desc`,
      { headers: fetchHeaders }
    );
    if (!response.ok) {
      const errorText = await response.text();
      console.error("GitHub API Error:", response.status, errorText);
      return new Response(JSON.stringify({
        error: "GitHub API Error",
        status: response.status,
        message: errorText
      }), { status: response.status, headers });
    }
    const issues = await response.json();
    const filteredIssues = issues.filter((issue) => !issue.pull_request);
    return new Response(JSON.stringify(filteredIssues), {
      status: 200,
      headers
    });
  } catch (error) {
    console.error("Error fetching GitHub issues:", error);
    return new Response(JSON.stringify({
      error: "Internal Error",
      message: error.message
    }), { status: 500, headers });
  }
}
export {
  handler as default
};
