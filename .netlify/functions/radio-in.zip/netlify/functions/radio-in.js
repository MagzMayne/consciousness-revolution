var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/radio-in.mjs
var radio_in_exports = {};
__export(radio_in_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(radio_in_exports);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_KEY;
function generateMsgId(prefix = "IN") {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `${prefix}-${timestamp}-${random}`.toUpperCase();
}
var VALID_CHANNELS = [
  "ARAYA",
  // Araya chat messages
  "DISCORD",
  // Discord bot messages
  "WEB",
  // Website form submissions
  "TRINITY",
  // Trinity terminal messages
  "SYSTEM",
  // System notifications
  "COMMANDER",
  // Direct to Commander (high priority)
  "FEEDBACK",
  // User feedback
  "BUG"
  // Bug reports
];
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Radio-Key",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const data = JSON.parse(event.body || "{}");
    const { channel, sender, content } = data;
    if (!channel || !sender || !content) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Missing required fields",
          required: ["channel", "sender", "content"]
        })
      };
    }
    if (!VALID_CHANNELS.includes(channel.toUpperCase())) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Invalid channel",
          valid_channels: VALID_CHANNELS
        })
      };
    }
    const subject = data.subject || null;
    const priority = Math.min(10, Math.max(1, data.priority || 5));
    const metadata = data.metadata || {};
    const responseToId = data.response_to || null;
    const msgId = generateMsgId("IN");
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const message = {
      id: msgId,
      direction: "inbound",
      channel: channel.toUpperCase(),
      sender,
      receiver: "CYCLOTRON",
      subject,
      content,
      priority,
      status: "pending",
      created_at: timestamp,
      response_to: responseToId,
      metadata: JSON.stringify(metadata)
    };
    if (SUPABASE_URL && SUPABASE_KEY) {
      try {
        const response = await fetch(
          `${SUPABASE_URL}/rest/v1/radio_messages`,
          {
            method: "POST",
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Content-Type": "application/json",
              "Prefer": "return=minimal"
            },
            body: JSON.stringify(message)
          }
        );
        if (!response.ok) {
          console.log("Supabase insert failed:", response.status);
        }
      } catch (e) {
        console.log("Supabase error:", e.message);
      }
    }
    console.log("\u{1F4E5} RADIO INBOUND:", JSON.stringify({
      id: msgId,
      channel: message.channel,
      sender,
      content: content.substring(0, 100),
      priority,
      timestamp
    }));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message_id: msgId,
        status: "queued",
        note: "Message delivered to Cyclotron brain"
      })
    };
  } catch (error) {
    console.error("Radio inbound error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to receive message",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
