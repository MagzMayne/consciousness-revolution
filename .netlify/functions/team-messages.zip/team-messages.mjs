
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/team-messages.mjs
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/utils/security.mjs
import { createClient } from "@supabase/supabase-js";
var ALLOWED_ORIGINS = [
  "https://consciousnessrevolution.io",
  "https://www.consciousnessrevolution.io",
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "http://localhost:8888",
  "http://localhost:3000",
  "http://127.0.0.1:8888"
];
function getSecureCORSHeaders(origin) {
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    // 24 hours
    "Content-Type": "application/json",
    // Security headers
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
  };
}
var rateLimitStore = /* @__PURE__ */ new Map();
var supabaseClient = null;
function getSupabaseForRateLimit() {
  if (supabaseClient) return supabaseClient;
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_SECRET || process.env.SUPABASE_SERVICE_KEY;
  if (url && key) {
    supabaseClient = createClient(url, key, {
      auth: { autoRefreshToken: false, persistSession: false }
    });
  }
  return supabaseClient;
}
async function checkRateLimitDistributed(identifier, maxRequests = 100, windowMs = 6e4) {
  const supabase = getSupabaseForRateLimit();
  if (!supabase) {
    return checkRateLimit(identifier, maxRequests, windowMs);
  }
  const now = Date.now();
  const windowStart = now - windowMs;
  const key = `rate_${identifier}`;
  try {
    const { data, error } = await supabase.rpc("check_rate_limit", {
      p_identifier: key,
      p_max_requests: maxRequests,
      p_window_ms: windowMs
    });
    if (!error && data !== null) {
      return {
        allowed: data.allowed,
        resetAt: data.reset_at,
        count: data.count
      };
    }
    const { data: existing } = await supabase.from("rate_limits").select("count, window_start").eq("identifier", key).single();
    if (!existing || existing.window_start < windowStart) {
      await supabase.from("rate_limits").upsert({
        identifier: key,
        count: 1,
        window_start: now,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }, { onConflict: "identifier" });
      return { allowed: true, resetAt: now + windowMs, count: 1 };
    }
    if (existing.count >= maxRequests) {
      return {
        allowed: false,
        resetAt: existing.window_start + windowMs,
        count: existing.count
      };
    }
    await supabase.from("rate_limits").update({
      count: existing.count + 1,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("identifier", key);
    return {
      allowed: true,
      resetAt: existing.window_start + windowMs,
      count: existing.count + 1
    };
  } catch (err) {
    console.warn("Distributed rate limit failed, using in-memory:", err.message);
    return checkRateLimit(identifier, maxRequests, windowMs);
  }
}
function checkRateLimit(identifier, maxRequests = 100, windowMs = 6e4) {
  const now = Date.now();
  const key = `rate_${identifier}`;
  if (!rateLimitStore.has(key)) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  const record = rateLimitStore.get(key);
  if (now > record.resetAt) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  if (record.count >= maxRequests) {
    return { allowed: false, resetAt: record.resetAt };
  }
  record.count++;
  rateLimitStore.set(key, record);
  return { allowed: true, resetAt: record.resetAt };
}
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of rateLimitStore.entries()) {
    if (now > record.resetAt + 6e4) {
      rateLimitStore.delete(key);
    }
  }
}, 3e5);
function sanitizeString(input, maxLength = 1e3) {
  if (!input || typeof input !== "string") return "";
  let sanitized = input.replace(/\0/g, "");
  sanitized = sanitized.trim();
  if (sanitized.length > maxLength) {
    sanitized = sanitized.substring(0, maxLength);
  }
  return sanitized;
}
var ENCRYPTION_KEY = process.env.DATA_ENCRYPTION_KEY;
function successResponse(data, origin, statusCode = 200) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: true,
      data,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function errorResponse(message, origin, statusCode = 400, code = null) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: false,
      error: message,
      ...code && { code },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function handlePreflight(origin) {
  return {
    statusCode: 204,
    headers: getSecureCORSHeaders(origin),
    body: ""
  };
}

// netlify/functions/team-messages.mjs
function getSupabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_SECRET || process.env.SUPABASE_SERVICE_KEY;
  if (!url || !key) {
    return null;
  }
  return createClient2(url, key, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
}
var TEAM_MEMBERS = [
  "commander",
  "tiger",
  "agent_r",
  "frances",
  "nero",
  "alex",
  "ryan",
  "josh_serrano",
  "toby",
  // New operator
  "patrick",
  // New operator
  "all"
  // Broadcast to everyone
];
var COMMANDER_KEY = process.env.COMMANDER_MESSAGE_KEY || "consciousness137";
async function handler(event) {
  const origin = event.headers.origin || event.headers.Origin || "";
  if (event.httpMethod === "OPTIONS") {
    return handlePreflight(origin);
  }
  const supabase = getSupabase();
  if (!supabase) {
    return handleInMemory(event, origin);
  }
  try {
    const clientIP = event.headers["x-forwarded-for"]?.split(",")[0] || "unknown";
    const rateCheck = await checkRateLimitDistributed(clientIP, 60, 6e4);
    if (!rateCheck.allowed) {
      return errorResponse("Rate limit exceeded", origin, 429);
    }
    if (event.httpMethod === "POST") {
      return await sendMessage(event, supabase, origin);
    } else if (event.httpMethod === "GET") {
      return await getMessages(event, supabase, origin);
    } else {
      return errorResponse("Method not allowed", origin, 405);
    }
  } catch (error) {
    console.error("Team messages error:", error);
    return errorResponse("Internal server error", origin, 500);
  }
}
async function sendMessage(event, supabase, origin) {
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return errorResponse("Invalid JSON", origin, 400);
  }
  const { key, to, message, priority, from } = body;
  if (key !== COMMANDER_KEY) {
    return errorResponse("Unauthorized", origin, 401);
  }
  if (!to || !TEAM_MEMBERS.includes(to.toLowerCase())) {
    return errorResponse(`Invalid recipient. Valid: ${TEAM_MEMBERS.join(", ")}`, origin, 400);
  }
  if (!message || message.trim().length === 0) {
    return errorResponse("Message is required", origin, 400);
  }
  const sanitizedMessage = sanitizeString(message, 2e3);
  const sanitizedFrom = sanitizeString(from || "Commander", 50);
  const priorityLevel = ["low", "normal", "high", "urgent"].includes(priority) ? priority : "normal";
  const recipients = to.toLowerCase() === "all" ? TEAM_MEMBERS.filter((m) => m !== "all" && m !== "commander") : [to.toLowerCase()];
  const messages = recipients.map((recipient) => ({
    recipient,
    sender: sanitizedFrom,
    message: sanitizedMessage,
    priority: priorityLevel,
    read: false,
    created_at: (/* @__PURE__ */ new Date()).toISOString()
  }));
  const { data, error } = await supabase.from("team_messages").insert(messages).select();
  if (error) {
    if (error.code === "42P01") {
      return errorResponse("Messages table not set up. Run setup first.", origin, 500);
    }
    console.error("Supabase error:", error);
    return errorResponse("Failed to send message", origin, 500);
  }
  return successResponse({
    sent: true,
    recipients: recipients.length,
    messageId: data?.[0]?.id
  }, origin);
}
async function getMessages(event, supabase, origin) {
  const params = event.queryStringParameters || {};
  const userId = params.user?.toLowerCase();
  const unreadOnly = params.unread === "true";
  const markRead = params.mark_read === "true";
  if (!userId || !TEAM_MEMBERS.includes(userId)) {
    return errorResponse("Valid user parameter required", origin, 400);
  }
  let query = supabase.from("team_messages").select("*").eq("recipient", userId).order("created_at", { ascending: false }).limit(50);
  if (unreadOnly) {
    query = query.eq("read", false);
  }
  const { data, error } = await query;
  if (error) {
    if (error.code === "42P01") {
      return successResponse({ messages: [], count: 0 }, origin);
    }
    console.error("Supabase error:", error);
    return errorResponse("Failed to get messages", origin, 500);
  }
  if (markRead && data && data.length > 0) {
    const unreadIds = data.filter((m) => !m.read).map((m) => m.id);
    if (unreadIds.length > 0) {
      await supabase.from("team_messages").update({ read: true }).in("id", unreadIds);
    }
  }
  return successResponse({
    messages: data || [],
    count: data?.length || 0,
    unread: data?.filter((m) => !m.read).length || 0
  }, origin);
}
var memoryMessages = /* @__PURE__ */ new Map();
function handleInMemory(event, origin) {
  if (event.httpMethod === "POST") {
    let body;
    try {
      body = JSON.parse(event.body || "{}");
    } catch {
      return errorResponse("Invalid JSON", origin, 400);
    }
    const { key, to, message, from } = body;
    if (key !== COMMANDER_KEY) {
      return errorResponse("Unauthorized", origin, 401);
    }
    const recipients = to === "all" ? TEAM_MEMBERS.filter((m) => m !== "all" && m !== "commander") : [to.toLowerCase()];
    recipients.forEach((r) => {
      if (!memoryMessages.has(r)) {
        memoryMessages.set(r, []);
      }
      memoryMessages.get(r).push({
        id: Date.now(),
        message: sanitizeString(message, 2e3),
        sender: from || "Commander",
        created_at: (/* @__PURE__ */ new Date()).toISOString(),
        read: false
      });
    });
    return successResponse({ sent: true, recipients: recipients.length, note: "Using in-memory storage" }, origin);
  } else if (event.httpMethod === "GET") {
    const params = event.queryStringParameters || {};
    const userId = params.user?.toLowerCase();
    if (!userId) {
      return errorResponse("User parameter required", origin, 400);
    }
    const messages = memoryMessages.get(userId) || [];
    return successResponse({
      messages,
      count: messages.length,
      unread: messages.filter((m) => !m.read).length,
      note: "Using in-memory storage"
    }, origin);
  }
  return errorResponse("Method not allowed", origin, 405);
}
var team_messages_default = { handler };
export {
  team_messages_default as default,
  handler
};
