var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/radio-out.mjs
var radio_out_exports = {};
__export(radio_out_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(radio_out_exports);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_KEY;
var PROTECTED_CHANNELS = ["COMMANDER", "SYSTEM", "TRINITY"];
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Radio-Key",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const params = event.queryStringParameters || {};
  const channel = params.channel?.toUpperCase();
  const receiver = params.receiver;
  const limit = Math.min(50, parseInt(params.limit) || 10);
  const markProcessed = params.mark_processed === "true";
  const requiresAuth = PROTECTED_CHANNELS.includes(channel) || markProcessed;
  if (requiresAuth) {
    const authKey = event.headers["x-radio-key"] || event.headers["X-Radio-Key"];
    if (authKey !== process.env.RADIO_API_KEY) {
      console.log(`\u26A0\uFE0F UNAUTHORIZED RADIO-OUT ATTEMPT: ${channel} mark=${markProcessed}`);
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({
          error: "Unauthorized - X-Radio-Key required for protected channels or mark_processed",
          protected_channels: PROTECTED_CHANNELS
        })
      };
    }
  }
  if (!channel) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: "Channel required",
        usage: "/api/radio-out?channel=ARAYA&receiver=user123"
      })
    };
  }
  try {
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          messages: [],
          count: 0,
          note: "Radio operating in local-only mode (no Supabase)"
        })
      };
    }
    let url = `${SUPABASE_URL}/rest/v1/radio_messages?direction=eq.outbound&status=eq.pending&channel=eq.${channel}&order=priority.desc,created_at.asc&limit=${limit}`;
    if (receiver) {
      url += `&receiver=eq.${encodeURIComponent(receiver)}`;
    }
    const response = await fetch(url, {
      headers: {
        "apikey": SUPABASE_KEY,
        "Authorization": `Bearer ${SUPABASE_KEY}`
      }
    });
    if (!response.ok) {
      throw new Error(`Supabase query failed: ${response.status}`);
    }
    const messages = await response.json();
    if (markProcessed && messages.length > 0) {
      const ids = messages.map((m) => m.id);
      const now = (/* @__PURE__ */ new Date()).toISOString();
      for (const id of ids) {
        await fetch(
          `${SUPABASE_URL}/rest/v1/radio_messages?id=eq.${id}`,
          {
            method: "PATCH",
            headers: {
              "apikey": SUPABASE_KEY,
              "Authorization": `Bearer ${SUPABASE_KEY}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              status: "delivered",
              processed_at: now
            })
          }
        );
      }
    }
    const cleaned = messages.map((m) => ({
      id: m.id,
      subject: m.subject,
      content: m.content,
      priority: m.priority,
      created_at: m.created_at,
      response_to: m.response_to,
      metadata: m.metadata ? JSON.parse(m.metadata) : null
    }));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        messages: cleaned,
        count: cleaned.length,
        channel,
        receiver: receiver || "ALL"
      })
    };
  } catch (error) {
    console.error("Radio outbound error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to fetch messages",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
