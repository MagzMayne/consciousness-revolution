var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/evidence-upload.mjs
var evidence_upload_exports = {};
__export(evidence_upload_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(evidence_upload_exports);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_KEY;
function generateReference() {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `EV-${timestamp}-${random}`.toUpperCase();
}
function parseMultipart(body, contentType) {
  const boundary = contentType.split("boundary=")[1];
  if (!boundary) return null;
  const parts = body.split(`--${boundary}`);
  const result = { fields: {}, files: [] };
  for (const part of parts) {
    if (part.includes("Content-Disposition")) {
      const nameMatch = part.match(/name="([^"]+)"/);
      const filenameMatch = part.match(/filename="([^"]+)"/);
      if (filenameMatch) {
        const contentTypeMatch = part.match(/Content-Type:\s*([^\r\n]+)/);
        const dataStart = part.indexOf("\r\n\r\n") + 4;
        const dataEnd = part.lastIndexOf("\r\n");
        const fileData = part.substring(dataStart, dataEnd);
        result.files.push({
          fieldName: nameMatch ? nameMatch[1] : "file",
          filename: filenameMatch[1],
          contentType: contentTypeMatch ? contentTypeMatch[1] : "application/octet-stream",
          data: fileData,
          size: fileData.length
        });
      } else if (nameMatch) {
        const dataStart = part.indexOf("\r\n\r\n") + 4;
        const dataEnd = part.lastIndexOf("\r\n");
        result.fields[nameMatch[1]] = part.substring(dataStart, dataEnd);
      }
    }
  }
  return result;
}
async function logEvidence(reference, uploader, description, files, timestamp) {
  const logEntry = {
    reference,
    uploader,
    description,
    timestamp,
    files: files.map((f) => ({
      name: f.filename,
      size: f.size,
      type: f.contentType
    })),
    ip: "redacted"
    // Privacy
  };
  console.log("=== EVIDENCE UPLOAD ===");
  console.log(JSON.stringify(logEntry, null, 2));
  console.log("=======================");
  if (SUPABASE_URL && SUPABASE_KEY) {
    try {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/evidence_log`,
        {
          method: "POST",
          headers: {
            "apikey": SUPABASE_KEY,
            "Authorization": `Bearer ${SUPABASE_KEY}`,
            "Content-Type": "application/json",
            "Prefer": "return=minimal"
          },
          body: JSON.stringify({
            reference,
            uploader,
            description,
            file_count: files.length,
            file_names: files.map((f) => f.filename),
            total_size: files.reduce((sum, f) => sum + f.size, 0),
            created_at: timestamp
          })
        }
      );
      if (!response.ok) {
        console.log("Supabase log failed (table may not exist):", response.status);
      }
    } catch (e) {
      console.log("Supabase logging error:", e.message);
    }
  }
  return logEntry;
}
async function notifyCommander(reference, uploader, fileCount) {
  console.log(`NOTIFY: ${uploader} uploaded ${fileCount} file(s) - Ref: ${reference}`);
}
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const contentType = event.headers["content-type"] || event.headers["Content-Type"] || "";
    if (contentType.includes("multipart/form-data")) {
      const body = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("binary") : event.body;
      const parsed = parseMultipart(body, contentType);
      if (!parsed || parsed.files.length === 0) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: "No files received" })
        };
      }
      const uploader = parsed.fields.uploader || "Anonymous";
      const description = parsed.fields.description || "";
      const timestamp = parsed.fields.timestamp || (/* @__PURE__ */ new Date()).toISOString();
      const reference = generateReference();
      const logEntry = await logEvidence(
        reference,
        uploader,
        description,
        parsed.files,
        timestamp
      );
      await notifyCommander(reference, uploader, parsed.files.length);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          reference,
          message: `Evidence received from ${uploader}`,
          files_received: parsed.files.length,
          note: "Files logged securely. Derek will be notified."
        })
      };
    }
    const data = JSON.parse(event.body || "{}");
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({
        error: "Please use the upload form",
        hint: "Visit /evidence-upload.html"
      })
    };
  } catch (error) {
    console.error("Evidence upload error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Upload failed",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
