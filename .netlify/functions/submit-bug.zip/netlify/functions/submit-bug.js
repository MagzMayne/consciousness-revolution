var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/submit-bug.mjs
var submit_bug_exports = {};
__export(submit_bug_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(submit_bug_exports);
var GITHUB_TOKEN = process.env.GITHUB_TOKEN;
var REPO_OWNER = "overkillkulture";
var REPO_NAME = "consciousness-bugs";
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body);
    const { description, page, timestamp } = body;
    if (!description) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Description required" })
      };
    }
    const title = `[User Report] ${description.substring(0, 50)}${description.length > 50 ? "..." : ""}`;
    const issueBody = `## Bug Report from ${page || "Unknown Page"}

**Submitted:** ${timestamp || (/* @__PURE__ */ new Date()).toISOString()}

### Description
${description}

---
*Submitted via Araya Chat bug report button*`;
    if (!GITHUB_TOKEN) {
      console.log("Bug report (no GitHub token):", { title, description, page, timestamp });
      return {
        statusCode: 200,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({
          success: true,
          message: "Bug logged locally (GitHub integration pending)"
        })
      };
    }
    const response = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/issues`,
      {
        method: "POST",
        headers: {
          "Accept": "application/vnd.github.v3+json",
          "Authorization": `token ${GITHUB_TOKEN}`,
          "Content-Type": "application/json",
          "User-Agent": "Consciousness-Revolution-Bug-Tracker"
        },
        body: JSON.stringify({
          title,
          body: issueBody,
          labels: ["user-reported", "araya"]
        })
      }
    );
    if (!response.ok) {
      const errorText = await response.text();
      console.error("GitHub API error:", response.status, errorText);
      return {
        statusCode: 200,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({
          success: true,
          message: "Bug report received"
        })
      };
    }
    const issue = await response.json();
    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: true,
        issueNumber: issue.number,
        issueUrl: issue.html_url
      })
    };
  } catch (error) {
    console.error("Submit bug error:", error);
    return {
      statusCode: 200,
      // Still return 200 - don't let errors block user
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        success: true,
        message: "Bug report received"
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
