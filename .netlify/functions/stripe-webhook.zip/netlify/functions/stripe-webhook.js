var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/stripe-webhook.mjs
var stripe_webhook_exports = {};
__export(stripe_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(stripe_webhook_exports);
var import_stripe = __toESM(require("stripe"), 1);
var stripe = new import_stripe.default(process.env.STRIPE_SECRET_KEY);
async function handler(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const sig = event.headers["stripe-signature"];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      webhookSecret
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: `Webhook Error: ${err.message}` })
    };
  }
  switch (stripeEvent.type) {
    case "checkout.session.completed": {
      const session = stripeEvent.data.object;
      console.log("Payment successful for session:", session.id);
      console.log("Customer email:", session.customer_details?.email);
      console.log("Amount total:", session.amount_total);
      const customerEmail = session.customer_details?.email;
      const customerName = session.customer_details?.name || "Consciousness Revolutionary";
      const amountPaid = session.amount_total ? (session.amount_total / 100).toFixed(2) : "0.00";
      const currency = session.currency?.toUpperCase() || "USD";
      if (customerEmail) {
        try {
          const emailResponse = await fetch(
            `${process.env.URL || "https://conciousnessrevolution.io"}/.netlify/functions/send-welcome-email`,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                email: customerEmail,
                name: customerName,
                amount: amountPaid,
                currency,
                sessionId: session.id,
                productName: "Consciousness Revolution Membership"
              })
            }
          );
          const emailResult = await emailResponse.json();
          console.log("Email send result:", emailResult);
        } catch (emailError) {
          console.error("Failed to send welcome email:", emailError);
        }
      }
      break;
    }
    case "customer.subscription.created": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription created:", subscription.id);
      break;
    }
    case "customer.subscription.updated": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription updated:", subscription.id, "Status:", subscription.status);
      break;
    }
    case "customer.subscription.deleted": {
      const subscription = stripeEvent.data.object;
      console.log("Subscription cancelled:", subscription.id);
      break;
    }
    case "invoice.paid": {
      const invoice = stripeEvent.data.object;
      console.log("Invoice paid:", invoice.id);
      break;
    }
    case "invoice.payment_failed": {
      const invoice = stripeEvent.data.object;
      console.log("Invoice payment failed:", invoice.id);
      break;
    }
    default:
      console.log(`Unhandled event type: ${stripeEvent.type}`);
  }
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ received: true })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
