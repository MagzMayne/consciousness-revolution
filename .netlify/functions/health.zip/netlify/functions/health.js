// netlify/functions/health.js
exports.handler = async (event, context) => {
  const response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
    },
    body: JSON.stringify({
      status: "healthy",
      message: "Netlify functions are operational",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      environment: process.env.CONTEXT || "unknown",
      repository: "barbrickdesign.github.io",
      version: "1.0.0"
    })
  };
  return response;
};
