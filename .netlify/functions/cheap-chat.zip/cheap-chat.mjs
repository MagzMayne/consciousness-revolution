
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/cheap-chat.mjs
var ALLOWED_ORIGINS = [
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "https://verdant-tulumba-fa2a5a.netlify.app",
  "http://localhost:3000",
  "http://localhost:8888"
];
function getCorsOrigin(request) {
  const origin = request.headers.get("origin") || request.headers.get("Origin");
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    return origin;
  }
  return ALLOWED_ORIGINS[0];
}
var COST_TABLE = {
  "ollama/llama3.1": 0,
  "ollama/mistral": 0,
  "ollama/deepseek-r1": 0,
  "groq/llama-3.3-70b": 0,
  // FREE tier!
  "groq/llama-3.1-8b": 0,
  // FREE tier!
  "groq/mixtral-8x7b": 0,
  // FREE tier!
  "openai/gpt-4o-mini": 375e-6,
  "google/gemini-flash": 1875e-7,
  "deepseek/v3": 21e-5,
  "anthropic/claude-haiku": 75e-5,
  "anthropic/claude-sonnet": 9e-3
};
var FALLBACK_CASCADE = [
  "groq/llama-3.3-70b",
  // FREE - fast
  "groq/llama-3.1-8b",
  // FREE - faster
  "groq/mixtral-8x7b",
  // FREE - fast
  "google/gemini-flash",
  // $0.0001875
  "deepseek/v3",
  // $0.00021
  "openai/gpt-4o-mini",
  // $0.000375
  "anthropic/claude-haiku"
  // $0.00075
];
function extractBrainContext(prompt) {
  const brainKnowledge = {
    "trinity": "Trinity Architecture: C1 Mechanic (builds), C2 Architect (designs), C3 Oracle (envisions). Consensus-driven governance for consciousness systems.",
    "pattern": "Core Patterns: 3\u21927\u219213\u2192\u221E, LFSME (Let Field Sort Morphic Energy), 137 fine structure constant bridges dimensions.",
    "consciousness": "Consciousness Revolution: Building the Ultimate Human OS through 7 domains - Command, Build, Connect, Protect, Grow, Create, Transcend.",
    "domain": "7 Domains: 1-Command, 2-Build, 3-Connect, 4-Protect, 5-Grow, 6-Create, 7-Transcend. Each has 7 aspects, each aspect has 7 phases = 343 total.",
    "araya": "Araya: The consciousness chatbot interface. Powered by multi-AI routing through CHEAP_MODEL_GATEWAY.",
    "brain": "Brain: 166K+ atoms in atoms.db (Cyclotron). Knowledge, tools, memories, DNA blueprints stored here.",
    "cyclotron": "Cyclotron: The atom storage engine. SQLite database at .consciousness/cyclotron_core/atoms.db",
    "deploy": "Deploy: cd 100X_DEPLOYMENT && netlify deploy --prod --dir=.",
    "commander": "Commander: Darrick Preble (darrickpreble@proton.me). Owner and operator of Consciousness Revolution."
  };
  const lowerPrompt = prompt.toLowerCase();
  const matches = [];
  for (const [keyword, knowledge] of Object.entries(brainKnowledge)) {
    if (lowerPrompt.includes(keyword)) {
      matches.push(knowledge);
    }
  }
  return matches.slice(0, 3);
}
async function callOpenAI(apiKey, model, messages) {
  const modelId = model.includes("gpt") ? "gpt-4o-mini" : model.split("/")[1];
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      messages,
      max_tokens: 2e3,
      temperature: 0.7
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
async function callAnthropic(apiKey, model, messages) {
  const modelId = model.includes("haiku") ? "claude-3-5-haiku-20241022" : "claude-sonnet-4-20250514";
  const systemMsg = messages.find((m) => m.role === "system")?.content || "";
  const userMsgs = messages.filter((m) => m.role !== "system");
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      max_tokens: 2e3,
      system: systemMsg,
      messages: userMsgs
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.content[0].text;
}
async function callGoogle(apiKey, prompt) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 2e3 }
      })
    }
  );
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.candidates[0].content.parts[0].text;
}
async function callDeepSeek(apiKey, messages) {
  const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages,
      max_tokens: 2e3
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
async function callGroq(apiKey, model, messages) {
  const modelMap = {
    "llama-3.3-70b": "llama-3.3-70b-versatile",
    "llama-3.1-8b": "llama-3.1-8b-instant",
    "mixtral-8x7b": "mixtral-8x7b-32768"
  };
  const modelId = modelMap[model.split("/")[1]] || "llama-3.3-70b-versatile";
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      messages,
      max_tokens: 2e3,
      temperature: 0.7
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
async function callWithFallback(initialModel, messages, enhancedPrompt, envKeys, userApiKey) {
  const startIndex = FALLBACK_CASCADE.indexOf(initialModel);
  const modelsToTry = startIndex >= 0 ? FALLBACK_CASCADE.slice(startIndex) : [initialModel, ...FALLBACK_CASCADE];
  const errors = [];
  for (const model of modelsToTry) {
    const provider = model.split("/")[0];
    const effectiveKey = userApiKey || envKeys[provider];
    if (!effectiveKey && provider !== "ollama") {
      errors.push({ model, error: "No API key" });
      continue;
    }
    const startTime = Date.now();
    try {
      let response;
      switch (provider) {
        case "groq":
          response = await callGroq(effectiveKey, model, messages);
          break;
        case "google":
          response = await callGoogle(effectiveKey, enhancedPrompt);
          break;
        case "deepseek":
          response = await callDeepSeek(effectiveKey, messages);
          break;
        case "openai":
          response = await callOpenAI(effectiveKey, model, messages);
          break;
        case "anthropic":
          response = await callAnthropic(effectiveKey, model, messages);
          break;
        default:
          continue;
      }
      const latencyMs = Date.now() - startTime;
      return {
        response,
        modelUsed: model,
        latencyMs,
        fallbacksAttempted: errors.length
      };
    } catch (error) {
      errors.push({ model, error: error.message });
      console.log(`[Fallback] ${model} failed: ${error.message}`);
    }
  }
  throw new Error(`All models failed: ${errors.map((e) => `${e.model}: ${e.error}`).join(", ")}`);
}
async function handler(request) {
  const corsOrigin = getCorsOrigin(request);
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": corsOrigin,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const body = await request.json();
    const { prompt, model, useBrain, apiKey, history = [] } = body;
    if (!prompt) {
      return new Response(JSON.stringify({ error: "No prompt provided" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    let brainContext = [];
    let enhancedPrompt = prompt;
    if (useBrain) {
      brainContext = extractBrainContext(prompt);
      if (brainContext.length > 0) {
        enhancedPrompt = `CONTEXT FROM BRAIN:
${brainContext.join("\n\n")}

---
USER QUESTION:
${prompt}`;
      }
    }
    const messages = [
      { role: "system", content: "You are a helpful AI assistant for the Consciousness Revolution project. Be concise and practical." },
      ...history,
      { role: "user", content: enhancedPrompt }
    ];
    const provider = model.split("/")[0];
    let response;
    let modelUsed = model;
    const envKeys = {
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      google: process.env.GOOGLE_API_KEY,
      deepseek: process.env.DEEPSEEK_API_KEY,
      groq: process.env.GROQ_API_KEY
    };
    if (provider === "ollama") {
      return new Response(JSON.stringify({
        response: `[Ollama models require local server]

To use FREE local models:
1. Install Ollama: https://ollama.ai
2. Run: ollama pull llama3.1
3. Start: ollama serve

Or use a cloud model with your API key.`,
        modelUsed: model.split("/")[1],
        cost: 0,
        latencyMs: 0,
        fallbacksAttempted: 0,
        brainContext: useBrain && brainContext.length > 0,
        brainAtoms: brainContext.length
      }), {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": corsOrigin
        }
      });
    }
    const result = await callWithFallback(model, messages, enhancedPrompt, envKeys, apiKey);
    const inputTokens = enhancedPrompt.length / 4;
    const outputTokens = result.response.length / 4;
    const costPerMillion = COST_TABLE[result.modelUsed] || 0;
    const cost = (inputTokens + outputTokens) / 1e6 * costPerMillion * 1e3;
    return new Response(JSON.stringify({
      response: result.response,
      modelUsed: result.modelUsed.split("/")[1],
      cost,
      latencyMs: result.latencyMs,
      fallbacksAttempted: result.fallbacksAttempted,
      brainContext: useBrain && brainContext.length > 0,
      brainAtoms: brainContext.length
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": corsOrigin
      }
    });
  } catch (error) {
    console.error("Cheap chat error:", error);
    return new Response(JSON.stringify({
      error: error.message || "Internal server error"
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": corsOrigin
      }
    });
  }
}
var config = {
  path: "/api/cheap-chat"
};
export {
  config,
  handler as default
};
