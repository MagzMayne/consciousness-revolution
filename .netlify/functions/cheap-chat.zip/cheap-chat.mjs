
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/cheap-chat.mjs
var COST_TABLE = {
  "ollama/llama3.1": 0,
  "ollama/mistral": 0,
  "ollama/deepseek-r1": 0,
  "openai/gpt-4o-mini": 375e-6,
  "google/gemini-flash": 1875e-7,
  "deepseek/v3": 21e-5,
  "anthropic/claude-haiku": 75e-5,
  "anthropic/claude-sonnet": 9e-3
};
function extractBrainContext(prompt) {
  const brainKnowledge = {
    "trinity": "Trinity Architecture: C1 Mechanic (builds), C2 Architect (designs), C3 Oracle (envisions). Consensus-driven governance for consciousness systems.",
    "pattern": "Core Patterns: 3\u21927\u219213\u2192\u221E, LFSME (Let Field Sort Morphic Energy), 137 fine structure constant bridges dimensions.",
    "consciousness": "Consciousness Revolution: Building the Ultimate Human OS through 7 domains - Command, Build, Connect, Protect, Grow, Create, Transcend.",
    "domain": "7 Domains: 1-Command, 2-Build, 3-Connect, 4-Protect, 5-Grow, 6-Create, 7-Transcend. Each has 7 aspects, each aspect has 7 phases = 343 total.",
    "araya": "Araya: The consciousness chatbot interface. Powered by multi-AI routing through CHEAP_MODEL_GATEWAY.",
    "brain": "Brain: 166K+ atoms in atoms.db (Cyclotron). Knowledge, tools, memories, DNA blueprints stored here.",
    "cyclotron": "Cyclotron: The atom storage engine. SQLite database at .consciousness/cyclotron_core/atoms.db",
    "deploy": "Deploy: cd 100X_DEPLOYMENT && netlify deploy --prod --dir=.",
    "commander": "Commander: Darrick Preble (darrickpreble@proton.me). Owner and operator of Consciousness Revolution."
  };
  const lowerPrompt = prompt.toLowerCase();
  const matches = [];
  for (const [keyword, knowledge] of Object.entries(brainKnowledge)) {
    if (lowerPrompt.includes(keyword)) {
      matches.push(knowledge);
    }
  }
  return matches.slice(0, 3);
}
async function callOpenAI(apiKey, model, messages) {
  const modelId = model.includes("gpt") ? "gpt-4o-mini" : model.split("/")[1];
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      messages,
      max_tokens: 2e3,
      temperature: 0.7
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
async function callAnthropic(apiKey, model, messages) {
  const modelId = model.includes("haiku") ? "claude-3-5-haiku-20241022" : "claude-sonnet-4-20250514";
  const systemMsg = messages.find((m) => m.role === "system")?.content || "";
  const userMsgs = messages.filter((m) => m.role !== "system");
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      max_tokens: 2e3,
      system: systemMsg,
      messages: userMsgs
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.content[0].text;
}
async function callGoogle(apiKey, prompt) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 2e3 }
      })
    }
  );
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.candidates[0].content.parts[0].text;
}
async function callDeepSeek(apiKey, messages) {
  const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages,
      max_tokens: 2e3
    })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error.message);
  return data.choices[0].message.content;
}
async function handler(request) {
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const body = await request.json();
    const { prompt, model, useBrain, apiKey, history = [] } = body;
    if (!prompt) {
      return new Response(JSON.stringify({ error: "No prompt provided" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    let brainContext = [];
    let enhancedPrompt = prompt;
    if (useBrain) {
      brainContext = extractBrainContext(prompt);
      if (brainContext.length > 0) {
        enhancedPrompt = `CONTEXT FROM BRAIN:
${brainContext.join("\n\n")}

---
USER QUESTION:
${prompt}`;
      }
    }
    const messages = [
      { role: "system", content: "You are a helpful AI assistant for the Consciousness Revolution project. Be concise and practical." },
      ...history,
      { role: "user", content: enhancedPrompt }
    ];
    const provider = model.split("/")[0];
    let response;
    let modelUsed = model;
    const envKeys = {
      openai: process.env.OPENAI_API_KEY,
      anthropic: process.env.ANTHROPIC_API_KEY,
      google: process.env.GOOGLE_API_KEY,
      deepseek: process.env.DEEPSEEK_API_KEY
    };
    const effectiveKey = apiKey || envKeys[provider];
    if (!effectiveKey && provider !== "ollama") {
      return new Response(JSON.stringify({
        error: `No API key for ${provider}. Please add your key in settings or use a FREE local model.`,
        brainContext: useBrain,
        brainAtoms: brainContext.length
      }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    switch (provider) {
      case "ollama":
        response = `[Ollama models require local server]

To use FREE local models:
1. Install Ollama: https://ollama.ai
2. Run: ollama pull llama3.1
3. Start: ollama serve

Or use a cloud model with your API key.`;
        break;
      case "openai":
        response = await callOpenAI(effectiveKey, model, messages);
        break;
      case "anthropic":
        response = await callAnthropic(effectiveKey, model, messages);
        break;
      case "google":
        response = await callGoogle(effectiveKey, enhancedPrompt);
        break;
      case "deepseek":
        response = await callDeepSeek(effectiveKey, messages);
        break;
      default:
        response = `Unknown provider: ${provider}`;
    }
    const inputTokens = enhancedPrompt.length / 4;
    const outputTokens = response.length / 4;
    const costPerMillion = COST_TABLE[model] || 0;
    const cost = (inputTokens + outputTokens) / 1e6 * costPerMillion * 1e3;
    return new Response(JSON.stringify({
      response,
      modelUsed: modelUsed.split("/")[1],
      cost,
      brainContext: useBrain && brainContext.length > 0,
      brainAtoms: brainContext.length
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    console.error("Cheap chat error:", error);
    return new Response(JSON.stringify({
      error: error.message || "Internal server error"
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
}
var config = {
  path: "/api/cheap-chat"
};
export {
  config,
  handler as default
};
