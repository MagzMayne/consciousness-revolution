
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/email-list.mjs
import { createClient } from "@supabase/supabase-js";
var supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
var email_list_default = async (req) => {
  try {
    const url = new URL(req.url);
    const source = url.searchParams.get("source");
    let query = supabase.from("email_signups").select("*").order("created_at", { ascending: false });
    if (source) {
      query = query.eq("source", source);
    }
    const { data, error } = await query.limit(100);
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    const summary = {};
    data.forEach((row) => {
      summary[row.source] = (summary[row.source] || 0) + 1;
    });
    return new Response(JSON.stringify({
      signups: data,
      total: data.length,
      by_source: summary
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = { path: "/api/email-list" };
export {
  config,
  email_list_default as default
};
