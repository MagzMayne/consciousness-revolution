var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/brain-api.mjs
var brain_api_exports = {};
__export(brain_api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(brain_api_exports);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;
async function supabase(table, method, data = null, query = "") {
  const url = `${SUPABASE_URL}/rest/v1/${table}${query}`;
  const options = {
    method,
    headers: {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": method === "POST" ? "return=representation" : "return=minimal"
    }
  };
  if (data) {
    options.body = JSON.stringify(data);
  }
  const response = await fetch(url, options);
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Supabase error: ${error}`);
  }
  if (method === "HEAD") {
    return { count: parseInt(response.headers.get("content-range")?.split("/")[1] || "0") };
  }
  if (method === "GET" || method === "POST") {
    return response.json();
  }
  return null;
}
async function getAtomCount() {
  const url = `${SUPABASE_URL}/rest/v1/atoms?select=id`;
  const response = await fetch(url, {
    method: "HEAD",
    headers: {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Prefer": "count=exact"
    }
  });
  const range = response.headers.get("content-range");
  if (range) {
    const total = range.split("/")[1];
    return parseInt(total) || 0;
  }
  return 0;
}
function scoreAtom(atom, query) {
  const content = (atom.content || "").toLowerCase();
  const queryLower = query.toLowerCase();
  const queryWords = queryLower.split(/\s+/).filter((w) => w.length > 2);
  let score = 0;
  if (content.includes(queryLower)) score += 10;
  for (const word of queryWords) {
    if (content.includes(word)) score += 2;
  }
  const typeWeights = {
    "knowledge": 1.5,
    "pattern": 1.4,
    "insight": 1.3,
    "concept": 1.2,
    "fact": 1.1,
    "ability": 1,
    "action": 0.9,
    "boot": 0.8
  };
  score *= typeWeights[atom.type] || 1;
  const domainWeights = {
    "7_TRANSCEND": 1.3,
    "1_COMMAND": 1.2,
    "2_BUILD": 1.1,
    "4_PROTECT": 1.1
  };
  score *= domainWeights[atom.domain] || 1;
  return score;
}
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, x-api-key",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  const path = event.path.replace("/.netlify/functions/brain-api", "").replace("/api/brain-api", "");
  const action = path.split("/")[1] || event.queryStringParameters?.action || "status";
  if (action === "log" || action === "sync") {
    const authKey = event.headers["x-api-key"];
    if (authKey !== process.env.BRAIN_API_KEY) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Unauthorized - valid x-api-key required for write operations" })
      };
    }
  }
  try {
    if (!SUPABASE_URL || !SUPABASE_KEY) {
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({
          error: "Brain not configured",
          details: "Supabase credentials missing"
        })
      };
    }
    switch (action) {
      // GET /brain-api/status - Brain health and stats
      case "status": {
        const atomCount = await getAtomCount();
        const latest = await supabase(
          "atoms",
          "GET",
          null,
          "?select=created&order=created.desc&limit=1"
        );
        const types = await supabase(
          "atoms",
          "GET",
          null,
          "?select=type&limit=1000"
        );
        const typeCount = {};
        if (types) {
          types.forEach((a) => {
            typeCount[a.type] = (typeCount[a.type] || 0) + 1;
          });
        }
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            status: "online",
            brain: "cyclotron",
            atom_count: atomCount,
            last_sync: latest?.[0]?.created || null,
            type_distribution: typeCount,
            capabilities: ["query", "context", "log", "sync"],
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/query?q=keyword - Search atoms
      case "query": {
        let query = "";
        let limit = 10;
        let type = null;
        let domain = null;
        if (event.httpMethod === "POST") {
          const body = JSON.parse(event.body || "{}");
          query = body.query || body.q || "";
          limit = Math.min(body.limit || 10, 50);
          type = body.type;
          domain = body.domain;
        } else {
          query = event.queryStringParameters?.q || event.queryStringParameters?.query || "";
          limit = Math.min(parseInt(event.queryStringParameters?.limit) || 10, 50);
          type = event.queryStringParameters?.type;
          domain = event.queryStringParameters?.domain;
        }
        if (!query) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: "Missing query parameter (q or query)" })
          };
        }
        let atoms = [];
        let searchMethod = "fts";
        try {
          const tsQuery = query.trim().split(/\s+/).filter((w) => w.length > 2).join(" & ");
          if (tsQuery) {
            let queryString = `?select=id,content,type,domain,created&limit=100`;
            queryString += `&content=fts.${encodeURIComponent(tsQuery)}`;
            if (type) {
              queryString += `&type=eq.${type}`;
            }
            if (domain) {
              queryString += `&domain=eq.${domain}`;
            }
            queryString += "&order=created.desc";
            atoms = await supabase("atoms", "GET", null, queryString);
          }
        } catch (ftsError) {
          searchMethod = "fallback";
        }
        if ((!atoms || atoms.length === 0) && (type || domain)) {
          searchMethod = "filtered_ilike";
          let queryString = `?select=id,content,type,domain,created&limit=50`;
          if (type) {
            queryString += `&type=eq.${type}`;
          }
          if (domain) {
            queryString += `&domain=eq.${domain}`;
          }
          queryString += `&content=ilike.*${encodeURIComponent(query)}*`;
          queryString += "&order=created.desc";
          try {
            atoms = await supabase("atoms", "GET", null, queryString);
          } catch (ilikeError) {
            atoms = [];
          }
        }
        if (!atoms || atoms.length === 0) {
          searchMethod = "recent_filter";
          let queryString = `?select=id,content,type,domain,created&limit=500&order=created.desc`;
          if (type) {
            queryString += `&type=eq.${type}`;
          }
          if (domain) {
            queryString += `&domain=eq.${domain}`;
          }
          const recentAtoms = await supabase("atoms", "GET", null, queryString);
          const queryLower = query.toLowerCase();
          atoms = (recentAtoms || []).filter(
            (a) => a.content && a.content.toLowerCase().includes(queryLower)
          );
        }
        const scored = (atoms || []).map((atom) => ({ ...atom, score: scoreAtom(atom, query) })).filter((a) => a.score > 0).sort((a, b) => b.score - a.score).slice(0, limit).map(({ score, ...atom }) => atom);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            query,
            count: scored.length,
            atoms: scored,
            search_method: searchMethod,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/context - Get recent session context
      case "context": {
        const limit = Math.min(
          parseInt(event.queryStringParameters?.limit) || 20,
          100
        );
        const domain = event.queryStringParameters?.domain;
        let queryString = `?select=id,content,type,domain,created&order=created.desc&limit=${limit}`;
        if (domain) {
          queryString += `&domain=eq.${domain}`;
        }
        const atoms = await supabase("atoms", "GET", null, queryString);
        const byType = {};
        (atoms || []).forEach((atom) => {
          if (!byType[atom.type]) byType[atom.type] = [];
          byType[atom.type].push(atom);
        });
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            context: {
              recent_atoms: atoms || [],
              by_type: byType,
              total: atoms?.length || 0
            },
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // POST /brain-api/log - Log new interaction to brain
      case "log": {
        if (event.httpMethod !== "POST") {
          return {
            statusCode: 405,
            headers: corsHeaders,
            body: JSON.stringify({ error: "POST required for logging" })
          };
        }
        const body = JSON.parse(event.body || "{}");
        const { content, type = "interaction", domain = "ARAYA", metadata = {} } = body;
        if (!content) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: "content required" })
          };
        }
        const atom = {
          content,
          type,
          domain,
          source: "cloud_araya",
          metadata: JSON.stringify(metadata),
          created: (/* @__PURE__ */ new Date()).toISOString()
        };
        const result = await supabase("atoms", "POST", atom);
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            success: true,
            atom_id: result?.[0]?.id,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/sync - Get atoms for local sync (paginated)
      case "sync": {
        const limit = Math.min(
          parseInt(event.queryStringParameters?.limit) || 100,
          500
        );
        const offset = parseInt(event.queryStringParameters?.offset) || 0;
        const since = event.queryStringParameters?.since;
        let queryString = `?select=id,content,type,domain,created&order=created.desc&limit=${limit}&offset=${offset}`;
        if (since) {
          queryString += `&created=gt.${since}`;
        }
        const atoms = await supabase("atoms", "GET", null, queryString);
        const totalCount = await getAtomCount();
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            atoms: atoms || [],
            pagination: {
              limit,
              offset,
              returned: atoms?.length || 0,
              total: totalCount,
              has_more: offset + (atoms?.length || 0) < totalCount
            },
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/domains - Get domain statistics
      case "domains": {
        const sample = await supabase(
          "atoms",
          "GET",
          null,
          "?select=domain&limit=5000"
        );
        const domainCount = {};
        (sample || []).forEach((a) => {
          if (a.domain) {
            domainCount[a.domain] = (domainCount[a.domain] || 0) + 1;
          }
        });
        const sorted = Object.entries(domainCount).sort((a, b) => b[1] - a[1]).map(([domain, count]) => ({ domain, count }));
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            domains: sorted,
            total_sampled: sample?.length || 0,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/types - Get type statistics
      case "types": {
        const sample = await supabase(
          "atoms",
          "GET",
          null,
          "?select=type&limit=5000"
        );
        const typeCount = {};
        (sample || []).forEach((a) => {
          if (a.type) {
            typeCount[a.type] = (typeCount[a.type] || 0) + 1;
          }
        });
        const sorted = Object.entries(typeCount).sort((a, b) => b[1] - a[1]).map(([type, count]) => ({ type, count }));
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            types: sorted,
            total_sampled: sample?.length || 0,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      // GET /brain-api/recent - Get most recent atoms
      case "recent": {
        const limit = Math.min(
          parseInt(event.queryStringParameters?.limit) || 20,
          100
        );
        const atoms = await supabase(
          "atoms",
          "GET",
          null,
          `?select=id,content,type,domain,created&order=created.desc&limit=${limit}`
        );
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify({
            atoms: atoms || [],
            count: atoms?.length || 0,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          })
        };
      }
      default:
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({
            error: "Unknown action",
            available_actions: ["status", "query", "context", "log", "sync", "domains", "types", "recent"],
            usage: {
              status: "GET /brain-api/status",
              query: "GET /brain-api/query?q=keyword&limit=10",
              context: "GET /brain-api/context?limit=20",
              log: "POST /brain-api/log { content, type, domain }",
              sync: "GET /brain-api/sync?limit=100&offset=0",
              domains: "GET /brain-api/domains",
              types: "GET /brain-api/types",
              recent: "GET /brain-api/recent?limit=20"
            }
          })
        };
    }
  } catch (error) {
    console.error("Brain API Error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: error.message,
        action,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
