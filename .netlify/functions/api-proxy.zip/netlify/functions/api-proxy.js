// netlify/functions/api-proxy.js
var https = require("https");
var http = require("http");
var ALLOWED_TARGETS = [
  "api.deepseek.com",
  "api.anthropic.com",
  "api.openai.com",
  "api.groq.com",
  "api.together.ai",
  "api.replicate.com",
  "api.huggingface.co",
  "api.cohere.ai",
  "api.stripe.com",
  "api.paypal.com",
  "api.github.com"
];
function validateProxyTarget(url) {
  try {
    const urlObj = new URL(url);
    if (urlObj.protocol !== "https:") {
      return { allowed: false, hostname: null, error: "Only HTTPS URLs are allowed" };
    }
    const hostname = urlObj.hostname.toLowerCase();
    const isAllowed = ALLOWED_TARGETS.some(
      (target) => hostname === target || hostname.endsWith("." + target)
    );
    if (!isAllowed) {
      console.warn(`[SSRF BLOCKED] Attempted proxy to non-whitelisted host: ${hostname}`);
      return { allowed: false, hostname, error: `Target host not allowed: ${hostname}` };
    }
    if (hostname === "localhost" || hostname === "127.0.0.1" || hostname.startsWith("192.168.") || hostname.startsWith("10.") || hostname.startsWith("172.") || hostname.endsWith(".local")) {
      return { allowed: false, hostname, error: "Private/internal addresses not allowed" };
    }
    return { allowed: true, hostname, error: null };
  } catch (e) {
    return { allowed: false, hostname: null, error: "Invalid URL format" };
  }
}
exports.handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
      },
      body: ""
    };
  }
  try {
    const params = event.queryStringParameters || {};
    const targetUrl = params.url;
    if (!targetUrl) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: "Missing required parameter: url",
          usage: "/api/proxy?url=https://api.example.com/endpoint",
          allowedTargets: ALLOWED_TARGETS
        })
      };
    }
    const validation = validateProxyTarget(targetUrl);
    if (!validation.allowed) {
      return {
        statusCode: 403,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          error: "Forbidden",
          message: validation.error,
          allowedTargets: ALLOWED_TARGETS
        })
      };
    }
    const response = await makeRequest(targetUrl, event.httpMethod, event.body);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
      },
      body: JSON.stringify({
        success: true,
        data: response,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("Proxy error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  }
};
function makeRequest(url, method = "GET", body = null) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const client = urlObj.protocol === "https:" ? https : http;
    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port,
      path: urlObj.pathname + urlObj.search,
      method,
      headers: {
        "User-Agent": "Netlify-Function/1.0"
      }
    };
    if (body) {
      options.headers["Content-Type"] = "application/json";
      options.headers["Content-Length"] = Buffer.byteLength(body);
    }
    const req = client.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
      });
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed);
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on("error", (error) => {
      reject(error);
    });
    if (body) {
      req.write(body);
    }
    req.end();
  });
}
