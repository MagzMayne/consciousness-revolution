var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/paypal-payout.mjs
var paypal_payout_exports = {};
__export(paypal_payout_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(paypal_payout_exports);
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function paypalApiBase() {
  return process.env.PAYPAL_MODE === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
}
function buildFallbackUrl(recipientEmail, amount) {
  const encoded = encodeURIComponent(recipientEmail);
  return `https://www.paypal.com/myaccount/transfer/send?emailAddress=${encoded}&amount=${amount}&currencyCode=USD`;
}
async function getAccessToken() {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new Error("PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET are not configured in environment variables.");
  }
  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const response = await fetch(`${paypalApiBase()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials"
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`PayPal auth failed (${response.status}): ${text}`);
  }
  const data = await response.json();
  return data.access_token;
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, error: "Method not allowed" })
    };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return {
      statusCode: 400,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, error: "Invalid JSON body" })
    };
  }
  const { recipientEmail, amount, note = "Payroll payment \u2014 Consciousness Revolution", memberId = "" } = body;
  if (!recipientEmail || !amount) {
    return {
      statusCode: 400,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, error: "recipientEmail and amount are required" })
    };
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail)) {
    return {
      statusCode: 400,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, error: "Invalid recipientEmail format" })
    };
  }
  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return {
      statusCode: 400,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ success: false, error: "amount must be a positive number" })
    };
  }
  const amountStr = parsedAmount.toFixed(2);
  const fallbackUrl = buildFallbackUrl(recipientEmail, amountStr);
  const hasCredentials = Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);
  if (!hasCredentials) {
    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({
        success: false,
        apiError: "PayPal credentials are not configured. Use the manual payment link.",
        fallbackUrl,
        requiresManual: true
      })
    };
  }
  try {
    const accessToken = await getAccessToken();
    const senderBatchId = `payroll_${memberId}_${Date.now()}`;
    const payoutPayload = {
      sender_batch_header: {
        sender_batch_id: senderBatchId,
        email_subject: "You have received a payment from Consciousness Revolution",
        email_message: note
      },
      items: [
        {
          recipient_type: "EMAIL",
          amount: { value: amountStr, currency: "USD" },
          note,
          receiver: recipientEmail,
          sender_item_id: `item_${Date.now()}`
        }
      ]
    };
    const response = await fetch(`${paypalApiBase()}/v1/payments/payouts`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payoutPayload)
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || `PayPal Payouts API error (${response.status})`);
    }
    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        payoutId: data.batch_header?.payout_batch_id,
        status: data.batch_header?.batch_status,
        fallbackUrl
      })
    };
  } catch (err) {
    console.error("PayPal payout error:", err.message);
    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({
        success: false,
        apiError: err.message,
        fallbackUrl,
        requiresManual: true
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
