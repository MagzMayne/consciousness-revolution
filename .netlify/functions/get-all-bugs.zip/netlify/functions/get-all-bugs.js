var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-all-bugs.mjs
var get_all_bugs_exports = {};
__export(get_all_bugs_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_all_bugs_exports);
var GITHUB_TOKEN = process.env.GITHUB_TOKEN;
var REPO_OWNER = "overkillkulture";
var REPO_NAME = "consciousness-bugs";
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "GET, OPTIONS"
      },
      body: ""
    };
  }
  try {
    const headers = {
      "Accept": "application/vnd.github.v3+json",
      "User-Agent": "Consciousness-Revolution-Bug-Tracker"
    };
    if (GITHUB_TOKEN) {
      headers["Authorization"] = `token ${GITHUB_TOKEN}`;
    }
    const response = await fetch(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/issues?state=all&per_page=100`,
      { headers }
    );
    if (!response.ok) {
      if (response.status === 404) {
        return {
          statusCode: 200,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ bugs: [], message: "Bug repo not found" })
        };
      }
      throw new Error(`GitHub API error: ${response.status}`);
    }
    const issues = await response.json();
    const bugs = issues.map((issue) => ({
      id: issue.number,
      title: issue.title,
      description: issue.body || "",
      status: issue.state,
      priority: issue.labels.find((l) => l.name.includes("priority"))?.name || "normal",
      labels: issue.labels.map((l) => l.name),
      created: issue.created_at,
      updated: issue.updated_at,
      url: issue.html_url
    }));
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=60"
        // Cache for 1 minute
      },
      body: JSON.stringify({
        bugs,
        total: bugs.length,
        open: bugs.filter((b) => b.status === "open").length,
        closed: bugs.filter((b) => b.status === "closed").length,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("Get bugs error:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Failed to fetch bugs", bugs: [] })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
