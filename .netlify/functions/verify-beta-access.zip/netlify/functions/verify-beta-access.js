var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/verify-beta-access.mjs
var verify_beta_access_exports = {};
__export(verify_beta_access_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(verify_beta_access_exports);
var import_crypto2 = __toESM(require("crypto"), 1);

// netlify/functions/utils/security.mjs
var import_crypto = __toESM(require("crypto"), 1);
var ALLOWED_ORIGINS = [
  "https://consciousnessrevolution.io",
  "https://www.consciousnessrevolution.io",
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "http://localhost:8888",
  "http://localhost:3000",
  "http://127.0.0.1:8888"
];
function getSecureCORSHeaders(origin) {
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Max-Age": "86400",
    // 24 hours
    "Content-Type": "application/json",
    // Security headers
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(), camera=()"
  };
}
var rateLimitStore = /* @__PURE__ */ new Map();
function checkRateLimit(identifier, maxRequests = 100, windowMs = 6e4) {
  const now = Date.now();
  const key = `rate_${identifier}`;
  if (!rateLimitStore.has(key)) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  const record = rateLimitStore.get(key);
  if (now > record.resetAt) {
    rateLimitStore.set(key, {
      count: 1,
      resetAt: now + windowMs
    });
    return { allowed: true, resetAt: now + windowMs };
  }
  if (record.count >= maxRequests) {
    return { allowed: false, resetAt: record.resetAt };
  }
  record.count++;
  rateLimitStore.set(key, record);
  return { allowed: true, resetAt: record.resetAt };
}
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of rateLimitStore.entries()) {
    if (now > record.resetAt + 6e4) {
      rateLimitStore.delete(key);
    }
  }
}, 3e5);
function anonymizeIP(ip) {
  if (!ip) return null;
  if (ip.includes(".")) {
    const parts = ip.split(".");
    if (parts.length === 4) {
      return `${parts[0]}.${parts[1]}.${parts[2]}.0`;
    }
  }
  if (ip.includes(":")) {
    const parts = ip.split(":");
    if (parts.length >= 4) {
      return `${parts[0]}:${parts[1]}:${parts[2]}:${parts[3]}::`;
    }
  }
  return null;
}
var ENCRYPTION_KEY = process.env.DATA_ENCRYPTION_KEY;
function successResponse(data, origin, statusCode = 200) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: true,
      data,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function errorResponse(message, origin, statusCode = 400, code = null) {
  return {
    statusCode,
    headers: getSecureCORSHeaders(origin),
    body: JSON.stringify({
      success: false,
      error: message,
      ...code && { code },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
}
function handlePreflight(origin) {
  return {
    statusCode: 204,
    headers: getSecureCORSHeaders(origin),
    body: ""
  };
}

// netlify/functions/verify-beta-access.mjs
function hashPassword(password) {
  return import_crypto2.default.createHash("sha256").update(password).digest("hex");
}
async function handler(event, context) {
  const origin = event.headers.origin || event.headers.Origin || "";
  if (event.httpMethod === "OPTIONS") {
    return handlePreflight(origin);
  }
  if (event.httpMethod !== "POST") {
    return errorResponse("Method not allowed", origin, 405);
  }
  const clientIP = event.headers["x-forwarded-for"]?.split(",")[0] || "unknown";
  const rateLimitCheck = checkRateLimit(`beta_${anonymizeIP(clientIP)}`, 5, 9e5);
  if (!rateLimitCheck.allowed) {
    return errorResponse("Too many attempts. Please try again later.", origin, 429);
  }
  try {
    const { password } = JSON.parse(event.body || "{}");
    if (!password || typeof password !== "string") {
      return errorResponse("Access code required", origin, 400);
    }
    const expectedPassword = process.env.BETA_ACCESS_CODE || "consciousness2025";
    const providedHash = hashPassword(password);
    const expectedHash = hashPassword(expectedPassword);
    if (import_crypto2.default.timingSafeEqual(Buffer.from(providedHash), Buffer.from(expectedHash))) {
      const accessToken = import_crypto2.default.randomBytes(32).toString("hex");
      const expiresAt = Date.now() + 24 * 60 * 60 * 1e3;
      return successResponse({
        valid: true,
        accessToken,
        expiresAt,
        redirectUrl: "/100x-work-area.html"
      }, origin);
    } else {
      return errorResponse("Invalid access code", origin, 401);
    }
  } catch (error) {
    console.error("Beta access error:", error);
    return errorResponse("Server error", origin, 500);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
