var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/sam-gov-token.mjs
var sam_gov_token_exports = {};
__export(sam_gov_token_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(sam_gov_token_exports);
var SAM_API_KEY = process.env.SAM_API_KEY || null;
var ALLOWED_ORIGINS = [
  "https://consciousnessrevolution.io",
  "https://www.consciousnessrevolution.io",
  "https://conciousnessrevolution.io",
  "https://www.conciousnessrevolution.io",
  "http://localhost:8888",
  "http://localhost:3000",
  "http://127.0.0.1:8888"
];
var _rateLimitMap = /* @__PURE__ */ new Map();
var RATE_LIMIT_MAX = 10;
var RATE_LIMIT_WINDOW_MS = 6e4;
function checkRateLimit(ip) {
  const now = Date.now();
  const entry = _rateLimitMap.get(ip) || { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + RATE_LIMIT_WINDOW_MS;
  }
  entry.count += 1;
  _rateLimitMap.set(ip, entry);
  return entry.count <= RATE_LIMIT_MAX;
}
function getCorsOrigin(origin) {
  if (ALLOWED_ORIGINS.includes(origin)) return origin;
  return "null";
}
var handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || "";
  const corsOrigin = getCorsOrigin(origin);
  const headers = {
    "Access-Control-Allow-Origin": corsOrigin,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  const clientIP = (event.headers?.["x-forwarded-for"] || "no-xff").split(",")[0].trim();
  if (!checkRateLimit(clientIP)) {
    return {
      statusCode: 429,
      headers: { ...headers, "Retry-After": "60" },
      body: JSON.stringify({ error: "Too many requests \u2014 try again in 60 s" })
    };
  }
  const auth = Boolean(SAM_API_KEY);
  if (!auth) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        auth: false,
        token: null,
        api_error: null,
        message: "Server secret missing or invalid \u2014 check repository secrets configuration (SAM_API_KEY)."
      })
    };
  }
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      auth: true,
      token: SAM_API_KEY,
      api_error: null,
      message: "Token loaded from server secret."
    })
  };
};
var config = {
  path: "/api/sam-gov-token"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
