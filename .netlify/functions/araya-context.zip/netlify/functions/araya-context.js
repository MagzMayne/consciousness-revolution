var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/araya-context.mjs
var araya_context_exports = {};
__export(araya_context_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(araya_context_exports);
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { tier, domain } = JSON.parse(event.body);
    console.log(`[ARAYA CONTEXT] Request: tier=${tier}, domain=${domain}`);
    const contextData = {
      // ──────────────────────────────────────────────────────────
      // PERSONAL MODE - Your workspace
      // ──────────────────────────────────────────────────────────
      personal: {
        tasks: [
          { id: 1, title: "Complete ARAYA HUD wiring", domain: "BUILD", priority: "high", status: "in-progress" },
          { id: 2, title: "Review payment integration", domain: "SUSTAIN", priority: "medium", status: "pending" },
          { id: 3, title: "Update voice system", domain: "CONNECT", priority: "low", status: "pending" }
        ],
        stats: {
          xp: 847,
          level: 4,
          streak: 12,
          tasks_pending: 5,
          tasks_completed: 23
        },
        recent_activity: [
          { action: "Completed task: Wire hamburger menu", timestamp: "2 hours ago" },
          { action: "Earned 50 XP from quest", timestamp: "5 hours ago" },
          { action: "Explored SUSTAIN domain", timestamp: "1 day ago" }
        ]
      },
      // ──────────────────────────────────────────────────────────
      // TEAM MODE - Builder collaboration
      // ──────────────────────────────────────────────────────────
      team: {
        builders: [
          {
            name: "Tiger",
            status: "online",
            task: "Voice integration",
            domain: "CONNECT",
            lastActive: "2 min ago"
          },
          {
            name: "Alex",
            status: "online",
            task: "Payment system",
            domain: "SUSTAIN",
            lastActive: "5 min ago"
          },
          {
            name: "Ryan",
            status: "away",
            task: "Mobile app",
            domain: "BUILD",
            lastActive: "1 hour ago"
          }
        ],
        projects: [
          {
            name: "7 Domains System",
            progress: 78,
            domain: "BUILD",
            contributors: ["Commander", "Tiger", "Alex"],
            deadline: "2 days"
          },
          {
            name: "Payment Integration",
            progress: 45,
            domain: "SUSTAIN",
            contributors: ["Alex", "Ryan"],
            deadline: "1 week"
          },
          {
            name: "Mobile App",
            progress: 23,
            domain: "CONNECT",
            contributors: ["Ryan", "Tiger"],
            deadline: "2 weeks"
          }
        ],
        stats: {
          builders_online: 3,
          visitors_today: 234,
          commits_today: 18,
          builds_deployed: 3
        },
        recent_commits: [
          {
            user: "Commander",
            message: "Session 104: Wave 1 Dashboard Factory",
            time: "10 min ago"
          },
          {
            user: "Tiger",
            message: "Voice system update",
            time: "1 hour ago"
          }
        ]
      },
      // ──────────────────────────────────────────────────────────
      // PUBLIC MODE - Visitor view
      // ──────────────────────────────────────────────────────────
      public: {
        metrics: {
          visitors_today: 234,
          visitors_total: 12847,
          tutorials_live: 23,
          products_active: 3,
          total_users: 1247,
          domains_explored: 7
        },
        viewing_window: [
          {
            builder: "Tiger",
            task: "Voice integration",
            benefit: "Accessibility for all users",
            progress: 67
          },
          {
            builder: "Alex",
            task: "Payment flow",
            benefit: "Easier checkout experience",
            progress: 45
          },
          {
            builder: "Ryan",
            task: "Mobile app",
            benefit: "Use anywhere, anytime",
            progress: 23
          }
        ],
        tutorials: [
          { title: "7 Domains Introduction", views: 1234, rating: 4.8 },
          { title: "Getting Started with ARAYA", views: 987, rating: 4.9 },
          { title: "Building Your First Project", views: 756, rating: 4.7 }
        ],
        products: [
          { name: "Builder Tier", price: "$29/mo", users: 147 },
          { name: "Architect Tier", price: "$99/mo", users: 34 },
          { name: "Oracle Tier", price: "$299/mo", users: 12 }
        ]
      }
    };
    const domainNames = ["COMMAND", "BUILD", "CONNECT", "PROTECT", "GROW", "SUSTAIN", "TRANSCEND"];
    const currentDomain = domain ? domainNames[domain - 1] : "BUILD";
    const tierData = contextData[tier] || contextData.team;
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        tier,
        domain: currentDomain,
        data: tierData,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("[ARAYA CONTEXT] Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
