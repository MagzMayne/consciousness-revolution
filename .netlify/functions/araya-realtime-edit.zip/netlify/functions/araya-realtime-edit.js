var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/araya-realtime-edit.mjs
var araya_realtime_edit_exports = {};
__export(araya_realtime_edit_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(araya_realtime_edit_exports);
var GITHUB_TOKEN = process.env.GITHUB_TOKEN;
var GITHUB_OWNER = "overkor-tek";
var GITHUB_REPO = "consciousness-revolution";
var GITHUB_BRANCH = "master";
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_SECRET || process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY;
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
var _sessionLogs = /* @__PURE__ */ new Map();
async function supabaseInsert(table, row) {
  if (!SUPABASE_URL || !SUPABASE_KEY) return null;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUPABASE_KEY}`,
        "apikey": SUPABASE_KEY,
        "Prefer": "return=representation"
      },
      body: JSON.stringify(row)
    });
    if (!res.ok) return null;
    const data = await res.json();
    return Array.isArray(data) ? data[0] : data;
  } catch {
    return null;
  }
}
async function supabaseSelect(table, filter = "") {
  if (!SUPABASE_URL || !SUPABASE_KEY) return [];
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}&order=created_at.desc&limit=100`, {
      headers: {
        "Authorization": `Bearer ${SUPABASE_KEY}`,
        "apikey": SUPABASE_KEY
      }
    });
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
}
async function getFileSha(path) {
  if (!GITHUB_TOKEN) return null;
  try {
    const res = await fetch(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}?ref=${GITHUB_BRANCH}`,
      { headers: { Authorization: `token ${GITHUB_TOKEN}`, Accept: "application/vnd.github.v3+json" } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.content || !data.sha) return null;
    let content;
    try {
      content = Buffer.from(data.content.replace(/\n/g, ""), "base64").toString("utf8");
    } catch (decodeErr) {
      console.error("[EDIT] Base64 decode failed for", path, decodeErr.message);
      return null;
    }
    return { sha: data.sha, content };
  } catch {
    return null;
  }
}
async function commitFileEdit(path, newContent, sha, message) {
  if (!GITHUB_TOKEN) return false;
  try {
    const res = await fetch(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${path}`,
      {
        method: "PUT",
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message,
          content: Buffer.from(newContent, "utf8").toString("base64"),
          sha,
          branch: GITHUB_BRANCH
        })
      }
    );
    return res.ok;
  } catch {
    return false;
  }
}
function applyEditToHtml(html, selector, property, value) {
  const overrideComment = `/* araya-edit: ${selector} */`;
  const newRule = `
${overrideComment}
${selector} { ${property}: ${value} !important; }
`;
  if (html.includes(overrideComment)) {
    return html.replace(
      new RegExp(`\\/\\* araya-edit: ${selector.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")} \\*\\/[\\s\\S]*?\\}`),
      newRule.trim()
    );
  }
  if (html.includes("</style>")) {
    return html.replace("</style>", `${newRule}</style>`);
  }
  return html.replace("</head>", `<style>${newRule}</style>
</head>`);
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  if (!["GET", "POST"].includes(event.httpMethod)) {
    return { statusCode: 405, headers: CORS_HEADERS, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  let body = {};
  try {
    body = event.httpMethod === "POST" ? JSON.parse(event.body || "{}") : {};
  } catch {
    return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { action = "edit", sessionId, page, selector, property, value, userId, editId } = body;
  const qp = event.queryStringParameters || {};
  switch (action) {
    // ── APPLY A REAL-TIME EDIT ──────────────────────────────────────────
    case "edit": {
      if (!sessionId || !page || !selector || !property || value === void 0) {
        return {
          statusCode: 400,
          headers: CORS_HEADERS,
          body: JSON.stringify({ error: "Missing required fields: sessionId, page, selector, property, value" })
        };
      }
      const timestamp = (/* @__PURE__ */ new Date()).toISOString();
      const editRecord = { sessionId, page, selector, property, value, userId: userId || "anonymous", timestamp, status: "pending" };
      const saved = await supabaseInsert("araya_edit_logs", editRecord);
      const localId = saved?.id || `local-${Date.now()}`;
      if (!_sessionLogs.has(sessionId)) _sessionLogs.set(sessionId, []);
      _sessionLogs.get(sessionId).push({ ...editRecord, id: localId });
      let committed = false;
      const filePath = page.replace(/^\//, "");
      const fileData = await getFileSha(filePath);
      if (fileData) {
        const newHtml = applyEditToHtml(fileData.content, selector, property, value);
        const commitMsg = `\u270F\uFE0F [ARAYA Edit] ${page}: ${selector} { ${property}: ${value} } \u2014 session ${sessionId}`;
        committed = await commitFileEdit(filePath, newHtml, fileData.sha, commitMsg);
      }
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          editId: localId,
          committed,
          message: committed ? "Edit saved and deployed" : "Edit logged (deploy pending \u2014 GitHub token may be needed)"
        })
      };
    }
    // ── GET SESSION LOGS ────────────────────────────────────────────────
    case "get_logs": {
      const sid = sessionId || qp.sessionId;
      if (!sid) return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: "sessionId required" }) };
      const memLogs = _sessionLogs.get(sid) || [];
      const dbLogs = await supabaseSelect("araya_edit_logs", `session_id=eq.${sid}`);
      const logs = dbLogs.length ? dbLogs : memLogs;
      return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ sessionId: sid, logs, count: logs.length }) };
    }
    // ── GET ALL EDITS FOR A PAGE ─────────────────────────────────────────
    case "get_page_edits": {
      const pg = page || qp.page;
      if (!pg) return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: "page required" }) };
      const edits = await supabaseSelect("araya_edit_logs", `page=eq.${encodeURIComponent(pg)}`);
      return { statusCode: 200, headers: CORS_HEADERS, body: JSON.stringify({ page: pg, edits, count: edits.length }) };
    }
    default:
      return { statusCode: 400, headers: CORS_HEADERS, body: JSON.stringify({ error: `Unknown action: ${action}` }) };
  }
};
var config = {
  path: "/api/araya-realtime-edit"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
