var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/dashboard-diff.mjs
var dashboard_diff_exports = {};
__export(dashboard_diff_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(dashboard_diff_exports);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  try {
    const { dashboard1, dashboard2 } = JSON.parse(event.body || "{}");
    if (!dashboard1 || !dashboard2) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Missing required params: dashboard1, dashboard2"
        })
      };
    }
    const registryPath = import_path.default.join(process.cwd(), "DASHBOARD_FEATURES_REGISTRY.json");
    const registryData = import_fs.default.readFileSync(registryPath, "utf8");
    const registry = JSON.parse(registryData);
    const dash1Features = extractDashboardFeatures(dashboard1, registry);
    const dash2Features = extractDashboardFeatures(dashboard2, registry);
    const comparison = compareDashboards(dash1Features, dash2Features, registry);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        dashboard1,
        dashboard2,
        comparison,
        stats: {
          dashboard1_features: dash1Features.length,
          dashboard2_features: dash2Features.length,
          unique_to_dashboard1: comparison.ahead.length,
          unique_to_dashboard2: comparison.behind.length,
          shared: comparison.shared.length
        }
      })
    };
  } catch (error) {
    console.error("Dashboard diff error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: error.message,
        stack: error.stack
      })
    };
  }
};
function extractDashboardFeatures(dashboardName, registry) {
  const installedFeatures = [];
  for (const feature of registry.features) {
    const installation = feature.installations.find(
      (inst) => inst.dashboard === dashboardName
    );
    if (installation) {
      installedFeatures.push({
        id: feature.id,
        name: feature.name,
        version: installation.version,
        installed_date: installation.installed_date,
        category: feature.category,
        author: feature.author,
        lfsme_avg: feature.lfsme_impact.average
      });
    }
  }
  return installedFeatures;
}
function compareDashboards(dash1Features, dash2Features, registry) {
  const dash1IDs = new Set(dash1Features.map((f) => f.id));
  const dash2IDs = new Set(dash2Features.map((f) => f.id));
  const ahead = dash1Features.filter((f) => !dash2IDs.has(f.id));
  const behind = dash2Features.filter((f) => !dash1IDs.has(f.id));
  const shared = [];
  const versionDifferences = [];
  for (const feat1 of dash1Features) {
    const feat2 = dash2Features.find((f) => f.id === feat1.id);
    if (feat2) {
      shared.push({
        id: feat1.id,
        name: feat1.name,
        dashboard1_version: feat1.version,
        dashboard2_version: feat2.version,
        version_match: feat1.version === feat2.version
      });
      if (feat1.version !== feat2.version) {
        versionDifferences.push({
          id: feat1.id,
          name: feat1.name,
          dashboard1_version: feat1.version,
          dashboard2_version: feat2.version,
          version_comparison: compareVersions(feat1.version, feat2.version)
        });
      }
    }
  }
  return {
    ahead,
    // Features dashboard1 has that dashboard2 doesn't
    behind,
    // Features dashboard2 has that dashboard1 doesn't
    shared,
    // Features both have (with version info)
    version_differences: versionDifferences
  };
}
function compareVersions(v1, v2) {
  const [major1, minor1, patch1] = v1.split(".").map(Number);
  const [major2, minor2, patch2] = v2.split(".").map(Number);
  if (major1 !== major2) return major1 > major2 ? "newer" : "older";
  if (minor1 !== minor2) return minor1 > minor2 ? "newer" : "older";
  if (patch1 !== patch2) return patch1 > patch2 ? "newer" : "older";
  return "same";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
