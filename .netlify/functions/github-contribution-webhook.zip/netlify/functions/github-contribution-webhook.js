var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/github-contribution-webhook.mjs
var github_contribution_webhook_exports = {};
__export(github_contribution_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(github_contribution_webhook_exports);
var import_crypto = __toESM(require("crypto"), 1);
var REWARDS = {
  commit: { xp: 10, okk: 5 },
  pr_opened: { xp: 20, okk: 10 },
  pr_merged: { xp: 50, okk: 25 },
  issue_closed: { xp: 30, okk: 15 },
  code_review: { xp: 20, okk: 10 },
  feature_complete: { xp: 100, okk: 50 }
};
var GITHUB_TO_TEAM = {
  "overkillkulture": { name: "Commander", id: "commander_1" },
  "darrickpreble": { name: "Commander", id: "commander_1" },
  "barbrickdesign": { name: "Ryan", id: "agent_r_1" },
  "ryanagent": { name: "Ryan", id: "agent_r_1" }
  // Add more mappings as team grows
};
var contributionStore = {};
function verifySignature(payload, signature, secret) {
  if (!secret) return true;
  const hmac = import_crypto.default.createHmac("sha256", secret);
  const digest = "sha256=" + hmac.update(payload).digest("hex");
  return import_crypto.default.timingSafeEqual(Buffer.from(signature), Buffer.from(digest));
}
function processPushEvent(payload) {
  const contributions = [];
  const repo = payload.repository?.name || "unknown";
  const commits = payload.commits || [];
  for (const commit of commits) {
    const author = commit.author?.username || commit.author?.name || "unknown";
    const teamMember = GITHUB_TO_TEAM[author.toLowerCase()];
    const closesIssue = /(?:closes?|fixes?|resolves?)\s+#(\d+)/i.test(commit.message);
    const reward = closesIssue ? REWARDS.issue_closed : REWARDS.commit;
    contributions.push({
      type: closesIssue ? "bug_fix" : "commit",
      author,
      teamMember: teamMember?.name || author,
      teamId: teamMember?.id || null,
      repo,
      sha: commit.id?.substring(0, 7),
      message: commit.message?.substring(0, 100),
      timestamp: commit.timestamp,
      reward,
      filesChanged: (commit.added?.length || 0) + (commit.modified?.length || 0) + (commit.removed?.length || 0)
    });
  }
  return contributions;
}
function processPREvent(payload) {
  const pr = payload.pull_request;
  const action = payload.action;
  const repo = payload.repository?.name || "unknown";
  const author = pr?.user?.login || "unknown";
  const teamMember = GITHUB_TO_TEAM[author.toLowerCase()];
  let reward = null;
  let type = null;
  if (action === "opened") {
    reward = REWARDS.pr_opened;
    type = "pr_opened";
  } else if (action === "closed" && pr?.merged) {
    reward = REWARDS.pr_merged;
    type = "pr_merged";
    if ((pr.additions || 0) + (pr.deletions || 0) > 500) {
      reward = REWARDS.feature_complete;
      type = "feature_complete";
    }
  }
  if (!reward) return [];
  return [{
    type,
    author,
    teamMember: teamMember?.name || author,
    teamId: teamMember?.id || null,
    repo,
    prNumber: pr?.number,
    title: pr?.title?.substring(0, 100),
    timestamp: pr?.merged_at || pr?.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    reward,
    additions: pr?.additions || 0,
    deletions: pr?.deletions || 0
  }];
}
function processReviewEvent(payload) {
  const review = payload.review;
  const pr = payload.pull_request;
  const repo = payload.repository?.name || "unknown";
  const reviewer = review?.user?.login || "unknown";
  const teamMember = GITHUB_TO_TEAM[reviewer.toLowerCase()];
  if (!["approved", "changes_requested"].includes(review?.state?.toLowerCase())) {
    return [];
  }
  return [{
    type: "code_review",
    author: reviewer,
    teamMember: teamMember?.name || reviewer,
    teamId: teamMember?.id || null,
    repo,
    prNumber: pr?.number,
    reviewState: review?.state,
    timestamp: review?.submitted_at || (/* @__PURE__ */ new Date()).toISOString(),
    reward: REWARDS.code_review
  }];
}
async function storeContribution(contribution) {
  const key = `${contribution.teamMember}_${contribution.repo}`;
  if (!contributionStore[key]) {
    contributionStore[key] = {
      teamMember: contribution.teamMember,
      teamId: contribution.teamId,
      repo: contribution.repo,
      totalXP: 0,
      totalOKK: 0,
      commits: 0,
      prs: 0,
      reviews: 0,
      bugFixes: 0,
      features: 0,
      history: []
    };
  }
  const record = contributionStore[key];
  record.totalXP += contribution.reward.xp;
  record.totalOKK += contribution.reward.okk;
  switch (contribution.type) {
    case "commit":
      record.commits++;
      break;
    case "bug_fix":
      record.bugFixes++;
      record.commits++;
      break;
    case "pr_opened":
    case "pr_merged":
      record.prs++;
      break;
    case "feature_complete":
      record.features++;
      record.prs++;
      break;
    case "code_review":
      record.reviews++;
      break;
  }
  record.history.unshift({
    type: contribution.type,
    message: contribution.message || contribution.title,
    reward: contribution.reward,
    timestamp: contribution.timestamp
  });
  if (record.history.length > 50) record.history.pop();
  return record;
}
async function handler(event) {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-Hub-Signature-256, X-GitHub-Event"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod === "GET") {
    const params = event.queryStringParameters || {};
    if (params.leaderboard) {
      const leaderboard = Object.values(contributionStore).sort((a, b) => b.totalXP - a.totalXP).slice(0, 20);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          leaderboard
        })
      };
    }
    if (params.contributor) {
      const stats = Object.values(contributionStore).filter((c) => c.teamMember.toLowerCase() === params.contributor.toLowerCase());
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          contributor: params.contributor,
          stats
        })
      };
    }
    if (params.repo) {
      const repoStats = Object.values(contributionStore).filter((c) => c.repo === params.repo);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          repo: params.repo,
          contributors: repoStats
        })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        totalContributors: Object.keys(contributionStore).length,
        contributions: contributionStore
      })
    };
  }
  if (event.httpMethod === "POST") {
    try {
      const secret = process.env.GITHUB_WEBHOOK_SECRET;
      const signature = event.headers["x-hub-signature-256"];
      if (secret && signature) {
        if (!verifySignature(event.body, signature, secret)) {
          return {
            statusCode: 401,
            headers,
            body: JSON.stringify({ error: "Invalid signature" })
          };
        }
      }
      const githubEvent = event.headers["x-github-event"];
      const payload = JSON.parse(event.body || "{}");
      let contributions = [];
      switch (githubEvent) {
        case "push":
          contributions = processPushEvent(payload);
          break;
        case "pull_request":
          contributions = processPREvent(payload);
          break;
        case "pull_request_review":
          contributions = processReviewEvent(payload);
          break;
        case "ping":
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ success: true, message: "Webhook configured!" })
          };
        default:
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ success: true, message: `Event ${githubEvent} not tracked` })
          };
      }
      const results = [];
      for (const contribution of contributions) {
        const stored = await storeContribution(contribution);
        results.push({
          contributor: contribution.teamMember,
          type: contribution.type,
          reward: contribution.reward,
          newTotals: {
            xp: stored.totalXP,
            okk: stored.totalOKK
          }
        });
      }
      console.log(`Processed ${contributions.length} contributions from ${githubEvent} event`);
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          event: githubEvent,
          contributionsProcessed: contributions.length,
          results
        })
      };
    } catch (error) {
      console.error("Webhook error:", error);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: error.message })
      };
    }
  }
  return {
    statusCode: 405,
    headers,
    body: JSON.stringify({ error: "Method not allowed" })
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
