var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/discord-verify.mjs
var discord_verify_exports = {};
__export(discord_verify_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(discord_verify_exports);

// netlify/functions/domain-tools.mjs
var LEVEL_UNLOCKS = {
  0: [],
  // LOBBY - nothing yet
  1: ["connect", "protect", "grow", "learn", "transcend", "awareness", "journey", "games"],
  // SEEKER - free domains
  2: ["command", "build", "personal_cockpit"],
  // BUILDER - team domains + personal cockpit
  3: ["araya_edit", "file_access"],
  // CONTRIBUTOR - edit powers
  4: ["full_dashboard", "all_abilities"],
  // ARCHITECT - everything
  5: ["admin", "user_management"]
  // ORACLE - admin
};
function getAccessibleDomains(level) {
  const accessible = [];
  for (let i = 0; i <= level; i++) {
    accessible.push(...LEVEL_UNLOCKS[i] || []);
  }
  return [...new Set(accessible)];
}

// netlify/functions/discord-verify.mjs
var DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
var DISCORD_GUILD_ID = process.env.DISCORD_GUILD_ID || "1458000070862573805";
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_SECRET || process.env.SUPABASE_KEY;
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
};
var ROLE_TO_LEVEL = {
  "lobby": { level: 0, xp: 0, name: "LOBBY" },
  "seeker": { level: 1, xp: 0, name: "SEEKER" },
  "builder": { level: 2, xp: 50, name: "BUILDER" },
  "contributor": { level: 3, xp: 200, name: "CONTRIBUTOR" },
  "architect": { level: 4, xp: 500, name: "ARCHITECT" },
  "oracle": { level: 5, xp: 2500, name: "ORACLE" }
};
async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }
  try {
    const { discord_user_id, action = "verify" } = event.httpMethod === "GET" ? event.queryStringParameters || {} : JSON.parse(event.body || "{}");
    if (!discord_user_id) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: "Missing discord_user_id parameter"
        })
      };
    }
    console.log(`[DISCORD-VERIFY] Checking user ${discord_user_id} in guild ${DISCORD_GUILD_ID}`);
    const memberData = await getDiscordMemberRoles(discord_user_id);
    if (!memberData) {
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: "User not found in Discord server",
          discord_user_id
        })
      };
    }
    const userLevel = calculateUserLevel(memberData.roles);
    if (SUPABASE_URL && SUPABASE_KEY) {
      await updateUserInSupabase(discord_user_id, userLevel, memberData);
    }
    const accessibleDomains = getAccessibleDomains(userLevel.level);
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: true,
        discord_user_id,
        username: memberData.username,
        level: userLevel.name,
        level_number: userLevel.level,
        xp: userLevel.xp,
        verified: userLevel.level > 0,
        accessible_domains: accessibleDomains,
        roles: memberData.role_names,
        message: `Verified as ${userLevel.name} (Level ${userLevel.level})`
      })
    };
  } catch (error) {
    console.error("[DISCORD-VERIFY] Error:", error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        error: "Internal server error",
        details: error.message
      })
    };
  }
}
async function getDiscordMemberRoles(userId) {
  const url = `https://discord.com/api/v10/guilds/${DISCORD_GUILD_ID}/members/${userId}`;
  try {
    const response = await fetch(url, {
      headers: {
        "Authorization": `Bot ${DISCORD_BOT_TOKEN}`,
        "Content-Type": "application/json"
      }
    });
    if (!response.ok) {
      console.error(`[DISCORD-VERIFY] Discord API error: ${response.status} ${response.statusText}`);
      return null;
    }
    const data = await response.json();
    const guildRoles = await getGuildRoles();
    const roleNames = data.roles.map((roleId) => {
      const role = guildRoles.find((r) => r.id === roleId);
      return role ? role.name : null;
    }).filter(Boolean);
    return {
      user_id: data.user.id,
      username: data.user.username,
      roles: data.roles,
      role_names: roleNames,
      nick: data.nick || data.user.username,
      joined_at: data.joined_at
    };
  } catch (error) {
    console.error("[DISCORD-VERIFY] Discord fetch error:", error);
    return null;
  }
}
async function getGuildRoles() {
  const url = `https://discord.com/api/v10/guilds/${DISCORD_GUILD_ID}/roles`;
  try {
    const response = await fetch(url, {
      headers: {
        "Authorization": `Bot ${DISCORD_BOT_TOKEN}`
      }
    });
    if (!response.ok) return [];
    return await response.json();
  } catch (error) {
    console.error("[DISCORD-VERIFY] Guild roles fetch error:", error);
    return [];
  }
}
function calculateUserLevel(roleNames) {
  let highestLevel = ROLE_TO_LEVEL["lobby"];
  roleNames.forEach((roleName) => {
    const normalized = roleName.toLowerCase().trim();
    const roleLevel = ROLE_TO_LEVEL[normalized];
    if (roleLevel && roleLevel.level > highestLevel.level) {
      highestLevel = roleLevel;
    }
  });
  return highestLevel;
}
async function updateUserInSupabase(discordUserId, levelInfo, memberData) {
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    console.log("[DISCORD-VERIFY] Supabase not configured - skipping user update");
    return;
  }
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/users`, {
      method: "POST",
      headers: {
        "apikey": SUPABASE_KEY,
        "Authorization": `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
      },
      body: JSON.stringify({
        discord_user_id: discordUserId,
        username: memberData.username,
        display_name: memberData.nick,
        level_name: levelInfo.name,
        level_number: levelInfo.level,
        xp: levelInfo.xp,
        verified: levelInfo.level > 0,
        discord_roles: memberData.role_names,
        last_verified: (/* @__PURE__ */ new Date()).toISOString()
      })
    });
    if (!response.ok) {
      console.error(`[DISCORD-VERIFY] Supabase update failed: ${response.status}`);
    } else {
      console.log(`[DISCORD-VERIFY] User ${discordUserId} updated in Supabase`);
    }
  } catch (error) {
    console.error("[DISCORD-VERIFY] Supabase update error:", error);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
