
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lifeforge-priorities.mjs
import { createClient } from "@supabase/supabase-js";
var DOMAIN_MAP = {
  1: { name: "COMMAND", forge: "reality", verb: "DIRECT", icon: "\u{1F3AF}" },
  2: { name: "BUILD", forge: "creation", verb: "CREATE", icon: "\u{1F528}" },
  3: { name: "CONNECT", forge: "communications", verb: "RELATE", icon: "\u{1F517}" },
  4: { name: "PROTECT", forge: "guardian", verb: "DEFEND", icon: "\u{1F6E1}\uFE0F" },
  5: { name: "GROW", forge: "wealth", verb: "EXPAND", icon: "\u{1F4C8}" },
  6: { name: "LEARN", forge: "character", verb: "EVOLVE", icon: "\u{1F4DA}" },
  7: { name: "TRANSCEND", forge: "infinity", verb: "INTEGRATE", icon: "\u267E\uFE0F" }
};
var DEFAULT_PRIORITIES = {
  1: { action: "Review today's mission and set clear direction", impact: "high", time: "15m" },
  2: { action: "Complete the next item on your build queue", impact: "high", time: "2h" },
  3: { action: "Reach out to one person who matters", impact: "medium", time: "20m" },
  4: { action: "Back up important files and check security", impact: "medium", time: "15m" },
  5: { action: "Review your financial dashboard", impact: "low", time: "10m" },
  6: { action: "Learn one new thing in your focus area", impact: "medium", time: "30m" },
  7: { action: "Reflect on patterns across all 7 domains", impact: "high", time: "15m" }
};
var DAILY_RITUALS = {
  1: "What truth did you face today?",
  2: "What did you bring into existence today?",
  3: "Who did you truly connect with today?",
  4: "What did you protect today?",
  5: "What value did you create today?",
  6: "How did you grow today?",
  7: "What pattern did you recognize today?"
};
var lifeforge_priorities_default = async (request) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  try {
    const url = new URL(request.url);
    const domainId = url.searchParams.get("domain");
    const userId = url.searchParams.get("user_id");
    let supabase = null;
    const supabaseUrl = process.env.SUPABASE_URL || Netlify.env.get("SUPABASE_URL");
    const supabaseKey = process.env.SUPABASE_ANON_KEY || Netlify.env.get("SUPABASE_ANON_KEY");
    if (supabaseUrl && supabaseKey) {
      supabase = createClient(supabaseUrl, supabaseKey);
    }
    let priorities = {};
    if (domainId) {
      const id = parseInt(domainId);
      if (id >= 1 && id <= 7) {
        priorities[id] = await getDomainPriority(id, userId, supabase);
      } else {
        return new Response(JSON.stringify({ error: "Invalid domain ID. Must be 1-7." }), {
          status: 400,
          headers
        });
      }
    } else {
      for (let i = 1; i <= 7; i++) {
        priorities[i] = await getDomainPriority(i, userId, supabase);
      }
    }
    return new Response(JSON.stringify({
      success: true,
      priorities,
      meta: {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        source: supabase ? "supabase" : "defaults",
        pattern: "3 \u2192 7 \u2192 13 \u2192 \u221E"
      }
    }), { status: 200, headers });
  } catch (error) {
    console.error("LIFEFORGE API Error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message,
      priorities: DEFAULT_PRIORITIES
    }), { status: 500, headers });
  }
};
async function getDomainPriority(domainId, userId, supabase) {
  const domain = DOMAIN_MAP[domainId];
  const defaultPriority = DEFAULT_PRIORITIES[domainId];
  const ritual = DAILY_RITUALS[domainId];
  if (supabase && userId) {
    try {
      const { data: tasks, error } = await supabase.from("user_tasks").select("*").eq("user_id", userId).eq("domain", domainId).eq("completed", false).order("priority", { ascending: false }).order("created_at", { ascending: true }).limit(1);
      if (!error && tasks && tasks.length > 0) {
        return {
          action: tasks[0].title || tasks[0].description,
          impact: tasks[0].priority || "medium",
          time: tasks[0].estimated_time || "30m",
          source: "user_tasks",
          ritual
        };
      }
      const { data: progress } = await supabase.from("forge_progress").select("*").eq("user_id", userId).eq("forge_slug", domain.forge).single();
      if (progress) {
        const currentLevel = progress.current_level || 1;
        return {
          action: `Continue ${domain.name} Phase ${currentLevel} - ${getPhaseAction(currentLevel)}`,
          impact: "high",
          time: "1h",
          source: "forge_progress",
          currentLevel,
          ritual
        };
      }
    } catch (e) {
      console.log("Supabase query failed, using defaults:", e.message);
    }
  }
  return {
    ...defaultPriority,
    domain: domain.name,
    forge: domain.forge,
    verb: domain.verb,
    icon: domain.icon,
    ritual,
    source: "default"
  };
}
function getPhaseAction(level) {
  const phases = {
    1: "Awakening",
    2: "Recognition",
    3: "Choice",
    4: "Foundation",
    5: "Practice",
    6: "Consistency",
    7: "Mastery",
    8: "Teaching",
    9: "Leadership",
    10: "Ecology",
    11: "Flow",
    12: "Transmission",
    13: "Transcendence"
  };
  return phases[level] || "Evolution";
}
var config = {
  path: "/api/lifeforge-priorities"
};
export {
  config,
  lifeforge_priorities_default as default
};
