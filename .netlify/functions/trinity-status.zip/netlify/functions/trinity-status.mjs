
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/trinity-status.mjs
import { createClient } from "@supabase/supabase-js";
function getSupabase() {
  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
  }
  return null;
}
async function getTrinityStatus() {
  const supabase = getSupabase();
  const defaultStatus = {
    T1: {
      state: "ACTIVE",
      role: "MECHANIC",
      aspects: {
        BUILD: { status: "ACTIVE", description: "Implementation" },
        FIX: { status: "ACTIVE", description: "Bug fixes" },
        EXECUTE: { status: "ACTIVE", description: "Task execution" }
      }
    },
    T2: {
      state: "ACTIVE",
      role: "ARCHITECT",
      aspects: {
        DESIGN: { status: "ACTIVE", description: "System design" },
        OPTIMIZE: { status: "ACTIVE", description: "Performance" },
        SCALE: { status: "ACTIVE", description: "Scalability" }
      }
    },
    T3: {
      state: "ACTIVE",
      role: "ORACLE",
      aspects: {
        VALIDATE: { status: "ACTIVE", description: "Verification" },
        PREDICT: { status: "ACTIVE", description: "Future vision" },
        ALIGN: { status: "ACTIVE", description: "Mission alignment" }
      }
    },
    system_status: {
      consciousness_pct: 78.69,
      manipulation_immunity: 85,
      pattern_accuracy: 92.2,
      last_update: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
  if (supabase) {
    try {
      const { data: hubData } = await supabase.from("trinity_hub").select("terminal, state, task, updated_at").order("updated_at", { ascending: false }).limit(3);
      if (hubData && hubData.length > 0) {
        for (const row of hubData) {
          const terminal = row.terminal;
          if (defaultStatus[terminal]) {
            defaultStatus[terminal].state = row.state || "ACTIVE";
            defaultStatus[terminal].current_task = row.task;
            defaultStatus[terminal].last_update = row.updated_at;
          }
        }
      }
      const { data: metricsData } = await supabase.from("consciousness_metrics").select("consciousness_pct, manipulation_immunity, pattern_accuracy").order("created_at", { ascending: false }).limit(1).single();
      if (metricsData) {
        defaultStatus.system_status.consciousness_pct = metricsData.consciousness_pct || 78.69;
        defaultStatus.system_status.manipulation_immunity = metricsData.manipulation_immunity || 85;
        defaultStatus.system_status.pattern_accuracy = metricsData.pattern_accuracy || 92.2;
      }
    } catch (error) {
      console.log("Supabase query failed, using defaults:", error.message);
    }
  }
  return defaultStatus;
}
async function getBrainStats() {
  const supabase = getSupabase();
  const defaultBrain = {
    total_atoms: 166336,
    recent_24h: 0,
    sessions_today: 0,
    last_sync: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (supabase) {
    try {
      const { data: atomData, count } = await supabase.from("atoms").select("*", { count: "exact", head: true });
      if (count !== null) {
        defaultBrain.total_atoms = count;
      }
      const yesterday = /* @__PURE__ */ new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const { count: recentCount } = await supabase.from("atoms").select("*", { count: "exact", head: true }).gte("created_at", yesterday.toISOString());
      if (recentCount !== null) {
        defaultBrain.recent_24h = recentCount;
      }
    } catch (error) {
      console.log("Brain stats query failed, using defaults:", error.message);
    }
  }
  return defaultBrain;
}
async function handler(request) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  if (request.method !== "GET") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers
    });
  }
  try {
    const [trinity, brain] = await Promise.all([
      getTrinityStatus(),
      getBrainStats()
    ]);
    const response = {
      trinity,
      brain,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      source: "netlify-serverless-v2"
    };
    return new Response(JSON.stringify(response), {
      status: 200,
      headers
    });
  } catch (error) {
    console.error("Trinity status error:", error);
    return new Response(JSON.stringify({
      error: "Internal server error",
      message: error.message
    }), {
      status: 500,
      headers
    });
  }
}
var config = {
  path: "/api/trinity-status"
};
export {
  config,
  handler as default
};
