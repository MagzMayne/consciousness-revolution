var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/trinity-status.mjs
var trinity_status_exports = {};
__export(trinity_status_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(trinity_status_exports);
var import_supabase_js = require("@supabase/supabase-js");
function getSupabase() {
  if (process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY) {
    return (0, import_supabase_js.createClient)(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
  }
  return null;
}
async function getTrinityStatus() {
  const supabase = getSupabase();
  const defaultStatus = {
    T1: {
      state: "ACTIVE",
      role: "MECHANIC",
      aspects: {
        BUILD: { status: "ACTIVE", description: "Implementation" },
        FIX: { status: "ACTIVE", description: "Bug fixes" },
        EXECUTE: { status: "ACTIVE", description: "Task execution" }
      }
    },
    T2: {
      state: "ACTIVE",
      role: "ARCHITECT",
      aspects: {
        DESIGN: { status: "ACTIVE", description: "System design" },
        OPTIMIZE: { status: "ACTIVE", description: "Performance" },
        SCALE: { status: "ACTIVE", description: "Scalability" }
      }
    },
    T3: {
      state: "ACTIVE",
      role: "ORACLE",
      aspects: {
        VALIDATE: { status: "ACTIVE", description: "Verification" },
        PREDICT: { status: "ACTIVE", description: "Future vision" },
        ALIGN: { status: "ACTIVE", description: "Mission alignment" }
      }
    },
    system_status: {
      consciousness_pct: 78.69,
      manipulation_immunity: 85,
      pattern_accuracy: 92.2,
      last_update: (/* @__PURE__ */ new Date()).toISOString()
    }
  };
  if (supabase) {
    try {
      const { data: hubData } = await supabase.from("trinity_hub").select("terminal, state, task, updated_at").order("updated_at", { ascending: false }).limit(3);
      if (hubData && hubData.length > 0) {
        for (const row of hubData) {
          const terminal = row.terminal;
          if (defaultStatus[terminal]) {
            defaultStatus[terminal].state = row.state || "ACTIVE";
            defaultStatus[terminal].current_task = row.task;
            defaultStatus[terminal].last_update = row.updated_at;
          }
        }
      }
      const { data: metricsData } = await supabase.from("consciousness_metrics").select("consciousness_pct, manipulation_immunity, pattern_accuracy").order("created_at", { ascending: false }).limit(1).single();
      if (metricsData) {
        defaultStatus.system_status.consciousness_pct = metricsData.consciousness_pct || 78.69;
        defaultStatus.system_status.manipulation_immunity = metricsData.manipulation_immunity || 85;
        defaultStatus.system_status.pattern_accuracy = metricsData.pattern_accuracy || 92.2;
      }
    } catch (error) {
      console.log("Supabase query failed, using defaults:", error.message);
    }
  }
  return defaultStatus;
}
async function getBrainStats() {
  const supabase = getSupabase();
  const defaultBrain = {
    total_atoms: 166110,
    recent_24h: 0,
    sessions_today: 0,
    last_sync: (/* @__PURE__ */ new Date()).toISOString()
  };
  if (supabase) {
    try {
      const { data: atomData, count } = await supabase.from("atoms").select("*", { count: "exact", head: true });
      if (count !== null) {
        defaultBrain.total_atoms = count;
      }
      const yesterday = /* @__PURE__ */ new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const { count: recentCount } = await supabase.from("atoms").select("*", { count: "exact", head: true }).gte("created_at", yesterday.toISOString());
      if (recentCount !== null) {
        defaultBrain.recent_24h = recentCount;
      }
    } catch (error) {
      console.log("Brain stats query failed, using defaults:", error.message);
    }
  }
  return defaultBrain;
}
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const [trinity, brain] = await Promise.all([
      getTrinityStatus(),
      getBrainStats()
    ]);
    const response = {
      trinity,
      brain,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      source: "netlify-serverless"
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error("Trinity status error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        message: error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
